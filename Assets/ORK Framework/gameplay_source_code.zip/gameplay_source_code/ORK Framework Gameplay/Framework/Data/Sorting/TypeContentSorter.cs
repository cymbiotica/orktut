
using System.Collections.Generic;

namespace ORKFramework
{
	public class TypeContentSorter : IComparer<IContent>
	{
		private bool invert = false;
		
		public TypeContentSorter(bool invert)
		{
			this.invert = invert;
		}
		
		public int Compare(IContent x , IContent y)
		{
			if(this.invert)
			{
				return y.TypeID.CompareTo(x.TypeID);
			}
			else
			{
				return x.TypeID.CompareTo(y.TypeID);
			}
		}
	}
}
