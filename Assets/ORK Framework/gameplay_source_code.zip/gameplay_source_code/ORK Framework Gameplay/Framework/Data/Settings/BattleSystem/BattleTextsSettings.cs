
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleTextsSettings : BaseSettings
	{
		// general settings
		[ORKEditorHelp("Default GUISkin", "The GUISkin used to display the damage/refresh and other texts " +
			"(e.g. level up, etc.).", "")]
		[ORKEditorInfo("Text Settings", "Base text and display settings.", "")]
		public GUISkin textSkin;
		
		[ORKEditorInfo(separator=true, labelText="All Allies Choice")]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageInfo[] allAlliesText = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count);
		
		[ORKEditorInfo(separator=true, labelText="All Enemies Choice")]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageInfo[] allEnemiesText = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count);
		
		[ORKEditorInfo(separator=true, labelText="All Combatants Choice", endFoldout=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageInfo[] allCombatantsText = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count);
		
		
		// info text settings
		[ORKEditorHelp("Show Info", "Info texts will be displayed.", "")]
		[ORKEditorInfo("Info Text Settings", "Info texts display information about " +
			"the battle action currently used by a combatant.", "")]
		public bool showInfo = true;
		
		[ORKEditorHelp("Queue Infos", "Info texts will be queued " +
			"(i.e. they will be displayed in sequence).\n" +
			"If disabled, a new info text will replace a currently displayed info text.", "")]
		[ORKEditorLayout("showInfo", true)]
		public bool queueInfos = false;
		
		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the info texts.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int infoBoxID = 0;
		
		[ORKEditorHelp("Visibility Time (s)", "The time in seconds the info text will be displayed.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float infoTime = 3;
		
		[ORKEditorHelp("Display At Combatant", "The info text will be displayed at the position of the combatant.\n" +
			"If disabled, the GUI box position is used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool infoAtCom = false;
		
		[ORKEditorHelp("Update Info", "If a combatant already shows an info text, the text will be updated.\n" +
			"If disabled, the old text will be faded out and the new text faded in (i.e. the GUI box).", "")]
		[ORKEditorLayout("infoAtCom", true)]
		public bool infoComUpdate = true;
		
		[ORKEditorHelp("Path to Child", "The info text is positioned at a child object of the combatant.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string infoChildName = "";
		
		[ORKEditorHelp("Offset", "Offset added to the object's position.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public Vector2 infoPosOff = Vector2.zero;
		
		
		// show in
		[ORKEditorHelp("Field", "The info texts will be displayed in the field (i.e. outside of battles).", "")]
		[ORKEditorInfo(separator=true, labelText="Show In")]
		public bool infoInField = false;
		
		[ORKEditorHelp("Turn Based", "The info texts will be displayed in 'Turn Based' battles.", "")]
		public bool infoInTurnBased = true;
		
		[ORKEditorHelp("Active Time", "The info texts will be displayed in 'Active Time' battles.", "")]
		public bool infoInActiveTime = true;
		
		[ORKEditorHelp("Real Time", "The info texts will be displayed in 'Real Time' battles.", "")]
		public bool infoInRealTime = true;
		
		[ORKEditorHelp("Phase", "The info texts will be displayed in 'Phase' battles.", "")]
		public bool infoPhase = true;
		
		
		// infos
		[ORKEditorInfo(separator=true, labelText="Attack Info", 
			callbackBefore="label:infotextUN", beginBox=true, endBox=true)]
		public BattleInfo attackInfo = new BattleInfo("%u attacks");
		
		[ORKEditorInfo(separator=true, labelText="Ability Info", 
			callbackBefore="label:infotextUN", beginBox=true, endBox=true)]
		public BattleInfo abilityInfo = new BattleInfo("%u uses %");
		
		[ORKEditorInfo(separator=true, labelText="Item Info", 
			callbackBefore="label:infotextUN", beginBox=true, endBox=true)]
		public BattleInfo itemInfo = new BattleInfo("%u uses %");
		
		[ORKEditorInfo(separator=true, labelText="Defend Info", 
			callbackBefore="label:infotextU", beginBox=true, endBox=true)]
		public BattleInfo defendInfo = new BattleInfo("%u defends");
		
		[ORKEditorInfo(separator=true, labelText="Escape Info", 
			callbackBefore="label:infotextU", beginBox=true, endBox=true)]
		public BattleInfo escapeInfo = new BattleInfo("%u tries to escape");
		
		[ORKEditorInfo(separator=true, labelText="Counter Info", 
			callbackBefore="label:infotextUN", beginBox=true, endBox=true)]
		public BattleInfo counterInfo = new BattleInfo("%u counters");
		
		[ORKEditorInfo(separator=true, labelText="Death Info", 
			callbackBefore="label:infotextU", beginBox=true, endBox=true)]
		public BattleInfo deathInfo = new BattleInfo("%u dies");
		
		[ORKEditorInfo(separator=true, labelText="Do Nothing Info", 
			callbackBefore="label:infotextU", beginBox=true, endBox=true)]
		public BattleInfo noneInfo = new BattleInfo("%u does nothing");
		
		[ORKEditorInfo(separator=true, labelText="Change Member Info", 
			callbackBefore="label:infotextUN", beginBox=true, endBox=true)]
		public BattleInfo changeMemberInfo = new BattleInfo("%u is exchanged for %");
		
		[ORKEditorInfo(separator=true, labelText="Join Battle Info", 
			callbackBefore="label:infotextU", beginBox=true, endBox=true)]
		public BattleInfo joinBattleInfo = new BattleInfo("%u joins the battle");
		
		// steal item infos
		[ORKEditorInfo(separator=true, labelText="Steal Item Info", 
			callbackBefore="label:infotextUN", beginBox=true, endBox=true)]
		public BattleInfo stealItemInfo = new BattleInfo("%u steals %");
		
		[ORKEditorInfo(separator=true, labelText="Steal Item Fail Info", 
			callbackBefore="label:infotextU", beginBox=true, endBox=true)]
		public BattleInfo stealItemFailInfo = new BattleInfo("%u fails to steal");
		
		// steal money infos
		[ORKEditorInfo(separator=true, labelText="Steal Money Info", 
			callbackBefore="label:infotextUN", beginBox=true, endBox=true)]
		public BattleInfo stealMoneyInfo = new BattleInfo("%u steals % money");
		
		[ORKEditorInfo(endFoldout=true, separator = true, labelText="Steal Money Fail Info", 
			callbackBefore="label:infotextU", beginBox=true, endBox=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public BattleInfo stealMoneyFailInfo = new BattleInfo("%u fails to steal money");
		
		
		// add status effect notification
		[ORKEditorHelp("Show Notification", "Show a notification text when a status effect is applied.", "")]
		[ORKEditorInfo("Add Status Effect Text", "The notification text is displayed when a " +
			"status effect is applied to a combatant.\n" +
			"Can be overriden by each status effect", "")]
		public bool useEffectNotification = true;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useEffectNotification", true, endCheckGroup=true, autoInit=true, 
			constTypes=new System.Type[] {typeof(string)}, constValues=new System.Object[] {"%"})]
		public DisplayTextSettings effectTextSettings;
		
		
		// remove status effect notification
		[ORKEditorHelp("Show Notification", "Show a notification text when a status effect is removed.", "")]
		[ORKEditorInfo("Remove Status Effect Text", "The notification text is displayed when a " +
			"status effect is removed from a combatant.\n" +
			"Can be overriden by each status effect", "")]
		public bool useEffectRemoveNotification = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useEffectRemoveNotification", true, endCheckGroup=true, autoInit=true, 
			constTypes=new System.Type[] {typeof(string)}, constValues=new System.Object[] {"%"})]
		public DisplayTextSettings effectRemoveTextSettings;
		
		
		// miss notification
		[ORKEditorHelp("Show Notification", "Show a notification text.", "")]
		[ORKEditorInfo("Miss Text", "The miss text is displayed when an attack or ability " +
			"misses it's target.", "")]
		public bool useMissNotification = true;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useMissNotification", true, endCheckGroup=true, autoInit=true, 
			constTypes=new System.Type[] {typeof(string)}, constValues=new System.Object[] {"Miss"})]
		public DisplayTextSettings missTextSettings;
		
		
		// block notification
		[ORKEditorHelp("Show Notification", "Show a notification text.", "")]
		[ORKEditorInfo("Block Text", "The block text is displayed when an attack or ability " +
			"is blocked by the target.", "")]
		public bool useBlockNotification = true;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useBlockNotification", true, endCheckGroup=true, autoInit=true, 
			constTypes=new System.Type[] {typeof(string)}, constValues=new System.Object[] {"Blocked"})]
		public DisplayTextSettings blockTextSettings;
		
		
		// cast cancel notification
		[ORKEditorHelp("Show Notification", "Show a notification text.", "")]
		[ORKEditorInfo("Cast Cancel Text", "The cast cancel text is displayed when an ability cast " +
			"is canceled (due to an attack).", "")]
		public bool useCastCancelNotification = true;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useCastCancelNotification", true, endCheckGroup=true, autoInit=true, 
			constTypes=new System.Type[] {typeof(string)}, constValues=new System.Object[] {"% canceled!"})]
		public DisplayTextSettings castCancelTextSettings;
		
		
		// level up notification
		[ORKEditorHelp("Show Notification", "Show a notification text.", "")]
		[ORKEditorInfo("Level Up Text", "The level up text is displayed when the level of a " +
			"combatant increases.", "")]
		public bool useLevelUpNotification = true;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useLevelUpNotification", true, endCheckGroup=true, autoInit=true, 
			constTypes=new System.Type[] {typeof(string)}, constValues=new System.Object[] {"Level %!"})]
		public DisplayTextSettings levelUpTextSettings;
		
		
		// level up notification
		[ORKEditorHelp("Show Notification", "Show a notification text.", "")]
		[ORKEditorInfo("Class Level Up Text", "The class level up text is displayed when the class " +
			"level of a combatant increases.", "")]
		public bool useClassLevelUpNotification = true;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useClassLevelUpNotification", true, endCheckGroup=true, autoInit=true, 
			constTypes=new System.Type[] {typeof(string)}, constValues=new System.Object[] {"Class Level %!"})]
		public DisplayTextSettings classLevelUpTextSettings;
		
		
		public BattleTextsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}
		
		public override void SetRealIDs()
		{
			
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "battleTexts"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}
		
		public override int Copy(int index)
		{
			return -1;
		}
		
		public override void Remove(int index)
		{
			
		}
		
		public override void Move(int index, bool down)
		{
			
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public ChoiceContent GetAllCombatantsContent(TargetType t, ContentLayout layout)
		{
			if(TargetType.Ally.Equals(t))
			{
				return layout.GetChoiceContent(this.allAlliesText);
			}
			else if(TargetType.Enemy.Equals(t))
			{
				return layout.GetChoiceContent(this.allEnemiesText);
			}
			else if(TargetType.All.Equals(t))
			{
				return layout.GetChoiceContent(this.allCombatantsText);
			}
			return null;
		}
		
		public GUISkin GUISkin
		{
			get{ return this.textSkin;}
		}
	}
}
