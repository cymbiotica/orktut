
using UnityEngine;

namespace ORKFramework
{
	public class StatusDevelopmentsSettings : BaseSettings
	{
		public StatusDevelopment[] data = new StatusDevelopment[] {new StatusDevelopment("Default Development")};
		
		public StatusDevelopmentsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}
		
		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "statusDevelopments"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].name;
			}
			else
			{
				return "StatusDevelopment(" + index + ") not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i=0; i<names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.data[i].name;
				}
				else
				{
					names[i] = this.data[i].name;
				}
			}
			return names;
		}
		
		public override int Count
		{
			get{ return this.data.Length;}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			ArrayHelper.Add(ref this.data, new StatusDevelopment("New Development"));
			DataHelper.Added(ORKDataType.StatusDevelopment);
			return this.data.Length - 1;
		}
		
		public override int Copy(int index)
		{
			ArrayHelper.Add(ref this.data, this.GetCopy(index));
			DataHelper.Added(ORKDataType.StatusDevelopment);
			return this.data.Length - 1;
		}
		
		public StatusDevelopment GetCopy(int index)
		{
			StatusDevelopment t = new StatusDevelopment();
			if(index >= 0 && index < this.data.Length)
			{
				t.SetData(this.data[index].GetData());
			}
			return t;
		}
		
		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.StatusDevelopment, index);
		}
		
		public StatusDevelopment Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else
			{
				return this.data[0];
			}
		}
		
		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.StatusDevelopment, down, index);
		}
		
		
		/*
		============================================================================
		Add, remove callbacks
		============================================================================
		*/
		public void StatusValueAdded()
		{
			for(int i=0; i<this.data.Length; i++)
			{
				StatusValueSetting value = ORK.StatusValues.Get(ORK.StatusValues.Count - 1);
				if(value.IsConsumable())
				{
					ArrayHelper.Add(ref this.data[i].statusValue, null);
				}
				else
				{
					ArrayHelper.Add(ref this.data[i].statusValue, 
						new LearnStatusValue(this.data[i].maxLevel, value.minValue, value.maxValue));
				}
			}
		}
		
		public void SetStatusValueType(int index, StatusValueType type)
		{
			for(int i=0; i<this.data.Length; i++)
			{
				StatusValueSetting value = ORK.StatusValues.Get(index);
				if(value.IsConsumable())
				{
					this.data[i].statusValue[index] = null;
				}
				else
				{
					this.data[i].statusValue[index] = new LearnStatusValue(
						this.data[i].maxLevel, value.minValue, value.maxValue);
				}
				
				if(!value.IsNormal())
				{
					for(int j=0; j<this.data[i].upgrade.Length; j++)
					{
						if(this.data[i].upgrade[j].statusID == index)
						{
							ArrayHelper.RemoveAt(ref this.data[i].upgrade, j--);
						}
					}
				}
			}
		}
		
		public void StatusValueMinMaxChanged(int index, int min, int max)
		{
			for(int i=0; i<this.data.Length; i++)
			{
				if(this.data[i].statusValue[index] != null && 
					this.data[i].statusValue[index].levelValue != null)
				{
					for(int j=0; j<this.data[i].statusValue[index].levelValue.Length; j++)
					{
						if(this.data[i].statusValue[index].levelValue[j] < min)
						{
							this.data[i].statusValue[index].levelValue[j] = min;
						}
						else if(this.data[i].statusValue[index].levelValue[j] > max)
						{
							this.data[i].statusValue[index].levelValue[j] = max;
						}
					}
				}
			}
		}
	}
}
