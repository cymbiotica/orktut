
using ORKFramework;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera: Top Down Border")]
	public class TopDownBorderCamera : BaseCameraControl
	{
		public bool initialDamping = true;
		
		public string onChild = "";
		
		public float positionDamping = 0;
		
		public Vector4 positionPadding = new Vector4(0, 0, 0, 0);
		
		
		// distance
		public float distance = 10.0f;
		
		
		// height
		public float height = 5.0f;
		
		public float heightDamping = 2.0f;
		
		
		// rotation
		public float rotation = 0;
		
		
		// in-game
		private CameraBorder cameraBorder;
		
		private bool firstUpdate = true;
		
		void Start()
		{
			this.cameraBorder = GameObject.FindObjectOfType<CameraBorder>();
			
			if(this.cameraBorder != null)
			{
				if(this.cameraBorder.setRotation)
				{
					this.rotation = this.cameraBorder.rotation;
				}
			}
		}
		
		void LateUpdate()
		{
			GameObject obj = TransformHelper.GetChildObject(this.onChild, this.CameraTarget);
			if(obj != null)
			{
				Vector3 targetPosition = obj.transform.position;
				
				if(this.cameraBorder != null)
				{
					this.cameraBorder.UpdatePosition(ref targetPosition, this.positionPadding);
				}
				
				Vector3 lookTargetPosition = targetPosition;
				
				// calculate the new height
				float targetHeight = transform.position.y;
				if(this.heightDamping > 0 && 
					(this.initialDamping || !this.firstUpdate))
				{
					targetHeight = Mathf.Lerp(targetHeight, targetPosition.y + this.height, 
						this.heightDamping * Time.deltaTime);
				}
				else
				{
					targetHeight = targetPosition.y + this.height;
				}
				
				// update camera position
				targetPosition -= Quaternion.Euler(0, this.rotation, 0) * Vector3.forward * this.distance;
				targetPosition.y = targetHeight;
				
				if(this.cameraBorder != null)
				{
					this.cameraBorder.UpdateCameraHeight(ref targetPosition);
				}
				
				if(this.positionDamping > 0 && 
					(this.initialDamping || !this.firstUpdate))
				{
					transform.position = Vector3.Lerp(transform.position, targetPosition, 
						this.positionDamping * Time.deltaTime);
				}
				else
				{
					transform.position = targetPosition;
				}
				
				// Always look at the target
				transform.LookAt(lookTargetPosition);
				
				this.firstUpdate = false;
			}
			else
			{
				this.firstUpdate = true;
			}
		}
	}
}
