
using ORKFramework;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	public abstract class BaseConditionComponent : SceneID
	{
		// variable conditions
		public bool autoDestroy = true;
		
		public bool repeatDestroy = false;
		
		public float destroyCheckTime = 1;
		
		public bool checkObjectVariables = false;
		
		public VariableCondition variableCondition = new VariableCondition();
		
		
		// variable setter
		public bool setObjectVariables = false;
		
		public VariableSetter variableSetter = new VariableSetter();
		
		
		// quest conditions
		public QuestCondition questCondition = new QuestCondition();
		
		
		// ingame
		protected bool isInvoking = false;
		
		
		/*
		============================================================================
		Auto start functions
		============================================================================
		*/
		void Start()
		{
			this.CheckAutoDestroy();
		}
		
		
		/*
		============================================================================
		Condition functions
		============================================================================
		*/
		public bool CheckConditions()
		{
			return this.CheckVariables() && this.questCondition.Check();
		}
		
		public bool CheckVariables()
		{
			if(this.checkObjectVariables)
			{
				ObjectVariablesComponent comp = ComponentHelper.
					GetInChildren<ObjectVariablesComponent>(this.gameObject);
				if(comp != null)
				{
					return this.variableCondition.CheckVariables(comp.GetHandler());
				}
			}
			else
			{
				return this.variableCondition.CheckVariables();
			}
			return false;
		}
		
		public void SetVariables()
		{
			if(this.setObjectVariables)
			{
				ObjectVariablesComponent comp = ComponentHelper.
					GetInChildren<ObjectVariablesComponent>(this.gameObject);
				if(comp != null)
				{
					this.variableSetter.SetVariables(comp.GetHandler());
				}
			}
			else
			{
				this.variableSetter.SetVariables();
			}
		}
		
		
		/*
		============================================================================
		Auto destroy functions
		============================================================================
		*/
		protected bool CheckAutoDestroy()
		{
			if(this.autoDestroy)
			{
				if(!this.CheckConditions())
				{
					GameObject.Destroy(this.gameObject);
					return true;
				}
				else if(this.repeatDestroy && !this.isInvoking)
				{
					this.isInvoking = true;
					this.InvokeRepeating("AutoDestroy", this.destroyCheckTime, this.destroyCheckTime);
				}
			}
			return false;
		}
		
		protected void AutoDestroy()
		{
			if(this.CheckAutoDestroy())
			{
				GameObject.Destroy(this.gameObject);
				this.CancelInvoke("AutoDestroy");
				this.isInvoking = false;
			}
		}
	}
}
