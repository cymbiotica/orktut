
using ORKFramework;
using ORKFramework.Animations;
using ORKFramework.Events;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Events/Item Collector")]
	public class ItemCollector : BaseInteraction
	{
		// collection type settings
		public CollectionType collectionType = CollectionType.Single;
	
		public string boxID = "";
		
		public bool blockControl = true;
		
		public bool destroyObject = true;
	
	
		// faction
		public bool useFaction = false;
	
		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;
	
	
		// place on ground
		public bool onGround = true;

		public float distance = 100.0f;

		public LayerMask layerMask = -1;
	
	
		// item
		public bool setVariablesOnChance = false;
	
		public bool destroyEmptyBox = false;
		
		public bool showDialogue = true;
		
		public bool showNotification = true;
		
		public bool showConsole = true;
	
		public ItemGain[] item = new ItemGain[] {new ItemGain()};
	
		public bool spawnPrefab = true;
	
		public bool doMount = false;
	
		public MountSettings mount = new MountSettings();
	
	
		// ingame
		private GameObject pref;

		private DropInfo dropInfo;
		
		private List<IShortcut> itemList;
		
		private IEventStarter starter;
		
		public void SetOnGround()
		{
			if(this.onGround)
			{
				RaycastOutput hit;
				if(RaycastHelper.Raycast(transform.position, -Vector3.up, out hit, this.distance, this.layerMask))
				{
					transform.position = hit.point;
				}
			}
		}
	
	
		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public override InteractionType Type
		{
			get
			{
				if(CollectionType.Box.Equals(this.collectionType))
				{
					return InteractionType.ItemBox;
				}
				else
				{
					return InteractionType.Item;
				}
			}
		}
	
	
		/*
		============================================================================
		Item list functions
		============================================================================
		*/
		public List<IShortcut> ItemList
		{
			get{ return this.itemList;}
		}
	
		private void AddItemCheck(ItemGain i)
		{
			if(i.CheckChance())
			{
				ShortcutHelper.Add(ref this.itemList, i.CreateShortcut(), 
					ORK.InventorySettings.itemBoxCollection.autoStack);
			}
		}
	
		public void SetDropInfo(DropInfo info)
		{
			this.dropInfo = info;
			this.itemList = new List<IShortcut>();
			this.itemList.Add(this.dropInfo.Item);
			this.useSceneID = false;
			this.collectionType = CollectionType.Single;
			this.startType = ORK.InventorySettings.dropStartType;
			this.onGround = ORK.InventorySettings.dropOnGround;
			this.layerMask = ORK.InventorySettings.dropMask;
		}
	
	
		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		void Start()
		{
			bool destroy = false;
			if(this.dropInfo != null)
			{
				this.SetOnGround();
			}
			else if(!this.CheckAutoDestroy())
			{
				if(!CollectionType.Box.Equals(this.collectionType) && 
					this.useSceneID && ORK.Game.Scene.IsItemCollected(this.sceneID))
				{
					if(this.destroyObject)
					{
						GameObject.Destroy(this.gameObject);
					}
					else
					{
						GameObject.Destroy(this);
					}
					destroy = true;
				}
				else
				{
					this.itemList = new List<IShortcut>();
				
					if(CollectionType.Single.Equals(this.collectionType))
					{
						this.AddItemCheck(this.item[0]);
					}
					else if(CollectionType.Random.Equals(this.collectionType))
					{
						this.AddItemCheck(this.item[Random.Range(0, this.item.Length)]);
					}
					else if(CollectionType.Box.Equals(this.collectionType))
					{
						if(!ORK.Game.Scene.GetItemBox(this.boxID, ref this.itemList))
						{
							for(int i=0; i<this.item.Length; i++)
							{
								this.AddItemCheck(this.item[i]);
							}
							ORK.Game.Scene.SetItemBox(this.boxID, this.itemList);
						}
					}
				
					if(this.itemList.Count > 0)
					{
						this.SetOnGround();
					}
					else
					{
						if(this.setVariablesOnChance)
						{
							this.SetVariables();
							if(this.useSceneID)
							{
								ORK.Game.Scene.ItemCollected(this.sceneID);
							}
						}
						if(!CollectionType.Box.Equals(this.collectionType) || 
							this.destroyEmptyBox)
						{
							GameObject.Destroy(this.gameObject);
							destroy = true;
						}
					}
				}
			}
			
			if(!destroy)
			{
				if(this.itemList.Count == 0)
				{
					GameObject.Destroy(this.gameObject);
				}
				else if(EventStartType.Autostart.Equals(this.startType))
				{
					if(this.CheckConditions())
					{
						this.AutoStart();
					}
					else
					{
						if(this.destroyObject)
						{
							GameObject.Destroy(this.gameObject);
						}
						else
						{
							GameObject.Destroy(this);
						}
					}
				}
				else if(this.spawnPrefab && !CollectionType.Box.Equals(this.collectionType))
				{
					Vector3 offset = Vector3.zero;
					if(this.itemList[0] is MoneyShortcut)
					{
						this.pref = ((MoneyShortcut)this.itemList[0]).Setting.GetPrefabInstance();
						offset = ((MoneyShortcut)this.itemList[0]).Setting.spawnOffset;
					}
					else if(this.itemList[0] is ItemShortcut)
					{
						this.pref = ((ItemShortcut)this.itemList[0]).Setting.GetPrefabInstance();
						offset = ((ItemShortcut)this.itemList[0]).Setting.spawnOffset;
					}
					else if(this.itemList[0] is EquipShortcut)
					{
						this.pref = ((EquipShortcut)this.itemList[0]).Setting.GetPrefabInstance();
						offset = ((EquipShortcut)this.itemList[0]).Setting.spawnOffset;
					}
				
					if(this.pref != null)
					{
						if(this.doMount)
						{
							this.mount.MountTo(this.transform, this.pref.transform);
						}
						else
						{
							this.mount.Place(this.transform, this.pref.transform);
						}
						this.pref.transform.position += offset;
						InteractionForwarder fw = this.pref.AddComponent<InteractionForwarder>();
						fw.baseInteraction = this;
						fw.startType = this.startType;
					}
				}
			}
		}
	
		public override bool CanInteract(EventStartType type, GameObject gameObject)
		{
			return base.CanInteract(type, gameObject) && 
				((CollectionType.Box.Equals(this.collectionType) && 
					(!ORK.InventorySettings.itemBoxCollection.autoClose ||
					this.itemList.Count > 0)) || 
				(!CollectionType.Box.Equals(this.collectionType) && 
					(!this.useSceneID || !ORK.Game.Scene.IsItemCollected(this.sceneID))));
		}
	
		public override void StartEvent(GameObject startingObject)
		{
			this.StartCoroutine(this.StartEvent2());
		}
	
		public void StartEvent(IEventStarter starter)
		{
			this.starter = starter;
			this.StartCoroutine(this.StartEvent2());
		}
		
		private IEnumerator StartEvent2()
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;
			
			if(!this.eventStarted)
			{
				this.eventStarted = true;
				
				if(this.blockControl)
				{
					ORK.Control.SetBlockControl(1, true);
				}
				if(CollectionType.Box.Equals(this.collectionType))
				{
					if(ORK.InventorySettings.itemBoxCollection.playSound)
					{
						Combatant p = ORK.Game.ActiveGroup.Leader;
						if(p != null)
						{
							AudioSource source = p.GetAudioSource();
							if(source != null)
							{
								AudioClip clip = null;
								if(ORK.InventorySettings.itemBoxCollection.useSoundType)
								{
									clip = p.Animations.GetAudioClip(ORK.InventorySettings.itemBoxCollection.soundTypeID);
									
									source.PlayOneShot(
										ORK.InventorySettings.itemBoxCollection.audioClip, 
										ORK.InventorySettings.itemBoxCollection.volume * ORK.Game.SoundVolume);
								}
								else
								{
									clip = ORK.InventorySettings.itemBoxCollection.audioClip;
								}
								if(clip != null)
								{
									source.PlayOneShot(
										ORK.InventorySettings.itemBoxCollection.audioClip, 
										ORK.InventorySettings.itemBoxCollection.volume * ORK.Game.SoundVolume);
								}
							}
						}
					}
					if(ORK.InventorySettings.itemBoxCollection.useAnimation)
					{
						Combatant p = ORK.Game.ActiveGroup.Leader;
						if(p != null)
						{
							yield return new WaitForSeconds(
								p.Animations.Play(ORK.InventorySettings.itemBoxCollection.animationTypeID).length);
						}
					}
					
					ORK.Game.Scene.GetItemBox(this.boxID, ref this.itemList);
					ORK.InventorySettings.itemBoxCollection.Show(this);
				}
				else if(this.itemList.Count > 0)
				{
					if(this.showDialogue)
					{
						ORK.InventorySettings.itemCollection.Show(this, this.itemList[0]);
					}
					else
					{
						this.CollectionFinished(ORK.Game.ActiveGroup.Leader.Inventory.CanCollect(this.itemList[0]));
					}
				}
			}
		}
	
		public void CollectionFinished(bool ok)
		{
			this.StartCoroutine(this.CollectionFinished2(ok));
		}
	
		private IEnumerator CollectionFinished2(bool ok)
		{
			if(CollectionType.Box.Equals(this.collectionType))
			{
				ORK.Game.Scene.SetItemBox(this.boxID, this.itemList);
				
				this.SetVariables();
				
				if(this.destroyEmptyBox && this.itemList.Count == 0)
				{
					GameObject.Destroy(this.gameObject);
				}
				else if(this.autoDestroy)
				{
					this.CheckAutoDestroy();
				}
			}
			else
			{
				if(ok)
				{
					if(ORK.InventorySettings.itemCollection.playSound)
					{
						Combatant p = ORK.Game.ActiveGroup.Leader;
						if(p != null)
						{
							AudioSource source = p.GetAudioSource();
							if(source != null)
							{
								AudioClip clip = null;
								if(ORK.InventorySettings.itemCollection.useSoundType)
								{
									clip = p.Animations.GetAudioClip(ORK.InventorySettings.itemCollection.soundTypeID);
									
									source.PlayOneShot(
										ORK.InventorySettings.itemCollection.audioClip, 
										ORK.InventorySettings.itemCollection.volume * ORK.Game.SoundVolume);
								}
								else
								{
									clip = ORK.InventorySettings.itemCollection.audioClip;
								}
								if(clip != null)
								{
									source.PlayOneShot(
										ORK.InventorySettings.itemCollection.audioClip, 
										ORK.InventorySettings.itemCollection.volume * ORK.Game.SoundVolume);
								}
							}
						}
					}
					if(ORK.InventorySettings.itemCollection.useAnimation)
					{
						Combatant p = ORK.Game.ActiveGroup.Leader;
						if(p != null)
						{
							yield return new WaitForSeconds(p.Animations.Play(ORK.InventorySettings.itemCollection.animationTypeID).length);
						}
					}
				
					this.SetVariables();
					if(this.useSceneID)
					{
						ORK.Game.Scene.ItemCollected(this.sceneID);
					}
				
					this.CollectItem(0, ORK.Game.ActiveGroup.Leader);
				
					if(this.dropInfo != null)
					{
						ORK.Game.Scene.Collected(this.dropInfo);
					}
					if(this.pref != null)
					{
						GameObject.Destroy(this.pref);
					}
					if(this.destroyObject)
					{
						GameObject.Destroy(this.gameObject);
					}
					else
					{
						GameObject.Destroy(this);
					}
				}
				else if(this.autoDestroy)
				{
					this.CheckAutoDestroy();
				}
			}
			if(this.blockControl)
			{
				ORK.Control.SetBlockControl(-1, true);
			}
			
			if(ComponentHelper.IsAlive(this.starter))
			{
				this.starter.EventEnded();
				this.starter = null;
			}
			this.eventStarted = false;
		}
	
		private void CollectItem(int index, Combatant combatant)
		{
			if(index >= 0 && index < this.itemList.Count)
			{
				// change sympathy for player
				if(this.useFaction)
				{
					ShortcutHelper.TakeFromFaction(this.itemList[index], this.factionID, combatant.Group.FactionID);
				}
				combatant.Inventory.Add(this.itemList[index], this.showNotification, this.showConsole);
				this.itemList.RemoveAt(index);
			}
		}
		
		public void AddItem(IShortcut shortcut)
		{
			ShortcutHelper.Add(ref this.itemList, shortcut, ORK.InventorySettings.itemBoxCollection.autoStack);
		}
		
		public void DestroySpawnedPrefab()
		{
			if(this.pref != null)
			{
				GameObject.Destroy(this.pref);
			}
		}
	
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "ItemCollector.psd");
		}
	}
}
