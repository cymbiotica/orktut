
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Show Image", "Shows an image on the screen.\n" +
		"Images are displayed on a GUI layer before the GUI boxes of the layer.\n" +
		"You can access images later by referring to their ID - you can even access images created by other events.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Image Steps")]
	public class ShowImageStep : BaseEventStep
	{
		[ORKEditorHelp("GUI Layer", "Select the GUI layer this image will be displayed on.\n" +
			"Images are displayed before GUI boxes of a layer.", "")]
		[ORKEditorInfo(ORKDataType.GUILayer)]
		public int layerID = 0;
		
		[ORKEditorHelp("Image ID", "Set the ID of this image.\n" +
			"An image is identified and accessed by it's ID - the ID is valid for the selected layer.\n" +
			"If you show an image using the ID of another image, the other image will be replaced by the new one.\n" +
			"You can access images created by another event through their ID.", "")]
		[ORKEditorLimit(0, false)]
		public int id = 0;
		
		[ORKEditorHelp("Bounds", "Set the position (X, Y) and size (W, H) of the image.", "")]
		[ORKEditorInfo(separator=true)]
		public Rect bounds = new Rect(0, 0, 100, 100);
		
		[ORKEditorHelp("Color", "Set the start color of the image.\n" +
			"The color is used for fade effects - to fade in an image, " +
			"set the start color's alpha value to 0.", "")]
		public Color color = Color.white;
		
		[ORKEditorInfo(separator=true, labelText="Image Settings")]
		public BaseImage image = new BaseImage();
		
		public ShowImageStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			new ImageFader(this.layerID, this.id, this.image, this.bounds, this.color);
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.GUILayers.GetName(this.layerID) + ": " + this.id;
		}
	}
	
	[ORKEditorHelp("Change Image Position", "Changes the position of an image.\n" +
		"Images are displayed on a GUI layer before the GUI boxes of the layer.\n" +
		"You can access images later by referring to their ID - you can even access images created by other events.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Image Steps")]
	public class ChangeImagePositionStep : BaseEventStep
	{
		[ORKEditorHelp("GUI Layer", "Select the GUI layer of the image.", "")]
		[ORKEditorInfo(ORKDataType.GUILayer)]
		public int layerID = 0;
		
		[ORKEditorHelp("Image ID", "Set the ID of the image.\n" +
			"An image is identified and accessed by it's ID - the ID is valid for the selected layer.\n" +
			"If you show an image using the ID of another image, the other image will be replaced by the new one.\n" +
			"You can access images created by another event through their ID.", "")]
		[ORKEditorLimit(0, false)]
		public int id = 0;
		
		
		// position
		[ORKEditorHelp("Bounds", "Set the new position (X, Y) and size (W, H) of the image.", "")]
		[ORKEditorInfo(separator=true)]
		public Rect bounds = new Rect(0, 0, 100, 100);
		
		[ORKEditorHelp("Fade Position", "Fade to the new position of the image.", "")]
		public bool fadePosition = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds used to fade.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("fadePosition", true)]
		public float time = 1;
		
		[ORKEditorHelp("Wait", "Wait until fading has finished before the next step is executed.", "")]
		public bool wait = false;
		
		[ORKEditorHelp("Interpolation", "The interpolation used for fading.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public EaseType interpolation = EaseType.Linear;
		
		public ChangeImagePositionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ImageFader fader = ORK.GUI.GetImage(this.layerID, this.id);
			if(fader != null)
			{
				if(this.fadePosition)
				{
					fader.FadeToPosition(this.bounds, this.interpolation, this.time);
				}
				else
				{
					fader.SetPosition(this.bounds);
				}
			}
			if(this.wait)
			{
				baseEvent.StartTime(this.time, this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.GUILayers.GetName(this.layerID) + ": " + this.id +
				(this.fadePosition ? ", " + this.time + "s" + (this.wait ? " (wait)" : "") : "");
		}
	}
	
	[ORKEditorHelp("Change Image Color", "Changes the color of an image.\n" +
		"Images are displayed on a GUI layer before the GUI boxes of the layer.\n" +
		"You can access images later by referring to their ID - you can even access images created by other events.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Image Steps")]
	public class ChangeImageColorStep : BaseEventStep
	{
		[ORKEditorHelp("GUI Layer", "Select the GUI layer of the image.", "")]
		[ORKEditorInfo(ORKDataType.GUILayer)]
		public int layerID = 0;
		
		[ORKEditorHelp("Image ID", "Set the ID of the image.\n" +
			"An image is identified and accessed by it's ID - the ID is valid for the selected layer.\n" +
			"If you show an image using the ID of another image, the other image will be replaced by the new one.\n" +
			"You can access images created by another event through their ID.", "")]
		[ORKEditorLimit(0, false)]
		public int id = 0;
		
		
		// color
		[ORKEditorHelp("Fade Color", "Fade to the new color of the image.\n" +
			"If disabled, the color will be set immediately.", "")]
		[ORKEditorInfo(separator=true)]
		public bool fadeColor = false;
		
		[ORKEditorLayout("fadeColor", true, autoInit=true)]
		public FadeColorSettings fadeSettings;
		
		[ORKEditorHelp("Wait", "Wait until fading has finished before the next step is executed.", "")]
		public bool wait = false;
		
		[ORKEditorHelp("Color", "The new color of the image.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public Color color = Color.white;
		
		public ChangeImageColorStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ImageFader fader = ORK.GUI.GetImage(this.layerID, this.id);
			if(fader != null)
			{
				if(this.fadeColor)
				{
					fader.FadeToColor(this.fadeSettings);
				}
				else
				{
					fader.SetColor(this.color);
				}
			}
			if(this.wait && this.fadeColor)
			{
				baseEvent.StartTime(this.fadeSettings.time, this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.GUILayers.GetName(this.layerID) + ": " + this.id +
				(this.fadeColor ? ", " + this.fadeSettings.time + "s" + (this.wait ? " (wait)" : "") : "");
		}
	}
	
	[ORKEditorHelp("Remove Image", "Removes an image from the screen.\n" +
		"Images are displayed on a GUI layer before the GUI boxes of the layer.\n" +
		"You can access images later by referring to their ID - you can even access images created by other events.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Image Steps")]
	public class RemoveImageStep : BaseEventStep
	{
		[ORKEditorHelp("GUI Layer", "Select the GUI layer the image will be removed from.", "")]
		[ORKEditorInfo(ORKDataType.GUILayer)]
		public int layerID = 0;
		
		[ORKEditorHelp("Image ID", "Set the ID of the image.\n" +
			"An image is identified and accessed by it's ID - the ID is valid for the selected layer.\n" +
			"If you show an image using the ID of another image, the other image will be replaced by the new one.\n" +
			"You can access images created by another event through their ID.", "")]
		[ORKEditorLimit(0, false)]
		public int id = 0;
		
		public RemoveImageStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.GUI.RemoveImage(this.layerID, this.id);
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.GUILayers.GetName(this.layerID) + ": " + this.id;
		}
	}
}
