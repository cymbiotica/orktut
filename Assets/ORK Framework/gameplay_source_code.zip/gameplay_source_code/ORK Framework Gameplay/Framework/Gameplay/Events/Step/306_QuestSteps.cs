
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Add Quest", "A new quest will be added to the player's quest list.\n" +
		"If the quest is already added, it wont be added again.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Quest Steps")]
	public class AddQuestStep : BaseEventStep
	{
		[ORKEditorHelp("Quest", "Select the quest that will be added.", "")]
		[ORKEditorInfo(ORKDataType.Quest)]
		public int id = 0;
		
		[ORKEditorHelp("Show Notification", "Show the quest's add notification.", "")]
		public bool showNotification = true;
		
		[ORKEditorHelp("Show Console", "Show the quest's add text in the console.", "")]
		public bool showConsole = true;
		
		public AddQuestStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Game.Quests.AddQuest(this.id, this.showNotification, this.showConsole);
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Quests.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Remove Quest", "Removes a quest from the player's quest list.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Quest Steps")]
	public class RemoveQuestStep : BaseEventStep
	{
		[ORKEditorHelp("Quest", "Select the quest that will be removed.", "")]
		[ORKEditorInfo(ORKDataType.Quest)]
		public int id = 0;
		
		[ORKEditorHelp("Show Console", "Show the quest's remove text in the console.", "")]
		public bool showConsole = true;
		
		public RemoveQuestStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Game.Quests.RemoveQuest(this.id, this.showConsole);
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Quests.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Change Quest Status", "Changes the status of a quest in the player's quest list.\n" +
		"The quest has to be in the player's quest list.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Quest Steps")]
	public class ChangeQuestStatusStep : BaseEventStep
	{
		[ORKEditorHelp("Quest", "Select the quest which's status will be changed.", "")]
		[ORKEditorInfo(ORKDataType.Quest)]
		public int id = 0;
		
		[ORKEditorHelp("Status", "Select the status the quest will be changed to:\n" +
			"- Inactive: The quest will be set inactive (only possible if the quest is active).\n" +
			"- Active: The quest will be set active (only possible if the quest is inactive).\n" +
			"- Finished: The quest will be finished (only possible if the quest is active/inactive).\n" +
			"- Failed: The quest will fail (only possible if the quest is active/inactive).", "")]
		public QuestStatusType status = QuestStatusType.Finished;
		
		[ORKEditorHelp("Show Notification", "Show the quest's status change notification.", "")]
		public bool showNotification = true;
		
		[ORKEditorHelp("Show Console", "Show the quest's status change in the console.", "")]
		public bool showConsole = true;
		
		// finish
		[ORKEditorHelp("Get Rewards", "The quest's rewards will be collected.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("status", QuestStatusType.Finished)]
		public bool getRewards = true;
		
		[ORKEditorHelp("Finish All Tasks", "All active quest tasks will be finished.", "")]
		public bool finishAllTasks = false;
		
		[ORKEditorHelp("Get Task Rewards", "The finished task's rewards will be collected", "")]
		[ORKEditorLayout("finishAllTasks", true, endCheckGroup=true, endGroups=2)]
		public bool getTaskRewards = true;
		
		public ChangeQuestStatusStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			Quest quest = ORK.Game.Quests.GetQuest(this.id);
			if(quest != null)
			{
				if(QuestStatusType.Inactive.Equals(this.status))
				{
					quest.SetInactive(ORK.Game.ActiveGroup.Leader, this.showNotification, this.showConsole);
				}
				else if(QuestStatusType.Active.Equals(this.status))
				{
					quest.SetActive(ORK.Game.ActiveGroup.Leader, this.showNotification, this.showConsole);
				}
				else if(QuestStatusType.Finished.Equals(this.status))
				{
					quest.SetFinished(ORK.Game.ActiveGroup.Leader, this.showNotification, this.showConsole, 
						this.getRewards, this.finishAllTasks, this.getTaskRewards);
				}
				else if(QuestStatusType.Failed.Equals(this.status))
				{
					quest.SetFailed(ORK.Game.ActiveGroup.Leader, this.showNotification, this.showConsole);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Quests.GetName(this.id) + ": " + this.status.ToString();
		}
	}
	
	[ORKEditorHelp("Has Quest", "Checks if a selected quest is in the player's quest list.\n" +
		"If the quest is in the quest list, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Quest Steps", "Check Steps")]
	public class HasQuestStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Quest", "Select the quest that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.Quest)]
		public int id = 0;
		
		public HasQuestStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ORK.Game.Quests.HasQuest(this.id))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Quests.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Check Quest Conditions", "Checks a series of quest and quest task conditions.\n" +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Quest Steps", "Check Steps")]
	public class CheckQuestConditionStep : BaseEventCheckStep
	{
		public QuestCondition condition = new QuestCondition();
		
		public CheckQuestConditionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.condition.Check())
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
	}
	
	[ORKEditorHelp("Quest Condition Fork", "Checks the status of quests.\n" +
		"If a condition is valid, it's next step will be executed.\n" +
		"If no condition is valid, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Quest Steps", "Check Steps")]
	public class QuestConditionForkStep : BaseEventStep
	{
		[ORKEditorArray(false, "Add Quest Condition", "Adds a new quest status condition.", "", 
			"Remove", "Removes the quest status condition.", "", isMove=true, isCopy=true, 
			removeType=ORKDataType.Quest, removeCheckField="questID", 
			foldout=true, foldoutText=new string[] {
				"Quest Status Condition", "Define the quest status condition that must be valid.", ""
		})]
		public CheckQuestStatusNextNode[] questStatus = new CheckQuestStatusNextNode[0];
		
		public QuestConditionForkStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int check = this.next;
			
			for(int i=0; i<this.questStatus.Length; i++)
			{
				if(this.questStatus[i].Check())
				{
					check = this.questStatus[i].next;
					break;
				}
			}
			
			baseEvent.StepFinished(check);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1).ToString() + ": " + this.questStatus[index - 1].GetInfoText();
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.questStatus.Length + 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.questStatus[index - 1].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.questStatus[index - 1].next = next;
			}
		}
	}
	
	[ORKEditorHelp("Task Condition Fork", "Checks the status of quest tasks.\n" +
		"If a condition is valid, it's next step will be executed.\n" +
		"If no condition is valid, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Quest Steps", "Check Steps")]
	public class TaskConditionForkStep : BaseEventStep
	{
		[ORKEditorArray(false, "Add Task Condition", "Adds a new task status condition.", "", 
			"Remove", "Removes the task status condition.", "", isMove=true, isCopy=true, 
			removeType=ORKDataType.QuestTask, removeCheckField="taskID", 
			foldout=true, foldoutText=new string[] {
				"Task Status Condition", "Define the task status condition that must be valid.", ""
		})]
		public CheckQuestTaskStatusNextNode[] taskStatus = new CheckQuestTaskStatusNextNode[0];
		
		public TaskConditionForkStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int check = this.next;
			
			for(int i=0; i<this.taskStatus.Length; i++)
			{
				if(this.taskStatus[i].Check())
				{
					check = this.taskStatus[i].next;
					break;
				}
			}
			
			baseEvent.StepFinished(check);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1).ToString() + ": " + this.taskStatus[index - 1].GetInfoText();
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.taskStatus.Length + 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.taskStatus[index - 1].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.taskStatus[index - 1].next = next;
			}
		}
	}
	
	[ORKEditorHelp("Change Task Status", "Changes the status of a quest's task.\n" +
		"The quest has to be in the player's quest list.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Quest Steps")]
	public class ChangeTaskStatusStep : BaseEventStep
	{
		[ORKEditorHelp("Quest Task", "Select the quest task which's status will be changed.", "")]
		[ORKEditorInfo(ORKDataType.QuestTask)]
		public int id = 0;
		
		[ORKEditorHelp("Status", "Select the status the task will be changed to:\n" +
			"- Inactive: The task will be set inactive/removed (only possible if the task is active).\n" +
			"- Active: The task will be set active (only possible if the task is inactive).\n" +
			"- Finished: The task will be finished (only possible if the task is active).\n" +
			"- Failed: The task will fail (only possible if the task is active).", "")]
		public QuestStatusType status = QuestStatusType.Finished;
		
		[ORKEditorHelp("Show Notification", "Show the task's status change notificaiton.", "")]
		public bool showNotification = true;
		
		[ORKEditorHelp("Show Console", "Show the task's status change in the console.", "")]
		public bool showConsole = true;
		
		// finish
		[ORKEditorHelp("Get Rewards", "The quest's rewards will be collected.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("status", QuestStatusType.Finished)]
		public bool getRewards = true;
		
		[ORKEditorHelp("Check Quest Finished", "Checks if the task's quest is finished (i.e. all tasks are finished).\n" +
			"If all tasks are finished, the quest will be finished.", "")]
		public bool checkQuestFinished = false;
		
		public ChangeTaskStatusStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			QuestTask task = ORK.Game.Quests.GetTask(this.id);
			if(task != null)
			{
				if(QuestStatusType.Inactive.Equals(this.status))
				{
					task.SetInactive(ORK.Game.ActiveGroup.Leader, this.showNotification, this.showConsole);
				}
				else if(QuestStatusType.Active.Equals(this.status))
				{
					task.SetActive(ORK.Game.ActiveGroup.Leader, this.showNotification, this.showConsole);
				}
				else if(QuestStatusType.Finished.Equals(this.status))
				{
					task.SetFinished(ORK.Game.ActiveGroup.Leader, this.showNotification, this.showConsole, 
						this.getRewards, this.checkQuestFinished);
				}
				else if(QuestStatusType.Failed.Equals(this.status))
				{
					task.SetFailed(ORK.Game.ActiveGroup.Leader, this.showNotification, this.showConsole);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.QuestTasks.GetName(this.id) + ": " + this.status.ToString();
		}
	}
	
	[ORKEditorHelp("Check Task Activate", "Checks if the task's activate requirements are valid.\n" +
		"If the requirements are met, 'Success' will be executed, else 'Failed'.\n" +
		"If the task's quest isn't added to the player's quest list, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Quest Steps", "Check Steps")]
	public class CheckTaskActivateStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Quest Task", "Select the quest task that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.QuestTask)]
		public int id = 0;
		
		public CheckTaskActivateStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			QuestTask task = ORK.Game.Quests.GetTask(this.id);
			
			if(task != null && task.CheckActivate())
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.QuestTasks.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Check Task Finish", "Checks if the task's finish requirements are valid.\n" +
		"If the requirements are met, 'Success' will be executed, else 'Failed'.\n" +
		"If the task's quest isn't added to the player's quest list, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Quest Steps", "Check Steps")]
	public class CheckTaskFinishStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Quest Task", "Select the quest task that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.QuestTask)]
		public int id = 0;
		
		public CheckTaskFinishStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			QuestTask task = ORK.Game.Quests.GetTask(this.id);
			
			if(task != null && task.CheckFinish())
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.QuestTasks.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Check Task Fail", "Checks if the task's fail requirements are valid.\n" +
		"If the requirements are met, 'Success' will be executed, else 'Failed'.\n" +
		"If the task's quest isn't added to the player's quest list, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Quest Steps", "Check Steps")]
	public class CheckTaskFailStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Quest Task", "Select the quest task that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.QuestTask)]
		public int id = 0;
		
		public CheckTaskFailStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			QuestTask task = ORK.Game.Quests.GetTask(this.id);
			
			if(task != null && task.CheckFail())
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.QuestTasks.GetName(this.id);
		}
	}
}
