
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Change Rotation", "Sets or fades the rotation of a game object.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Rotation Steps")]
	public class ChangeRotationStep : BaseEventStep
	{
		// rotating object
		[ORKEditorInfo(labelText="Rotating Object")]
		public EventObjectSetting rotateObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between rotating two objects.\n" +
			"Only used if greater than 0 and more than one object will be rotated.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start rotating before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		[ORKEditorInfo(separator=true, labelText="Rotation", label=new string[] {"Axes set to 0 wont be changed."})]
		public EventVector3 rotation = new EventVector3(new Vector3(0, 90, 0));
		
		
		// fade
		[ORKEditorHelp("Fade Rotation", "The rotation is changed over time to the new rotation.\n" +
			"If disabled, the object's rotation is set to the new rotation immediately.", "")]
		[ORKEditorInfo(separator=true, labelText="Fade Settings")]
		public bool fade = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds used to rotate.", "")]
		[ORKEditorLayout("fade", true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorHelp("Wait", "Wait until the rotation has finished before the next step is executed.", "")]
		[ORKEditorLayout("waitBetween", true, endCheckGroup=true)]
		public bool wait = false;
		
		// interpolate
		[ORKEditorHelp("Interpolate", "Use interpolation to rotate the game object.\n" +
			"Interpolation enables you to set a fixed amount of degrees to rotate.\n" +
			"If disabled, the rotation is used as speed per second " +
			"(e.g. rotating Y=90 for 2 seconds would rotate the object by 180 degrees).", "")]
		public bool interpolate = false;
		
		[ORKEditorHelp("Interpolation", "The interpolation used for fading the rotation.", "")]
		[ORKEditorLayout("interpolate", true, endCheckGroup=true, endGroups=2)]
		public EaseType interpolation = EaseType.Linear;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public ChangeRotationStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.rotateObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				if(this.fade)
				{
					ActorEventRotator rotator = ComponentHelper.Get<ActorEventRotator>(this.list[this.index]);
					if(this.interpolate)
					{
						rotator.Rotation(this.list[this.index].transform, this.time, 
							this.rotation.GetValue(baseEvent), this.interpolation);
					}
					else
					{
						rotator.Rotation(this.list[this.index].transform, this.time, 
							this.rotation.GetValue(baseEvent));
					}
				}
				else
				{
					this.list[this.index].transform.eulerAngles += this.rotation.GetValue(baseEvent);
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.fade && this.wait)
					{
						baseEvent.StartTime(this.time, this.next);
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.fade ? 
				"Fade to rotation, " + this.time + "s " + (this.wait ? "(wait)" : "") : 
				"Set to rotation";
		}
	}
	
	[ORKEditorHelp("Rotate To", "Rotates a game object toward a position in world space or another game object.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Rotation Steps")]
	public class RotateToStep : BaseEventStep
	{
		// rotating object
		[ORKEditorInfo(labelText="Rotating Object")]
		public EventObjectSetting rotateObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between rotating two objects.\n" +
			"Only used if greater than 0 and more than one object will be rotated.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start rotating before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// ignore
		[ORKEditorHelp("Ignore X", "Position differences on the X-axis are ignored.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ignoreX = false;
		
		[ORKEditorHelp("Ignore Y", "Position differences on the Y-axis are ignored.", "")]
		public bool ignoreY = true;
		
		[ORKEditorHelp("Ignore Z", "Position differences on the Z-axis are ignored.", "")]
		public bool ignoreZ = false;
		
		
		// rotation target
		[ORKEditorHelp("To Object", "Use another object's position to change the rotation.", "")]
		[ORKEditorInfo(separator=true, labelText="Rotation Target")]
		public bool toObject = false;
		
		[ORKEditorLayout("toObject", true, autoInit=true)]
		public EventObjectSetting targetObject;
		
		[ORKEditorHelp("Use Center", "The center of all target objects will be used.\n" +
			"If disabled, the target object with the same index as the " +
			"moving object is used (or the first existing target object).", "")]
		public bool useCenter = false;
		
		[ORKEditorHelp("Local Space", "The offset is added in local space of the target object.", "")]
		public bool localSpace = false;
		
		[ORKEditorHelp("Offset", "The offset added to the target object.", "")]
		public Vector3 offset = Vector3.zero;
		
		[ORKEditorInfo(separator=true, labelText="Position")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public EventVector3 position = new EventVector3();
		
		
		// fade
		[ORKEditorHelp("Fade Rotation", "The rotation is changed over time to the new rotation.\n" +
			"If disabled, the object's rotation is set to the new rotation immediately.", "")]
		[ORKEditorInfo(separator=true, labelText="Fade Settings")]
		public bool fade = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds used to rotate.", "")]
		[ORKEditorLayout("fade", true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorHelp("Wait", "Wait until the rotation has finished before the next step is executed.", "")]
		[ORKEditorLayout("waitBetween", true, endCheckGroup=true)]
		public bool wait = false;
		
		[ORKEditorHelp("Interpolation", "The interpolation used for fading the rotation.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public EaseType interpolation = EaseType.Linear;
		
		
		// ingame
		private List<GameObject> list;
		
		private List<GameObject> target;
		
		private int index = 0;
		
		private GameObject centerObj;
		
		public RotateToStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.centerObj = null;
			this.list = this.rotateObject.GetObject(baseEvent);
			if(this.toObject)
			{
				this.target = this.targetObject.GetObject(baseEvent);
			}
			else
			{
				this.target = null;
			}
			this.index = 0;
			
			if(this.list.Count > 0 && (!this.toObject || this.target.Count > 0))
			{
				if(this.useCenter && this.target.Count > 0)
				{
					if(this.target.Count == 1)
					{
						this.centerObj = this.target[0];
					}
					else
					{
						this.centerObj = new GameObject("_CenterObj");
						CenterEventMover mover = this.centerObj.AddComponent<CenterEventMover>();
						mover.SetCenter(target, this.localSpace, this.offset, 
							(this.fade ? this.time : 0) + this.timeBetween * (this.list.Count - 1));
					}
				}
				
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				Vector3 pos = this.list[this.index].transform.position;
				if(this.toObject)
				{
					GameObject tObj = this.GetTarget();
					if(tObj != null)
					{
						if(this.localSpace)
						{
							pos = tObj.transform.TransformPoint(this.offset);
						}
						else
						{
							pos = tObj.transform.position + this.offset;
						}
					}
				}
				else
				{
					pos = this.position.GetValue(baseEvent);
				}
						
				if(this.ignoreX)
				{
					pos.x = this.list[this.index].transform.position.x;
				}
				if(this.ignoreY)
				{
					pos.y = this.list[this.index].transform.position.y;
				}
				if(this.ignoreZ)
				{
					pos.z = this.list[this.index].transform.position.z;
				}
						
				// rotate to
				if(this.fade)
				{
					ActorEventRotator rotator = ComponentHelper.Get<ActorEventRotator>(this.list[this.index]);
					rotator.RotateToPosition(this.list[this.index].transform, pos, this.interpolation, this.time);
				}
				// look at
				else
				{
					this.list[this.index].transform.LookAt(pos);
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.fade && this.wait)
					{
						baseEvent.StartTime(this.time, this.next);
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				if(this.centerObj != null && 
					this.centerObj != this.target[0])
				{
					if(this.wait)
					{
						GameObject.Destroy(this.centerObj, this.time);
					}
					else
					{
						GameObject.Destroy(this.centerObj);
					}
				}
				this.centerObj = null;
				this.list = null;
				this.target = null;
				this.index = 0;
			}
		}
		
		private GameObject GetTarget()
		{
			if(this.target.Count > 0)
			{
				if(this.useCenter)
				{
					return centerObj;
				}
				else
				{
					if(this.index < this.target.Count)
					{
						return this.target[this.index];
					}
					else
					{
						return this.target[0];
					}
				}
			}
			return null;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.fade ? 
				"Fade to rotation, " + this.time + "s " + (this.wait ? "(wait)" : "") : 
				"Set to rotation";
		}
	}
	
	[ORKEditorHelp("Curve Rotation", "Rotates a game object using curves.\n" +
		"The curve values are added to the game object's original rotation at the start of the step.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Rotation Steps")]
	public class CurveRotationStep : BaseEventStep
	{
		// moving object
		[ORKEditorInfo(labelText="Rotating Object")]
		public EventObjectSetting moveObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between rotating two objects.\n" +
			"Only used if greater than 0 and more than one object will be rotated.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start rotating before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		[ORKEditorHelp("Wait", "Wait until the rotation has finished before the next step is executed.", "")]
		[ORKEditorLayout("waitBetween", true, endCheckGroup=true)]
		public bool wait = false;
		
		
		// curves
		// x-axis
		[ORKEditorHelp("Rotate X-Axis", "Rotate the game object along the X-axis.", "")]
		[ORKEditorInfo(separator=true, labelText="X-Axis")]
		public bool xRotate = false;
		
		[ORKEditorHelp("X-Axis Curve", "Define the curve used for the X-axis.", "")]
		[ORKEditorLayout("xRotate", true, endCheckGroup=true, autoInit=true)]
		public AnimationCurve xCurve;
		
		// y-axis
		[ORKEditorHelp("Rotate Y-Axis", "Rotate the game object along the Y-axis.", "")]
		[ORKEditorInfo(separator=true, labelText="Y-Axis")]
		public bool yRotate = false;
		
		[ORKEditorHelp("Y-Axis Curve", "Define the curve used for the Y-axis.", "")]
		[ORKEditorLayout("yRotate", true, endCheckGroup=true, autoInit=true)]
		public AnimationCurve yCurve;
		
		// z-axis
		[ORKEditorHelp("Rotate Z-Axis", "Rotate the game object along the Z-axis.", "")]
		[ORKEditorInfo(separator=true, labelText="Z-Axis")]
		public bool zRotate = false;
		
		[ORKEditorHelp("Z-Axis Curve", "Define the curve used for the Z-axis.", "")]
		[ORKEditorLayout("zRotate", true, endCheckGroup=true, autoInit=true)]
		public AnimationCurve zCurve;
		
		
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		private float rotationTime = 0;
		
		public CurveRotationStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.moveObject.GetObject(baseEvent);
			this.index = 0;
			
			this.rotationTime = 0;
			if(this.xRotate)
			{
				this.rotationTime = Mathf.Max(this.rotationTime, this.xCurve[this.xCurve.length - 1].time);
			}
			if(this.yRotate)
			{
				this.rotationTime = Mathf.Max(this.rotationTime, this.yCurve[this.yCurve.length - 1].time);
			}
			if(this.zRotate)
			{
				this.rotationTime = Mathf.Max(this.rotationTime, this.zCurve[this.zCurve.length - 1].time);
			}
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				ActorEventRotator mover = ComponentHelper.Get<ActorEventRotator>(this.list[this.index]);
				
				mover.RotateByCurve(this.list[this.index].transform, 
					this.xRotate ? this.xCurve : null, 
					this.yRotate ? this.yCurve : null, 
					this.zRotate ? this.zCurve : null, 
					this.rotationTime);
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.wait)
					{
						baseEvent.StartTime(this.rotationTime, this.next);
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
	}
	
	[ORKEditorHelp("Check Angle", "The angle between two objects is checked against a value.\n" +
	 	"If the check is valid, 'Success' is executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Rotation Steps", "Check Steps")]
	public class CheckAngleStep : BaseEventCheckStep
	{
		[ORKEditorInfo(labelText="From Object")]
		public EventObjectSetting fromObject = new EventObjectSetting();
		
		[ORKEditorInfo(separator=true, labelText="To Object")]
		public EventObjectSetting toObject = new EventObjectSetting();
		
		[ORKEditorHelp("Check Type", "Checks if the distance is equal, not equal, less or greater than the defined distance.\n" +
			"Range inclusive checks if the value is between two defind values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true, labelText="Check")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		[ORKEditorHelp("Needed", "Either all or only one of the objects must match the defined check.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.All;
		
		[ORKEditorHelp("Use Direction", "The angle between the forward directions of the objects will be checked.\n" +
			"E.g. the angle will be 0 if both are looking into the same direction, -180/180 if they look into opposite directions.\n" +
			"If disabled, the angle between the positions will be checked.\n" +
			"E.g. the result will be 0 if 'from' looks directly at the 'to', -180/180 if he looks away from the 'to'.", "")]
		public bool direction = false;
		
		[ORKEditorInfo(separator=true, labelText="Angle")]
		public EventFloat angle = new EventFloat();
		
		[ORKEditorInfo(separator=true, labelText="Angle 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat angle2;
		
		public CheckAngleStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.DoCheck(this.fromObject.GetObject(baseEvent), 
				this.toObject.GetObject(baseEvent), this.angle.GetValue(baseEvent), 
				this.angle2 != null ? this.angle2.GetValue(baseEvent) : 0))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool DoCheck(List<GameObject> from, List<GameObject> to, float value, float value2)
		{
			bool any = false;
			for(int i=0; i<from.Count; i++)
			{
				for(int j=0; j<to.Count; j++)
				{
					if(ValueHelper.CheckVariableValue(this.direction ? 
							VectorHelper.HorizontalDirectionAngle(from[i].transform, to[j].transform) : 
							VectorHelper.HorizontalAngle(from[i].transform, to[j].transform), 
						value, value2, this.check))
					{
						if(Needed.One.Equals(needed))
						{
							return true;
						}
						else
						{
							any = true;
						}
					}
					else if(Needed.All.Equals(needed))
					{
						return false;
					}
				}
			}
			return any;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check + " " + this.angle.GetInfoText() + 
				(this.direction ? " Direction" : "");
		}
	}
	
	[ORKEditorHelp("Check Orientation", "The orientation from objects to other objects (e.g. if an object is in front of another object).\n" +
	 	"If the check is valid, 'Success' is executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Rotation Steps", "Check Steps")]
	public class CheckOrientation : BaseEventCheckStep
	{
		[ORKEditorInfo(labelText="From Object")]
		public EventObjectSetting fromObject = new EventObjectSetting();
		
		[ORKEditorInfo(separator=true, labelText="To Object")]
		public EventObjectSetting toObject = new EventObjectSetting();
		
		[ORKEditorHelp("Orientation", "Select the orientation that'll be checked for:\n" +
			"- None: The orientation is ignored (always valid).\n" +
			"- Front: The target has to be in front of the user.\n" +
			"- Back: The target has to be in the back of the user.\n" +
			"- Left: The target has to be left of the user.\n" +
			"- Right: The target has to be right of the user.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true, labelText="Check")]
		public Orientation orientation = Orientation.Front;
		
		[ORKEditorHelp("Needed", "Either all or only one of the objects must match the defined check.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.All;
		
		public CheckOrientation()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(Orientation.None.Equals(this.orientation) || 
				this.DoCheck(this.fromObject.GetObject(baseEvent), this.toObject.GetObject(baseEvent)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool DoCheck(List<GameObject> from, List<GameObject> to)
		{
			bool any = false;
			for(int i=0; i<from.Count; i++)
			{
				for(int j=0; j<to.Count; j++)
				{
					if(this.orientation.Equals(VectorHelper.GetOrientation(from[i].transform, to[j].transform)))
					{
						if(Needed.One.Equals(needed))
						{
							return true;
						}
						else
						{
							any = true;
						}
					}
					else if(Needed.All.Equals(needed))
					{
						return false;
					}
				}
			}
			return any;
		}
	}
}
