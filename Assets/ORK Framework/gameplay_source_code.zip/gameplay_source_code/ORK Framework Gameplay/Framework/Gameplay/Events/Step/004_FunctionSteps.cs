
using UnityEngine;
using ORKFramework;
using ORKFramework.Menu;
using ORKFramework.Reflection;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Send Message", "Uses Unity's SendMessage or BroadcastMessage functionality to call a defined " +
		"function (method) with a defined value in every component of a game object or any of it's children (broadcast).", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class SendMessageStep : BaseEventStep
	{
		[ORKEditorHelp("Function Name", "The name of the function that will be called.\n" +
			"The name has to be exactly as in the code!", "")]
		[ORKEditorInfo(expandWidth=true, labelText="Function Settings")]
		public string name = "";
		
		[ORKEditorHelp("Broadcast", "The function is also called on all children of the object using BroadcastMessage.", "")]
		public bool broadcast = false;
		
		
		// value
		[ORKEditorHelp("Add Parameter", "The function is called using a parameter.", "")]
		public bool addParameter = false;
		
		[ORKEditorLayout("addParameter", true, endCheckGroup=true, autoInit=true)]
		public CallParameter parameter;
		
		
		// object
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between sending a message to two objects.\n" +
			"Only used if greater than 0 and more than one object will be used.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to send a message before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public SendMessageStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.name != "")
			{
				this.list = this.onObject.GetObject(baseEvent);
				this.index = 0;
				
				if(this.list.Count > 0)
				{
					this.Continue(baseEvent);
					
					if(!this.waitBetween)
					{
						baseEvent.StepFinished(this.next);
					}
				}
				else
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				if(this.addParameter)
				{
					this.Send(this.list[this.index], this.parameter.GetValue());
				}
				else
				{
					this.Send(this.list[this.index], null);
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				this.list = null;
				this.index = 0;
			}
		}
		
		private void Send(GameObject obj, System.Object value)
		{
			if(this.broadcast)
			{
				obj.BroadcastMessage(this.name, value, SendMessageOptions.DontRequireReceiver);
			}
			else
			{
				obj.SendMessage(this.name, value, SendMessageOptions.DontRequireReceiver);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.name == "" ? "" : this.name;
		}
	}
	
	[ORKEditorHelp("Call Function", "Uses reflection to call a function in a component or " +
		"a static function of a class.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class CallFunctionStep : BaseEventStep
	{
		// component
		[ORKEditorHelp("Component Name", "The name of the component that contains the function.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Is Static", "The called function is a static function of a class.\n" +
			"It doesn't require a component attached to a game object.", "")]
		public bool isStatic = false;
		
		
		// object
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		[ORKEditorLayout("isStatic", false)]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between adding a component to two objects.\n" +
			"Only used if greater than 0 and more than one object will be used.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to add a component before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool waitBetween = true;
		
		
		// method
		[ORKEditorInfo(separator=true, labelText="Function Settings")]
		public CallMethod method = new CallMethod();
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public CallFunctionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.name != "" && this.method.functionName != "")
			{
				if(this.isStatic)
				{
					this.method.CallStatic(this.name);
					baseEvent.StepFinished(this.next);
				}
				else
				{
					this.list = this.onObject.GetObject(baseEvent);
					this.index = 0;
					
					if(this.list.Count > 0)
					{
						this.Continue(baseEvent);
						
						if(!this.waitBetween)
						{
							baseEvent.StepFinished(this.next);
						}
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				Component comp = ComponentHelper.Get(this.list[this.index], this.name);
				if(comp != null)
				{
					this.method.Call(comp);
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.isStatic ? "static " : "") + this.name + 
				(this.method.functionName == "" ? "" : "." + this.method.functionName);
		}
	}
	
	[ORKEditorHelp("Check Function", "Uses reflection to call a function in a component and check the return value.\n" +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class CheckFunctionStep : BaseEventCheckStep
	{
		// component
		[ORKEditorHelp("Component Name", "The name of the component that contains the function.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Is Static", "The called function is a static function of a class.\n" +
			"It doesn't require a component attached to a game object.", "")]
		public bool isStatic = false;
		
		
		// object
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		[ORKEditorLayout("isStatic", false, endCheckGroup=true)]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		
		// method
		[ORKEditorInfo(separator=true, labelText="Function Settings")]
		public CheckMethod method = new CheckMethod();
		
		public CheckFunctionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = false;
			if(this.name != "" && this.method.functionName != "")
			{
				if(this.isStatic)
				{
					check = this.method.CheckStatic(this.name);
				}
				else
				{
					List<GameObject> list = this.onObject.GetObject(baseEvent);
					
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							Component comp = ComponentHelper.Get(list[i], this.name);
							if(comp != null && this.method.Check(comp))
							{
								check = true;
								break;
							}
						}
					}
				}
			}
			
			if(check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.isStatic ? "static " : "") + this.name + 
				(this.method.functionName == "" ? "" : "." + this.method.functionName);
		}
	}
	
	[ORKEditorHelp("Change Fields", "Uses reflection to change fields or properties of a component.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class ChangeFieldsStep : BaseEventStep
	{
		// component
		[ORKEditorHelp("Component Name", "The name of the component that contains the fields or properties.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Is Static", "The changed fields or properties are static.\n" +
			"It doesn't require a component attached to a game object.", "")]
		public bool isStatic = false;
		
		
		// object
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("isStatic", false)]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between adding a component to two objects.\n" +
			"Only used if greater than 0 and more than one object will be used.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to add a component before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool waitBetween = true;
		
		
		// fields
		[ORKEditorInfo(separator=true, labelText="Field Settings")]
		public ChangeFields fields = new ChangeFields();
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public ChangeFieldsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.name != "" && this.fields.field.Length > 0)
			{
				if(this.isStatic)
				{
					this.fields.ChangeStatic(this.name);
					baseEvent.StepFinished(this.next);
				}
				else
				{
					this.list = this.onObject.GetObject(baseEvent);
					this.index = 0;
					
					if(this.list.Count > 0)
					{
						this.Continue(baseEvent);
						
						if(!this.waitBetween)
						{
							baseEvent.StepFinished(this.next);
						}
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				Component comp = ComponentHelper.Get(this.list[this.index], this.name);
				if(comp != null)
				{
					this.fields.Change(comp);
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			string info = (this.isStatic ? "static " : "") + this.name;
			for(int i=0; i<this.fields.field.Length; i++)
			{
				if(this.fields.field[i].fieldName != "")
				{
					info += (i == 0 ? ": " : ", ") + this.fields.field[i].fieldName;
				}
			}
			return info;
		}
	}
	
	[ORKEditorHelp("Check Fields", "Uses reflection to check the value of fields or properties of a component.\n" +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class CheckFieldsStep : BaseEventCheckStep
	{
		// component
		[ORKEditorHelp("Component Name", "The name of the component that contains the fields or properties.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Is Static", "The checked fields or properties are static.\n" +
			"It doesn't require a component attached to a game object.", "")]
		public bool isStatic = false;
		
		
		// object
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("isStatic", false, endCheckGroup=true)]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		
		// fields
		[ORKEditorInfo(separator=true, labelText="Field Settings")]
		public CheckFields fields = new CheckFields();
		
		public CheckFieldsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = false;
			if(this.name != "" && this.fields.field.Length > 0)
			{
				if(this.isStatic)
				{
					check = this.fields.CheckStatic(this.name);
				}
				else
				{
					List<GameObject> list = this.onObject.GetObject(baseEvent);
					
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							Component comp = ComponentHelper.Get(list[i], this.name);
							if(comp != null && this.fields.Check(comp))
							{
								check = true;
								break;
							}
						}
					}
				}
			}
			
			if(check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			string info = (this.isStatic ? "static " : "") + this.name;
			for(int i=0; i<this.fields.field.Length; i++)
			{
				if(this.fields.field[i].fieldName != "")
				{
					info += (i == 0 ? ": " : ", ") + this.fields.field[i].fieldName;
				}
			}
			return info;
		}
	}
	
	[ORKEditorHelp("Add Component", "Adds a defined component to a game object.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class AddComponentStep : BaseEventStep
	{
		[ORKEditorHelp("Component Name", "The name of the component that will be added.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between adding a component to two objects.\n" +
			"Only used if greater than 0 and more than one object will be used.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to add a component before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public AddComponentStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.name != "")
			{
				this.list = this.onObject.GetObject(baseEvent);
				this.index = 0;
				
				if(this.list.Count > 0)
				{
					this.Continue(baseEvent);
					
					if(!this.waitBetween)
					{
						baseEvent.StepFinished(this.next);
					}
				}
				else
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				ComponentHelper.Add(this.list[this.index], this.name);
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.name == "" ? "" : this.name;
		}
	}
	
	[ORKEditorHelp("Remove Component", "Removes a defined component from a game object.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class RemoveComponentStep : BaseEventStep
	{
		[ORKEditorHelp("Component Name", "The name of the component that will be removed.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between removing a component from two objects.\n" +
			"Only used if greater than 0 and more than one object will be used.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to remove a component before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public RemoveComponentStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.name != "")
			{
				this.list = this.onObject.GetObject(baseEvent);
				this.index = 0;
				
				if(this.list.Count > 0)
				{
					this.Continue(baseEvent);
					
					if(!this.waitBetween)
					{
						baseEvent.StepFinished(this.next);
					}
				}
				else
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				Component comp = ComponentHelper.Get(this.list[this.index], this.name);
				if(comp != null)
				{
					GameObject.Destroy(comp);
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.name == "" ? "" : this.name;
		}
	}
	
	[ORKEditorHelp("Enable Component", "Enables or disables a defined component from a game object.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class EnableComponentStep : BaseEventStep
	{
		[ORKEditorHelp("Component Name", "The name of the component that will be enabled or disabled.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Enable/Disable", "If enabled, the component will be enabled.\n" +
			"If disabled, the component will be disabled.", "")]
		public bool enable = false;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between removing a component from two objects.\n" +
			"Only used if greater than 0 and more than one object will be used.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to remove a component before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public EnableComponentStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.name != "")
			{
				this.list = this.onObject.GetObject(baseEvent);
				this.index = 0;
				
				if(this.list.Count > 0)
				{
					this.Continue(baseEvent);
					
					if(!this.waitBetween)
					{
						baseEvent.StepFinished(this.next);
					}
				}
				else
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				Component comp = ComponentHelper.Get(this.list[this.index], this.name);
				if(comp != null && comp is Behaviour)
				{
					((Behaviour)comp).enabled = this.enable;
				}
				else if(comp != null && comp is Collider)
				{
					((Collider)comp).enabled = this.enable;
				}
				else if(comp != null && comp is Collider2D)
				{
					((Collider2D)comp).enabled = this.enable;
				}
				else if(comp != null && comp is Renderer)
				{
					((Renderer)comp).enabled = this.enable;
				}
				else if(comp != null && comp is ParticleEmitter)
				{
					((ParticleEmitter)comp).enabled = this.enable;
				}
				else if(comp != null && comp is LODGroup)
				{
					((LODGroup)comp).enabled = this.enable;
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.name == "" ? "" : (this.enable ? "Enable " : "Disable ") + this.name;
		}
	}
	
	[ORKEditorHelp("Check Component Enabled", "Checks if a defined component from a game object is enabled.\n" +
		"If the component is enabled, 'Success' will be executed, else or if not found 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class CheckComponentEnableStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Component Name", "The name of the component that will be checked.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		public CheckComponentEnableStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = false;
			if(this.name != "")
			{
				List<GameObject> list = this.onObject.GetObject(baseEvent);
				
				for(int i=0; i<list.Count; i++)
				{
					Component comp = ComponentHelper.Get(list[i], this.name);
					
					if(comp != null && comp is Behaviour)
					{
						if(((Behaviour)comp).enabled)
						{
							check = true;
							break;
						}
					}
					else if(comp != null && comp is Collider)
					{
						if(((Collider)comp).enabled)
						{
							check = true;
							break;
						}
					}
					else if(comp != null && comp is Renderer)
					{
						if(((Renderer)comp).enabled)
						{
							check = true;
							break;
						}
					}
					else if(comp != null && comp is ParticleEmitter)
					{
						if(((ParticleEmitter)comp).enabled)
						{
							check = true;
							break;
						}
					}
					else if(comp != null && comp is LODGroup)
					{
						if(((LODGroup)comp).enabled)
						{
							check = true;
							break;
						}
					}
				}
			}
			
			if(check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.name;
		}
	}
	
	[ORKEditorHelp("Emit Particles", "Start or stop emitting particles on a game object and it's child objects.\n" +
		"For particles to start/stop emitting, the game object (or child objects) " +
		"need a ParticleEmitter or ParticleSystem component.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class EmitParticlesStep : BaseEventStep
	{
		[ORKEditorHelp("Emit", "If enabled, the game object will start emitting particles.\n" +
			"If disabled, the game object will stop emitting particles.", "")]
		public bool emit = false;
		
		[ORKEditorHelp("Emit After (s)", "The time in seconds to wait before start/stop emitting particles.\n" +
			"Set to 0 if particles should start/stop emitting right away.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float time = 0;
		
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between emitting particles on two objects.\n" +
			"Only used if greater than 0 and more than one object will be used.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to emit particles before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public EmitParticlesStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.onObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.time > 0)
			{
				ComponentHelper.EmitParticlesAfter(this.list[this.index], this.emit, this.time);
			}
			else
			{
				ComponentHelper.EmitParticles(this.list[this.index], this.emit);
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.emit ? "Start" : "Stop" + 
				(this.time > 0 ? " after " + this.time + "s" : "");
		}
	}
	
	[ORKEditorHelp("Activate Object", "Sets a game object active or inactive.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class ActivateObjectStep : BaseEventStep
	{
		[ORKEditorHelp("Set Active", "If enabled, the game object will be set activate.\n" +
			"If disabled, the game object will be deactivated.", "")]
		public bool setActive = false;
		
		[ORKEditorInfo(separator=true)]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between activating two objects.\n" +
			"Only used if greater than 0 and more than one object will be used.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to activate before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public ActivateObjectStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.onObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				this.list[this.index].SetActive(this.setActive);
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.setActive ? "Activate" : "Deactivate";
		}
	}
	
	[ORKEditorHelp("Object Visible", "Sets a game object visible or invisible.\n" +
		"This is done by setting every Renderer and Projector component of the game object (and all of it's children) active or inactive.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class ObjectVisibleStep : BaseEventStep
	{
		[ORKEditorHelp("Set Visible", "If enabled, the game object will be set visible.\n" +
			"If disabled, the game object will be set invisible.", "")]
		public bool setVisible = false;
		
		[ORKEditorInfo(separator=true)]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between activating two objects.\n" +
			"Only used if greater than 0 and more than one object will be used.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to activate before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public ObjectVisibleStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.onObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				Renderer[] renderers = this.list[this.index].GetComponentsInChildren<Renderer>(true);
				foreach(Renderer r in renderers)
				{
					if(r != null)
					{
						r.enabled = this.setVisible;
					}
				}
				Projector[] projectors = this.list[this.index].GetComponentsInChildren<Projector>(true);
				foreach(Projector p in projectors)
				{
					if(p != null)
					{
						p.enabled = this.setVisible;
					}
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.setVisible ? "Visible" : "Invisible";
		}
	}
	
	[ORKEditorHelp("Mount Object", "Mounts or unmounts a game object to another game object.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class MountObjectStep : BaseEventStep
	{
		[ORKEditorHelp("Mount", "If enabled, the game object will be mounted to another game object.\n" +
			"If disabled, the game object will be unmounted from it's current parent object.", "")]
		public bool mount = false;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		public EventObjectSetting useObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between mounting two objects.\n" +
			"Only used if greater than 0 and more than one object will be used.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to mount before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// target settings
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		[ORKEditorLayout("mount", true, autoInit=true)]
		public EventObjectSetting targetObject;
		
		[ORKEditorHelp("Place Object", "The game object will also be placed at the parent object when mounting it.\n" +
			"If disabled, the object will only be made a child object of the parent.", "")]
		public bool placeObject = true;
		
		[ORKEditorLayout("placeObject", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public MountSettings mountSettings;
		
		
		// ingame
		private List<GameObject> list;
		
		private List<GameObject> target;
		
		private int index = 0;
		
		public MountObjectStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.useObject.GetObject(baseEvent);
			this.target = this.mount && this.targetObject != null ? 
				this.targetObject.GetObject(baseEvent) : null;
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				// mount
				if(this.mount)
				{
					if(this.target.Count > 0)
					{
						// use index equivalent target object, if available
						if(this.index < this.target.Count)
						{
							if(this.target[this.index] != null)
							{
								if(this.placeObject)
								{
									this.mountSettings.MountTo(this.target[this.index].transform, this.list[this.index].transform);
								}
								else
								{
									this.list[this.index].transform.parent = this.target[this.index].transform;
								}
							}
						}
						// use first existing object instead
						else
						{
							GameObject obj = TransformHelper.GetFirstObject(this.target);
							if(obj != null)
							{
								if(this.placeObject)
								{
									this.mountSettings.MountTo(obj.transform, this.list[this.index].transform);
								}
								else
								{
									this.list[this.index].transform.parent = obj.transform;
								}
							}
						}
					}
				}
				// unmount
				else
				{
					this.list[this.index].transform.parent = null;
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				this.list = null;
				this.target = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.mount ? "Mount" : "Unmount";
		}
	}
	
	[ORKEditorHelp("Call Global Event", "Calls a global event.\n" +
		"The event will continue after the global event has finished.\n" +
		"If the global event can't be executed (e.g. event file not found), the next step will be executed immediately.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Function Steps")]
	public class CallGlobalEventStep : BaseEventStep
	{
		[ORKEditorHelp("Global Event", "Select the global event that will be called.", "")]
		[ORKEditorInfo(ORKDataType.GlobalEvent)]
		public int id = 0;
		
		public CallGlobalEventStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.id >= 0 && this.id < ORK.GlobalEvents.Count)
			{
				baseEvent.CallEvent(ORK.GlobalEvents.Get(this.id).eventAsset, this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.GlobalEvents.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Call Move Event", "Calls a move event and uses an object of this event as moving object.\n" +
		"The event will continue after the move event has finished.\n" +
		"If the move event can't be executed (e.g. event file not found), the next step will be executed immediately.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class CallMoveEventStep : BaseEventStep
	{
		[ORKEditorHelp("Move Event", "The ORK move event asset that will be used.", "")]
		public ORKMoveEvent eventAsset;
		
		[ORKEditorInfo(separator=true, labelText="Used Object")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		public CallMoveEventStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.eventAsset != null)
			{
				baseEvent.CallMoveEvent(this.eventAsset, this.onObject.GetObject(baseEvent), this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.eventAsset ? this.eventAsset.name : "";
		}
	}
	
	[ORKEditorHelp("Open Shop", "Opens a shop.\n" +
		"If the player buys something in the shop, 'Bought Something' is executed, else, 'Bought Nothing'.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Function Steps")]
	public class OpenShopStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Shop", "Select the shop that will be opened.", "")]
		[ORKEditorInfo(ORKDataType.Shop)]
		public int shopID = 0;
		
		[ORKEditorHelp("Scene ID", "The scene ID of the shop.\n" +
			"A scene ID is used to optionally store contents of a shop in a running game.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string sceneID = "";
		
		
		// faction settings
		[ORKEditorHelp("Use Faction", "This shop belongs to a faction and uses the faction's buy/sell price modifiers.\n" +
			"If disabled, the shop wont belong to a faction and no price modifiers are used.", "")]
		public bool useFaction = false;
		
		[ORKEditorHelp("Faction", "Select the faction the shop will belong to.", "")]
		[ORKEditorLayout("useFaction", true, endCheckGroup=true)]
		public int factionID = 0;
		
		public OpenShopStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is GameEvent)
			{
				((GameEvent)baseEvent).OpenShop(this.shopID, this.sceneID, this.useFaction ? this.factionID : -1, this.next, this.nextFail);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Shops.GetName(this.shopID) + 
				(this.sceneID != "" ? ", " + this.sceneID : "") + 
				(this.useFaction ? " (" + ORK.Factions.GetName(this.factionID) + "" : "");
		}
		
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Bought Something";
			}
			else if(index == 1)
			{
				return "Bought Nothing";
			}
			return "";
		}
	}
	
	[ORKEditorHelp("Change Area", "Change the area the player currently is in.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps", "Base Steps")]
	public class ChangeAreaStep : BaseEventStep
	{
		[ORKEditorHelp("Area Name", "Select the area that will be changed to.", "")]
		[ORKEditorInfo(ORKDataType.Area)]
		public int areaID = 0;
		
		[ORKEditorHelp("Show Notification", "Display the new area notification (as if the player stepped into it).\n" +
			"If disabled, no notification will be displayed.", "")]
		public bool show = true;
		
		public ChangeAreaStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Game.SetArea(this.areaID, this.show);
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Areas.GetName(this.areaID);
		}
	}
	
	[ORKEditorHelp("Call Menu Screen", "Calls a menu screen.\n" +
		"The event continues after the menu is closed.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Function Steps", "Base Steps")]
	public class CallMenuScreenStep : BaseEventStep
	{
		[ORKEditorHelp("Menu Screen", "Select the menu screen that will be called.", "")]
		[ORKEditorInfo(ORKDataType.MenuScreen)]
		public int screenID = 0;
		
		public CallMenuScreenStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.SetNextStep(this.next);
			ORK.MenuScreens.Get(this.screenID).Show(baseEvent);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.MenuScreens.GetName(this.screenID);
		}
	}
	
	[ORKEditorHelp("Close Menu Screen", "Closes a menu screen or all menu screens.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Function Steps", "Base Steps")]
	public class CloseMenuScreenStep : BaseEventStep
	{
		[ORKEditorHelp("Close All", "All open menu screens will be closed.\n" +
			"If disabled, only a selected menu screen will be closed.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Menu Screen", "Select the menu screen that will be called.", "")]
		[ORKEditorInfo(ORKDataType.MenuScreen)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int screenID = 0;
		
		public CloseMenuScreenStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				ORK.Menu.CloseAll();
			}
			else
			{
				MenuScreen screen = ORK.MenuScreens.Get(this.screenID);
				screen.Clear();
				screen.Close();
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? "All" : ORK.MenuScreens.GetName(this.screenID);
		}
	}
	
	[ORKEditorHelp("Start Battle", "Starts a battle - the event continues after the battle ends.\n" +
		"The selected object must either be a combatant or have a 'Battle' component " +
		"attached with a correctly set up battle.\n" +
		"Only battles between enemy factions are possible - i.e. the player can't fight an allied faction.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Function Steps", "Base Steps")]
	public class StartBattleStep : BaseEventStep
	{
		public EventObjectSetting onObject = new EventObjectSetting();
		
		public StartBattleStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<GameObject> list = this.onObject.GetObject(baseEvent);
			
			BattleComponent comp = ComponentHelper.GetInChildren<BattleComponent>(list);
			
			if(comp != null)
			{
				baseEvent.SetNextStep(this.next);
				baseEvent.DontDestroy();
				
				// unblock during battles
				if(baseEvent is GameEvent && 
					((GameEvent)baseEvent).blockingEvent)
				{
					ORK.Control.SetEventBlock(-1);
				}
				
				comp.StartEvent(baseEvent);
			}
			else
			{
				List<Combatant> combatants = ComponentHelper.GetCombatants(list);
				
				if(combatants.Count > 0)
				{
					baseEvent.SetNextStep(this.next);
					baseEvent.DontDestroy();
					
					// unblock during battles
					if(baseEvent is GameEvent && 
						((GameEvent)baseEvent).blockingEvent)
					{
						ORK.Control.SetEventBlock(-1);
					}
					
					BattleComponent.CreateBattle(combatants, baseEvent);
				}
				else
				{
					baseEvent.StepFinished(this.next);
				}
			}
		}
	}
	
	[ORKEditorHelp("Start Item Collector", "Starts an item collector - the event continues after the item collection ends.\n" +
		"The selected object must have an 'Item Collector' component attached with a correctly set up item collector.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Function Steps", "Base Steps", "Inventory Steps")]
	public class StartItemCollectorStep : BaseEventStep
	{
		public EventObjectSetting onObject = new EventObjectSetting();
		
		public StartItemCollectorStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ItemCollector comp = ComponentHelper.GetInChildren<ItemCollector>(
				this.onObject.GetObject(baseEvent));
			
			if(comp != null)
			{
				baseEvent.SetNextStep(this.next);
				comp.StartEvent(baseEvent);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
	}
	
	[ORKEditorHelp("Change Time Scale", "Changes the time scale.\n" +
		"The time scale influences the speed of everything in the game - " +
		"you can use this to create slow motion effects.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Function Steps", "Base Steps")]
	public class ChangeTimeScaleStep : BaseEventStep
	{
		[ORKEditorHelp("Time Scale", "The time scale that will be used.\n" +
			"E.g.:\n" +
			"- 1 is normal time.\n" +
			"- 0.5 is slows down time by halve.\n" +
			"- 2 quickens time by double.", "")]
		[ORKEditorLimit(0.0001f, false)]
		public float scale = 1;
		
		[ORKEditorHelp("Set ORK Scale", "Set the ORK Framework time scale - " +
			"it's used only for ORK Framework related things, like battles, events, etc.\n" +
			"If disabled, the Unity time scale will be set, affecting everything in the game.", "")]
		public bool orkScale = false;
		
		public ChangeTimeScaleStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.orkScale)
			{
				ORK.Game.TimeFactor = this.scale;
			}
			else
			{
				Time.timeScale = this.scale;
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.orkScale ? "ORK " : "Unity ") + this.scale;
		}
	}
	
	[ORKEditorHelp("Call Plugin", "Calls the 'Call' function of a selected plugin.\n" +
		"If the plugin was called successfully, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps")]
	public class CallPluginStep : BaseEventCheckStep
	{
		public CallPlugin call = new CallPlugin();
		
		public CallPluginStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.call.Call())
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Plugins.GetName(this.call.pluginID) + ": " + this.call.info;
		}
	}
	
	[ORKEditorHelp("Set Object Layer", "Sets an object's layer.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Function Steps")]
	public class SetObjectLayerStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Layer")]
		public EventFloat layer = new EventFloat();
		
		
		// object
		[ORKEditorInfo(separator=true, labelText="Object")]
		public EventObjectSetting setObject = new EventObjectSetting();
		
		[ORKEditorHelp("Set Child Objects", "Sets the layer of child objects of the selected game object.\n" +
			"If disabled, only the selected object will be set.", "")]
		public bool setChilObjects = true;
		
		public SetObjectLayerStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int tmpLayer = (int)this.layer.GetValue(baseEvent);
			
			if(tmpLayer >= 0 && tmpLayer < 32)
			{
				List<GameObject> list = this.setObject.GetObject(baseEvent);
				
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						if(this.setChilObjects)
						{
							Transform[] tmp = list[i].GetComponentsInChildren<Transform>(true);
							for(int j=0; j<tmp.Length; j++)
							{
								if(tmp[j] != null)
								{
									tmp[j].gameObject.layer = tmpLayer;
								}
							}
						}
						else
						{
							list[i].layer = tmpLayer;
						}
					}
				}
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.setObject.GetInfoText() + ": " +
				this.layer.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Check Object Layer", "Checks an object's layer.\n" +
		"If check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Function Steps", "Check Steps")]
	public class CheckObjectLayerStep : BaseEventCheckStep
	{
		[ORKEditorInfo(labelText="Layer")]
		public EventFloat layer = new EventFloat();
		
		
		// object
		[ORKEditorHelp("Needed", "Either all or only one of the objects must match the defined name or tag.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true, labelText="Check Object")]
		public Needed needed = Needed.All;
		
		public EventObjectSetting checkObject = new EventObjectSetting();
		
		public CheckObjectLayerStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.DoCheck((int)this.layer.GetValue(baseEvent), 
				this.checkObject.GetObject(baseEvent)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool DoCheck(int tmpLayer, List<GameObject> list)
		{
			bool any = false;
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(list[i].layer == tmpLayer)
					{
						if(Needed.One.Equals(needed))
						{
							return true;
						}
						else
						{
							any = true;
						}
					}
					else if(Needed.All.Equals(needed))
					{
						return false;
					}
				}
			}
			return any;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.checkObject.GetInfoText() + ": " +
				this.layer.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Add Control Component", "Adds a defined component to the player or camera control list.\n" +
		"The component will be enabled/disabled with the controls.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps", "Base Steps")]
	public class AddControlComponentStep : BaseEventStep
	{
		[ORKEditorHelp("Component Name", "The name of the component that will be added.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Blocked By", "Select when this component will be blocked:\n" +
			"- Player: When the player control is blocked.\n" +
			"- Camera: When the camera control is blocked.", "")]
		public CustomControlType blockType = CustomControlType.Player;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		public AddControlComponentStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.name != null)
			{
				List<GameObject> list = this.onObject.GetObject(baseEvent);
				
				for(int i=0; i<list.Count; i++)
				{
					Component comp = ComponentHelper.Get(list[i], this.name);
					if(comp != null && comp is Behaviour)
					{
						if(CustomControlType.Player.Equals(this.blockType))
						{
							ORK.Control.AddPlayerControl((Behaviour)comp);
						}
						else if(CustomControlType.Camera.Equals(this.blockType))
						{
							ORK.Control.AddCameraControl((Behaviour)comp);
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.blockType + ": " + this.name + 
				" on " + this.onObject.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Remove Control Component", "Removes a defined component from the player or camera control list.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Function Steps", "Base Steps")]
	public class RemoveControlComponentStep : BaseEventStep
	{
		[ORKEditorHelp("Component Name", "The name of the component that will be removed.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Blocked By", "Select when this component will be blocked:\n" +
			"- Player: When the player control is blocked.\n" +
			"- Camera: When the camera control is blocked.", "")]
		public CustomControlType blockType = CustomControlType.Player;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		public RemoveControlComponentStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.name != null)
			{
				List<GameObject> list = this.onObject.GetObject(baseEvent);
				
				for(int i=0; i<list.Count; i++)
				{
					Component comp = ComponentHelper.Get(list[i], this.name);
					if(comp != null && comp is Behaviour)
					{
						if(CustomControlType.Player.Equals(this.blockType))
						{
							ORK.Control.RemovePlayerControl((Behaviour)comp);
						}
						else if(CustomControlType.Camera.Equals(this.blockType))
						{
							ORK.Control.RemoveCameraControl((Behaviour)comp);
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.blockType + ": " + this.name + 
				" on " + this.onObject.GetInfoText();
		}
	}
}
