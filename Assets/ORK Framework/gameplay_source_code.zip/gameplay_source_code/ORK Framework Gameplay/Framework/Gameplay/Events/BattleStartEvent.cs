
using ORKFramework;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class BattleStartEvent : BaseEvent
	{
		// move AI blocks
		[ORKEditorHelp("Block Move AI", "The move AI is blocked while this event is performed.\n" +
			"The move AI will be blocked at the start of the event and unblocked at the end.", "")]
		[ORKEditorInfo("Event Settings", "Base settings of this battle start event.", "")]
		public bool blockMoveAI = false;
		
		[ORKEditorHelp("Block Actor Move AI", "The move AI of all event actors is blocked while this event is performed.\n" +
			"The move AI of all actors will be blocked at the start of the event and unblocked at the end.", "")]
		[ORKEditorLayout("blockMoveAI", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool blockActorMoveAI = false;
		
		
		// control blocks
		[ORKEditorHelp("Block Player Control", "The control of the player will be blocked during this event.\n" +
			"If disabled, the player can still be controlled - " +
			"this can interfere with some of the event steps, e.g. movement.", "")]
		[ORKEditorInfo(separator=true, labelText="Control Blocks")]
		public bool blockPlayer = false;
		
		[ORKEditorHelp("Block Camera Control", "The control of the camera will be blocked during this event.\n" +
			"If disabled, the camera can still be controlled - " +
			"this can interfere with some of the event steps, e.g. camera changes, etc..", "")]
		public bool blockCamera = false;
		
		[ORKEditorHelp("Clear Block Steps", "All 'block player/camera control' steps will be cleared at the end of the event, " +
			"i.e. each 'block' without an 'unblock' will be unblocked at the end of the event.\n" +
			"E.g.: the player control is blocked 2 times, but only unblocked 1 time - so 1 block is still remaining and will be removed.", "")]
		public bool clearBlocks = false;
		
		
		// camera settings
		[ORKEditorHelp("Use Main Camera", "The event uses the main camera.\n" +
			"If disabled, you can specify another camera to be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Camera Settings")]
		public bool mainCamera = true;
		
		[ORKEditorHelp("Find With Tag", "The camera is searched using it's tag instead of name.", "")]
		[ORKEditorLayout("mainCamera", false)]
		public bool cameraTag = false;
		
		[ORKEditorHelp("Camera Name", "The name (or tag) of the camera that will be used by this event.", "")]
		[ORKEditorInfo(expandWidth=true, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string cameraName = "";
		
		
		// prefabs
		[ORKEditorHelp("Destroy Prefabs", "All spawned prefabs will be destroyed at the end of the event.", "")]
		[ORKEditorInfo("Prefabs", "Events can spawn prefabs in the scene.", "")]
		public bool destroyPrefabs = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Prefab", "Adds a prefab to this event.", "", 
			"Remove", "Removes this prefab from the event.", "", isCopy=true, 
			foldout=true, foldoutText=new string[] {"Prefab", "Prefabs can be spawned in the scene by the event.", ""})]
		public EventPrefab[] prefab = new EventPrefab[0];
		
		
		// audio
		[ORKEditorInfo("Audio Clips", "Events can play audio clips in the scene.", "", 
			endFoldout=true)]
		[ORKEditorArray(false, "Add Audio Clip", "Adds an audio clip to this event.", "", 
			"Remove", "Removes this audio clip from the event.", "", isCopy=true, 
			foldout=true, foldoutText=new string[] {"Audio Clip", "Audio clips can be played by the event.", ""})]
		public EventAudio[] audioClip = new EventAudio[0];
		
		public BattleStartEvent()
		{
			
		}
		
		
		/*
		============================================================================
		Start/End functions
		============================================================================
		*/
		public override void StartEvent(IEventStarter s, GameObject startingObject)
		{
			if(this.step.Length > 0 && !this.executing)
			{
				this.starter = s;
				
				for(int i=0; i<this.prefab.Length; i++)
				{
					this.prefab[i].Clear();
				}
				
				ORK.Control.SetEventBlock(1);
				
				// block move AI
				if(this.blockMoveAI)
				{
					ORK.Control.SetBlockMoveAI(1);
				}
				else if(this.blockActorMoveAI)
				{
					for(int i=0; i<3; i++)
					{
						List<GameObject> list = this.GetActorObject(i);
						for(int j=0; j<list.Count; j++)
						{
							if(list[j] != null)
							{
								MoveAIComponent comp = list[j].GetComponentInChildren<MoveAIComponent>();
								if(comp != null)
								{
									comp.blocked = true;
								}
							}
						}
					}
				}
				
				// block controls
				if(this.blockPlayer)
				{
					ORK.Control.SetBlockPlayer(1, true);
				}
				if(this.blockCamera)
				{
					ORK.Control.SetBlockCamera(1, true);
				}
				
				// lock participating combatants
				this.LockCombatants(0);
				this.LockCombatants(1);
				this.LockCombatants(2);
				
				this.StartEvent();
			}
			else if(ComponentHelper.IsAlive(s))
			{
				s.EventEnded();
			}
		}
		
		protected override void EndEvent()
		{
			if(this.continueSteps.Count == 0)
			{
				this.executing = false;
				this.timeRunning = false;
				
				if(this.destroyPrefabs)
				{
					for(int i=0; i<this.prefab.Length; i++)
					{
						this.prefab[i].DestroyPrefab(-1, -1);
					}
				}
				
				// unlock participating combatants
				this.UnlockCombatants(0);
				this.UnlockCombatants(1);
				this.UnlockCombatants(2);
				
				ORK.Control.SetEventBlock(-1);
				
				// block move AI
				if(this.blockMoveAI)
				{
					ORK.Control.SetBlockMoveAI(-1);
				}
				else if(this.blockActorMoveAI)
				{
					for(int i=0; i<3; i++)
					{
						List<GameObject> list = this.GetActorObject(i);
						for(int j=0; j<list.Count; j++)
						{
							if(list[j] != null)
							{
								MoveAIComponent comp = list[j].GetComponentInChildren<MoveAIComponent>();
								if(comp != null)
								{
									comp.blocked = false;
								}
							}
						}
					}
				}
				
				// block controls
				if(this.blockPlayer)
				{
					ORK.Control.SetBlockPlayer(-1, true);
				}
				if(this.blockCamera)
				{
					ORK.Control.SetBlockCamera(-1, true);
				}
				// clear block steps
				if(this.clearBlocks)
				{
					if(this.playerBlocks > 0)
					{
						ORK.Control.SetBlockPlayer(-this.playerBlocks, true);
					}
					if(this.cameraBlocks > 0)
					{
						ORK.Control.SetBlockCamera(-this.cameraBlocks, true);
					}
				}
				
				// notify interaction
				if(ComponentHelper.IsAlive(this.starter))
				{
					this.starter.EventEnded();
				}
				
				if(this.gameOver)
				{
					ORK.Game.GameOver();
				}
				this.starter = null;
			}
			else
			{
				this.endAfterContinue = true;
			}
		}
		
		
		/*
		============================================================================
		Step functions
		============================================================================
		*/
		public override void ExecuteNextStep()
		{
			if(this.executing)
			{
				this.stepFinished = false;
				if(this.currentStep >= 0 && this.currentStep < this.step.Length)
				{
					if(this.step[this.currentStep].active && 
						(!this.stopFlag || this.step[this.currentStep].ExecuteOnStop))
					{
						this.step[this.currentStep].Execute(this);
					}
					else
					{
						this.StepFinished(this.step[this.currentStep].GetNext(0));
					}
				}
				else
				{
					this.EndEvent();
				}
			}
		}
		
		
		/*
		============================================================================
		Actor functions
		============================================================================
		*/
		public override string GetActorName(int index)
		{
			List<Combatant> list = this.GetActorCombatant(index);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					return list[i].GetName();
				}
			}
			return "";
		}
		
		public override Portrait GetActorPortrait(int index, int typeID)
		{
			List<Combatant> list = this.GetActorCombatant(index);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					Portrait portrait = list[i].GetPortrait(typeID);
					if(portrait != null)
					{
						return portrait;
					}
				}
			}
			return null;
		}
		
		public override List<GameObject> GetActorObject(int index)
		{
			List<GameObject> objList = new List<GameObject>();
			// camera
			if(index == 3)
			{
				if(this.camera != null)
				{
					objList.Add(this.camera.gameObject);
				}
			}
			// other actors
			else
			{
				List<Combatant> list = this.GetActorCombatant(index);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null && list[i].GameObject != null)
					{
						objList.Add(list[i].GameObject);
					}
				}
			}
			return objList;
		}
		
		public override List<Combatant> GetActorCombatant(int index)
		{
			if(index == 0)
			{
				return ORK.Game.ActiveGroup.GetBattle();
			}
			else if(index == 1)
			{
				return ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
					false, Range.Infinity, Consider.No, Consider.Ignore, Consider.Yes);
			}
			else if(index == 2)
			{
				return ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
					false, Range.Infinity, Consider.Yes, Consider.Ignore, Consider.Yes);
			}
			return new List<Combatant>();
		}
		
		
		/*
		============================================================================
		Waypoint functions
		============================================================================
		*/
		public override List<GameObject> GetWaypoint(int index)
		{
			List<GameObject> objList = new List<GameObject>();
			if(index == 3)
			{
				objList.Add(ORK.Battle.GetArenaCenter());
			}
			else
			{
				List<Combatant> list = this.GetActorCombatant(index);
				for(int i=0; i<list.Count; i++)
				{
					objList.Add(list[i].BattleSpot);
				}
			}
			return objList;
		}
		
		
		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public override GameObject SpawnPrefab(int index, Vector3 position, Vector3 rotation)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				return this.prefab[index].SpawnPrefab(position, rotation);
			}
			return null;
		}
		
		public override void DestroyPrefab(int index, int spawnID, float time)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				this.prefab[index].DestroyPrefab(spawnID, time);
			}
		}
		
		public override List<GameObject> GetSpawnedPrefab(int index, int spawnID)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				return this.prefab[index].GetSpawnedPrefab(spawnID);
			}
			return new List<GameObject>();
		}
		
		
		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public override AudioClip GetAudioClip(int index)
		{
			if(index >= 0 && index < this.audioClip.Length)
			{
				return this.audioClip[index].GetClip();
			}
			return null;
		}
		
		
		/*
		============================================================================
		Teleport functions
		============================================================================
		*/
		public void ChangeScene(SceneChanger sceneChanger, int next)
		{
			this.currentStep = next;
			if(sceneChanger != null)
			{
				this.DontDestroy();
				sceneChanger.SetStarter(this);
				sceneChanger.StartEvent(this.GameObject);
			}
			else
			{
				this.StepFinished(this.currentStep);
			}
		}
		
		
		/*
		============================================================================
		Camera functions
		============================================================================
		*/
		public override Transform GetCamera()
		{
			if(this.camera == null)
			{
				if(this.mainCamera)
				{
					Camera c = Camera.main;
					if(c != null)
					{
						this.camera = c.transform;
					}
				}
				else
				{
					Camera[] cams = Camera.allCameras;
					for(int i=0; i<cams.Length; i++)
					{
						if((this.cameraTag && cams[i].tag == this.cameraName) ||
							(!this.cameraTag && cams[i].name == this.cameraName))
						{
							this.camera = cams[i].transform;
							break;
						}
					}
				}
			}
			return this.camera;
		}
		
		
		/*
		============================================================================
		Call event functions
		============================================================================
		*/
		public override void CallEvent(ORKEventAsset eventAsset, int next)
		{
			// do nothing
		}
		
		
		/*
		============================================================================
		Combatant lock functions
		============================================================================
		*/
		private void LockCombatants(int index)
		{
			List<Combatant> list = this.GetActorCombatant(index);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					ORK.Game.Combatants.Lock(list[i]);
				}
			}
		}
		
		private void UnlockCombatants(int index)
		{
			List<Combatant> list = this.GetActorCombatant(index);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					ORK.Game.Combatants.Unlock(list[i]);
				}
			}
		}
	}
}
