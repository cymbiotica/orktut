
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Add Force Rigidbody", "Adds a force to a rigidbody.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Rigidbody Steps")]
	public class AddForceRigidbodyStep : BaseEventStep
	{
		// rotating object
		[ORKEditorInfo(labelText="Rigidbody Object")]
		public EventObjectSetting rigidbodyObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between adding force to two objects.\n" +
			"Only used if greater than 0 and more than one object will add force.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start adding force before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// force settings
		[ORKEditorInfo(separator=true, labelText="Force Settings")]
		[ORKEditorHelp("Use 2D", "Uses Rigidbody2D component - only X and Y axis of the force vector will be used.\n" +
			"If disabled, a normal Rigidbody (3D) component will be used.", "")]
		public bool is2D = false;
		
		[ORKEditorHelp("Relative Force", "The force is added relative to the object's coordinate system.\n" +
			"Uses 'Rigidbody.AddRelativeForce' instead of 'Rigidbody.AddForce'.", "")]
		[ORKEditorLayout("is2D", false, endCheckGroup=true)]
		public bool relativeForce = false;
		
		[ORKEditorHelp("Limit Time", "Limit the time the force is added.\n" +
			"If disabled, the force will be added to the object until it's " +
			"stopped or changed from somewhere else (e.g. other event)", "")]
		public bool limitTime = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds used to add force.", "")]
		[ORKEditorLayout("limitTime", true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorHelp("Wait", "Wait until adding force has finished before the next step is executed.", "")]
		[ORKEditorLayout("waitBetween", true, endCheckGroup=true, endGroups=2)]
		public bool wait = false;
		
		[ORKEditorInfo(separator=true, labelText="Force")]
		public EventVector3 force = new EventVector3();
		
		[ORKEditorHelp("Force Mode", "Select the force mode.", "")]
		[ORKEditorLayout("is2D", false, endCheckGroup=true)]
		public ForceMode forceMode = ForceMode.Force;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public AddForceRigidbodyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.rigidbodyObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				if(this.is2D)
				{
					Rigidbody2D rigidbody = this.list[this.index].GetComponent<Rigidbody2D>();
					if(rigidbody)
					{
						ActorEventRigidbody aer = ComponentHelper.Get<ActorEventRigidbody>(this.list[this.index]);
						aer.AddForce2D(rigidbody, this.force.GetValue(baseEvent), 
							this.limitTime ? this.time : -1);
					}
				}
				else
				{
					Rigidbody rigidbody = this.list[this.index].GetComponent<Rigidbody>();
					if(rigidbody)
					{
						ActorEventRigidbody aer = ComponentHelper.Get<ActorEventRigidbody>(this.list[this.index]);
						aer.AddForce(rigidbody, this.force.GetValue(baseEvent), 
							this.forceMode, this.relativeForce, 
							this.limitTime ? this.time : -1);
					}
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.limitTime && this.wait)
					{
						baseEvent.StartTime(this.time, this.next);
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.is2D ? "2D, " : (this.relativeForce ? "Relative, " : "")) + 
				(this.limitTime ? this.time + "s " + (this.waitBetween && this.wait ? "(wait)" : "") : "");
		}
	}
	
	[ORKEditorHelp("Add Torque Rigidbody", "Adds a torque to a rigidbody.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Rigidbody Steps")]
	public class AddTorqueRigidbodyStep : BaseEventStep
	{
		// rotating object
		[ORKEditorInfo(labelText="Rigidbody Object")]
		public EventObjectSetting rigidbodyObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between adding torque to two objects.\n" +
			"Only used if greater than 0 and more than one object will add torque.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start adding torque before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// torque settings
		[ORKEditorInfo(separator=true, labelText="Torque Settings")]
		[ORKEditorHelp("Use 2D", "Uses Rigidbody2D component.\n" +
			"If disabled, a normal Rigidbody (3D) component will be used.", "")]
		public bool is2D = false;
		
		[ORKEditorHelp("Limit Time", "Limit the time the torque is added.\n" +
			"If disabled, the torque will be added to the object until it's " +
			"stopped or changed from somewhere else (e.g. other event)", "")]
		public bool limitTime = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds used to add torque.", "")]
		[ORKEditorLayout("limitTime", true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorHelp("Wait", "Wait until adding torque has finished before the next step is executed.", "")]
		[ORKEditorLayout("waitBetween", true, endCheckGroup=true, endGroups=2)]
		public bool wait = false;
		
		[ORKEditorInfo(separator=true, labelText="Torque")]
		[ORKEditorLayout("is2D", false)]
		public EventVector3 force = new EventVector3();
		
		[ORKEditorHelp("Force Mode", "Select the force mode.", "")]
		public ForceMode forceMode = ForceMode.Force;
		
		[ORKEditorInfo(separator=true, labelText="Torque 2D")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public EventFloat torque2D = new EventFloat();
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public AddTorqueRigidbodyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.rigidbodyObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				if(this.is2D)
				{
					Rigidbody2D rigidbody = this.list[this.index].GetComponent<Rigidbody2D>();
					if(rigidbody)
					{
						ActorEventRigidbody aer = ComponentHelper.Get<ActorEventRigidbody>(this.list[this.index]);
						aer.AddTorque2D(rigidbody, this.torque2D.GetValue(baseEvent), 
							this.limitTime ? this.time : -1);
					}
				}
				else
				{
					Rigidbody rigidbody = this.list[this.index].GetComponent<Rigidbody>();
					if(rigidbody)
					{
						ActorEventRigidbody aer = ComponentHelper.Get<ActorEventRigidbody>(this.list[this.index]);
						aer.AddTorque(rigidbody, this.force.GetValue(baseEvent), this.forceMode, 
							this.limitTime ? this.time : -1);
					}
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.limitTime && this.wait)
					{
						baseEvent.StartTime(this.time, this.next);
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.is2D ? "2D, " : "") + 
				(this.limitTime ? this.time + "s " + (this.waitBetween && this.wait ? "(wait)" : "") : "");
		}
	}
	
	[ORKEditorHelp("Position Force Rigidbody", "Adds a force at a position and applies force and torque to a rigidbody.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Rigidbody Steps")]
	public class PositionForceRigidbodyStep : BaseEventStep
	{
		// rotating object
		[ORKEditorInfo(labelText="Rigidbody Object")]
		public EventObjectSetting rigidbodyObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between adding force to two objects.\n" +
			"Only used if greater than 0 and more than one object will be forced.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start adding force before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// force settings
		[ORKEditorInfo(separator=true, labelText="Force Settings")]
		[ORKEditorHelp("Use 2D", "Uses Rigidbody2D component - only X and Y axis of the force vector will be used.\n" +
			"If disabled, a normal Rigidbody (3D) component will be used.", "")]
		public bool is2D = false;
		
		[ORKEditorHelp("Limit Time", "Limit the time the force is added.\n" +
			"If disabled, the force will be added to the object until it's " +
			"stopped or changed from somewhere else (e.g. other event)", "")]
		public bool limitTime = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds used to add force.", "")]
		[ORKEditorLayout("limitTime", true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorHelp("Wait", "Wait until adding force has finished before the next step is executed.", "")]
		[ORKEditorLayout("waitBetween", true, endCheckGroup=true, endGroups=2)]
		public bool wait = false;
		
		[ORKEditorInfo(separator=true, labelText="Force")]
		public EventVector3 force = new EventVector3();
		
		[ORKEditorHelp("Force Mode", "Select the force mode.", "")]
		[ORKEditorLayout("is2D", false, endCheckGroup=true)]
		public ForceMode forceMode = ForceMode.Force;
		
		
		// force position
		[ORKEditorHelp("Use Object", "Use another object's position as the position of the force.", "")]
		[ORKEditorInfo(separator=true, labelText="Force Position")]
		public bool useObject = false;
		
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting forceObject;
		
		[ORKEditorHelp("Use Center", "The center of all force objects will be used.\n" +
			"If disabled, the force object with the same index as the " +
			"rigidbody object is used (or the first existing force object).", "")]
		public bool useCenter = false;
		
		[ORKEditorHelp("Local Space", "The offset is added in local space of the force object.", "")]
		public bool localSpace = false;
		
		[ORKEditorHelp("Offset", "The offset added to the force object's position.", "")]
		public Vector3 offset = Vector3.zero;
		
		[ORKEditorInfo(separator=true, labelText="Position")]
		[ORKEditorLayout(elseCheckGroup=true, autoInit=true)]
		public EventVector3 position;
		
		[ORKEditorHelp("Local Position", "The position is in local space of the rigidbody object.\n" +
			"If disabled, the position is in world space.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool localPosition = false;
		
		
		// ingame
		private List<GameObject> list;
		
		private List<GameObject> target;
		
		private GameObject centerObj;
		
		private int index = 0;
		
		public PositionForceRigidbodyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.rigidbodyObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.useObject)
			{
				this.target = this.forceObject.GetObject(baseEvent);
			}
			else
			{
				this.target = null;
			}
			
			if(this.list.Count > 0 && (!this.useObject || this.target.Count > 0))
			{
				if(this.target != null && this.useCenter && this.target.Count > 0)
				{
					if(this.target.Count == 1)
					{
						this.centerObj = this.target[0];
					}
					else
					{
						this.centerObj = new GameObject("_CenterObj");
						CenterEventMover mover = this.centerObj.AddComponent<CenterEventMover>();
						mover.SetCenter(this.target, this.localSpace, this.offset, this.timeBetween * (this.list.Count - 1));
					}
				}
				
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				Vector3 pos = Vector3.zero;
				if(this.useObject)
				{
					GameObject tObj = this.GetTarget();
					if(tObj != null)
					{
						if(this.localSpace)
						{
							pos = tObj.transform.TransformPoint(this.offset);
						}
						else
						{
							pos = tObj.transform.position + this.offset;
						}
					}
				}
				// set to position
				else
				{
					pos = this.localPosition ? 
						this.list[this.index].transform.TransformPoint(this.position.GetValue(baseEvent)) : 
						this.position.GetValue(baseEvent);
				}
				
				if(this.is2D)
				{
					Rigidbody2D rigidbody = this.list[this.index].GetComponent<Rigidbody2D>();
					if(rigidbody)
					{
						ActorEventRigidbody aer = ComponentHelper.Get<ActorEventRigidbody>(this.list[this.index]);
						aer.AddForceAtPosition2D(rigidbody, this.force.GetValue(baseEvent), pos, 
							this.limitTime ? this.time : -1);
					}
				}
				else
				{
					Rigidbody rigidbody = this.list[this.index].GetComponent<Rigidbody>();
					if(rigidbody)
					{
						ActorEventRigidbody aer = ComponentHelper.Get<ActorEventRigidbody>(this.list[this.index]);
						aer.AddForceAtPosition(rigidbody, this.force.GetValue(baseEvent), pos, this.forceMode, 
							this.limitTime ? this.time : -1);
					}
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		private GameObject GetTarget()
		{
			if(this.target != null && this.target.Count > 0)
			{
				if(this.useCenter)
				{
					return centerObj;
				}
				else
				{
					if(this.index < this.target.Count)
					{
						return this.target[this.index];
					}
					else
					{
						return this.target[0];
					}
				}
			}
			return null;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.is2D ? "2D, " : "") + 
				(this.useObject ? "At Object" : "");
		}
	}
	
	[ORKEditorHelp("Explosion Rigidbody", "Adds exposion force to a rigidbody.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Rigidbody Steps")]
	public class ExplosionRigidbodyStep : BaseEventStep
	{
		// rotating object
		[ORKEditorInfo(labelText="Rigidbody Object")]
		public EventObjectSetting rigidbodyObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between adding explosion force to two objects.\n" +
			"Only used if greater than 0 and more than one object will be forced.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start adding force before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// explosion settings
		[ORKEditorHelp("Force Mode", "Select the force mode.", "")]
		[ORKEditorInfo(separator=true, labelText="Explosion Settings")]
		public ForceMode forceMode = ForceMode.Force;
		
		[ORKEditorInfo(separator=true, labelText="Explosion Force")]
		public EventFloat force = new EventFloat(1000);
		
		[ORKEditorInfo(separator=true, labelText="Explosion Radius")]
		public EventFloat radius = new EventFloat(10);
		
		[ORKEditorInfo(separator=true, labelText="Upwards Modifier")]
		public EventFloat upwardsModifier = new EventFloat();
		
		
		// explosion position
		[ORKEditorHelp("Use Object", "Use another object's position as the position of the explosion.", "")]
		[ORKEditorInfo(separator=true, labelText="Explotion Position")]
		public bool useObject = false;
		
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting explosionObject;
		
		[ORKEditorHelp("Use Center", "The center of all explosion objects will be used.\n" +
			"If disabled, the explosion object with the same index as the " +
			"rigidbody object is used (or the first existing explosion object).", "")]
		public bool useCenter = false;
		
		[ORKEditorHelp("Local Space", "The offset is added in local space of the explosion object.", "")]
		public bool localSpace = false;
		
		[ORKEditorHelp("Offset", "The offset added to the explosion object's position.", "")]
		public Vector3 offset = Vector3.zero;
		
		[ORKEditorInfo(separator=true, labelText="Position")]
		[ORKEditorLayout(elseCheckGroup=true, autoInit=true)]
		public EventVector3 position;
		
		[ORKEditorHelp("Local Position", "The position is in local space of the rigidbody object.\n" +
			"If disabled, the position is in world space.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool localPosition = false;
		
		
		// ingame
		private List<GameObject> list;
		
		private List<GameObject> target;
		
		private GameObject centerObj;
		
		private int index = 0;
		
		public ExplosionRigidbodyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.rigidbodyObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.useObject)
			{
				this.target = this.explosionObject.GetObject(baseEvent);
			}
			else
			{
				this.target = null;
			}
			
			if(this.list.Count > 0 && (!this.useObject || this.target.Count > 0))
			{
				if(this.target != null && this.useCenter && this.target.Count > 0)
				{
					if(this.target.Count == 1)
					{
						this.centerObj = this.target[0];
					}
					else
					{
						this.centerObj = new GameObject("_CenterObj");
						CenterEventMover mover = this.centerObj.AddComponent<CenterEventMover>();
						mover.SetCenter(this.target, this.localSpace, this.offset, this.timeBetween * (this.list.Count - 1));
					}
				}
				
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				Rigidbody rigidbody = this.list[this.index].GetComponent<Rigidbody>();
				if(rigidbody)
				{
					Vector3 ePos = Vector3.zero;
					
					if(this.useObject)
					{
						GameObject tObj = this.GetTarget();
						if(tObj != null)
						{
							if(this.localSpace)
							{
								ePos = tObj.transform.TransformPoint(this.offset);
							}
							else
							{
								ePos = tObj.transform.position + this.offset;
							}
						}
					}
					// set to position
					else
					{
						ePos = this.localPosition ? 
							this.list[this.index].transform.TransformPoint(this.position.GetValue(baseEvent)) : 
							this.position.GetValue(baseEvent);
					}
					
					rigidbody.AddExplosionForce(
						this.force.GetValue(baseEvent), ePos, this.radius.GetValue(baseEvent), 
						this.upwardsModifier.GetValue(baseEvent), this.forceMode);
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		private GameObject GetTarget()
		{
			if(this.target != null && this.target.Count > 0)
			{
				if(this.useCenter)
				{
					return centerObj;
				}
				else
				{
					if(this.index < this.target.Count)
					{
						return this.target[this.index];
					}
					else
					{
						return this.target[0];
					}
				}
			}
			return null;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject ? "At Object" : "";
		}
	}
	
	[ORKEditorHelp("Stop Rigidbody", "Stops adding forces or torques to a rigidbody.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Rigidbody Steps")]
	public class StopRigidbodyStep : BaseEventStep
	{
		// rotating object
		[ORKEditorInfo(labelText="Rigidbody Object")]
		public EventObjectSetting rigidbodyObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between stopping on two objects.\n" +
			"Only used if greater than 0 and more than one object will be stopped.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to stop before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// torque settings
		[ORKEditorInfo(separator=true, labelText="Rigidbody Settings")]
		[ORKEditorHelp("Use 2D", "Uses Rigidbody2D component.\n" +
			"If disabled, a normal Rigidbody (3D) component will be used.", "")]
		public bool is2D = false;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public StopRigidbodyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.rigidbodyObject.GetObject(baseEvent);
			this.index = 0;
			
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				if(this.is2D)
				{
					Rigidbody2D rigidbody = this.list[this.index].GetComponent<Rigidbody2D>();
					if(rigidbody)
					{
						ActorEventRigidbody aer = ComponentHelper.Get<ActorEventRigidbody>(this.list[this.index]);
						aer.Stop();
					}
				}
				else
				{
					Rigidbody rigidbody = this.list[this.index].GetComponent<Rigidbody>();
					if(rigidbody)
					{
						ActorEventRigidbody aer = ComponentHelper.Get<ActorEventRigidbody>(this.list[this.index]);
						aer.Stop();
					}
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.is2D ? "2D" : "";
		}
	}
}
