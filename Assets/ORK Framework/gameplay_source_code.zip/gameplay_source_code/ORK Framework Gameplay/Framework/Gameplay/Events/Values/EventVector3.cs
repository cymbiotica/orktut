
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class EventVector3 : BaseData
	{
		[ORKEditorHelp("Value Type", "Select where the Vector3 value comes from:\n" +
			"- Value: A defined value.\n" +
			"- Game Variable: The value of a game variable (Vector3).\n" +
			"- Scene Position: The scene position of the current scene (or if not set: 0, 0, 0).\n" +
			"- Player Position: The current position of the player.\n" +
			"- Random: A randomly generated value between defined min/max values for each axis.", "")]
		public Vector3ValueType type = Vector3ValueType.Value;
		
		
		// value
		[ORKEditorHelp("Value", "The Vector3 value that will be used.", "")]
		[ORKEditorLayout("type", Vector3ValueType.Value, endCheckGroup=true)]
		public Vector3 value = Vector3.zero;
		
		
		// variable
		[ORKEditorHelp("Variable Origin", "Select the origin of the variable:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorLayout("type", Vector3ValueType.GameVariable)]
		public VariableOrigin origin = VariableOrigin.Global;
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		// variable key
		[ORKEditorHelp("Variable Key (Vector3)", "The key (name) of the game variable (Vector3) that contains the value.", "")]
		[ORKEditorInfo(expandWidth=true, isVariableField=true)]
		[ORKEditorLayout(endCheckGroup=true, setDefault=true, defaultValue="")]
		public string variableKey = "";
		
		
		// random
		[ORKEditorHelp("X Minimum", "The minimum random value on the X-axis.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", Vector3ValueType.Random)]
		public float xMin = 0;
		
		[ORKEditorHelp("X Maximum", "The maximum random value on the X-axis.", "")]
		public float xMax = 0;
		
		[ORKEditorHelp("Y Minimum", "The minimum random value on the Y-axis.", "")]
		[ORKEditorInfo(separator=true)]
		public float yMin = 0;
		
		[ORKEditorHelp("Y Maximum", "The maximum random value on the Y-axis.", "")]
		public float yMax = 0;
		
		[ORKEditorHelp("Z Minimum", "The minimum random value on the Z-axis.", "")]
		[ORKEditorInfo(separator=true)]
		public float zMin = 0;
		
		[ORKEditorHelp("Z Maximum", "The maximum random value on the Z-axis.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float zMax = 0;
		
		public EventVector3()
		{
			
		}
		
		public EventVector3(Vector3 value)
		{
			this.value = value;
		}
		
		public Vector3 GetValue(BaseEvent baseEvent)
		{
			if(Vector3ValueType.Value.Equals(this.type))
			{
				return this.value;
			}
			else if(Vector3ValueType.GameVariable.Equals(this.type))
			{
				if(VariableOrigin.Local.Equals(this.origin))
				{
					return baseEvent.Variables.GetVector3(this.variableKey);
				}
				else if(VariableOrigin.Global.Equals(this.origin))
				{
					return ORK.Game.Variables.GetVector3(this.variableKey);
				}
				else if(VariableOrigin.Object.Equals(this.origin))
				{
					if(this.useObject)
					{
						List<GameObject> list = this.fromObject.GetObject(baseEvent);
						for(int i=0; i<list.Count; i++)
						{
							if(list[i] != null)
							{
								ObjectVariablesComponent[] comps = list[i].
									GetComponentsInChildren<ObjectVariablesComponent>();
								if(comps.Length > 0)
								{
									return comps[0].GetHandler().GetVector3(this.variableKey);
								}
							}
						}
					}
					else
					{
						return ORK.Game.Scene.GetObjectVariables(this.objectID).GetVector3(this.variableKey);
					}
				}
			}
			else if(Vector3ValueType.ScenePosition.Equals(this.type))
			{
				SceneTarget st = ORK.Game.Scene.GetScenePosition(Application.loadedLevelName);
				if(st != null)
				{
					return st.position;
				}
			}
			else if(Vector3ValueType.PlayerPosition.Equals(this.type) && ORK.Game.GetPlayer() != null)
			{
				return ORK.Game.GetPlayer().transform.position;
			}
			else if(Vector3ValueType.Random.Equals(this.type))
			{
				return new Vector3(
					Random.Range(this.xMin, this.xMax), 
					Random.Range(this.yMin, this.yMax), 
					Random.Range(this.zMin, this.zMax));
			}
			return Vector3.zero;
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(Vector3ValueType.Value.Equals(this.type))
			{
				return this.value.ToString();
			}
			else if(Vector3ValueType.GameVariable.Equals(this.type))
			{
				return this.variableKey + " (" + this.origin + ")";
			}
			else if(Vector3ValueType.Random.Equals(this.type))
			{
				return "(" + this.xMin + "~" + this.xMax + ", " + 
					this.yMin + "~" + this.yMax + ", " + 
					this.zMin + "~" + this.zMax + ")";
			}
			else
			{
				return this.type.ToString();
			}
		}
	}
}
