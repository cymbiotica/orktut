
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public interface IEventStarter
	{
		void EventEnded();
		
		void DontDestroy();
		
		GameObject GameObject
		{
			get;
		}
	}
}
