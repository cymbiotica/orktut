
using UnityEngine;
using ORKFramework.Events;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GameOverChoice : BaseData, IChoice, IEventStarter
	{
		[ORKEditorHelp("Load Scene", "The scene that will be loaded when the player group is defeated and game over is called.\n" +
			"Leave blank if no scene should be loaded.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string scene = "";
		
		
		// auto game over
		[ORKEditorHelp("Auto Game Over", "Automatically call game over in the field or in " +
			"'Real Time Battle Areas' when the player or player group is dead.", "")]
		[ORKEditorInfo(separator=true, labelText="Field/Real Time Area Settings")]
		[ORKEditorLayout("scene", "", elseCheckGroup=true)]
		public bool fieldAuto = false;
		
		[ORKEditorHelp("Battle Group Dead", "All members of the battle group must be dead for auto game over.\n" +
			"If disabled, only the leader (i.e. the player combatant) must be dead for auto game over.", "")]
		[ORKEditorLayout("fieldAuto", true, endCheckGroup=true)]
		public bool autoGroupDead = true;
		
		
		// screen fade out
		[ORKEditorHelp("Fade Out", "The screen will fade out.", "")]
		[ORKEditorInfo("Fade Out Screen", "The screen can fade out when loading the game over scene.", "", separatorForce=true)]
		public bool useFadeOut = true;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useFadeOut", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings fadeOut = new FadeColorSettings(0.5f, 0, 1);
		
		[ORKEditorHelp("Fade In", "The screen will fade in.", "")]
		[ORKEditorInfo("Fade In Screen", "The screen can fade in after loading the game over scene.", "")]
		public bool useFadeIn = true;
		
		[ORKEditorLayout("useFadeIn", true, endCheckGroup=true, autoInit=true, endGroups=2)]
		[ORKEditorInfo(endFoldout=true)]
		public FadeColorSettings fadeIn = new FadeColorSettings(0.5f, 1, 0);
		
		
		// wait time
		[ORKEditorHelp("Wait Time (s)", "The time in seconds that will be waited before " +
			"showing the choice or loading the main menu scene.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorInfo(separator=true)]
		public float waitTime = 1;
		
		
		// choice
		[ORKEditorHelp("Show Choice", "A game over choice dialogue will be displayed.\n" +
			"You can select between retry, load and exit options.", "")]
		[ORKEditorInfo(separator=true, labelText="Game Over Choice")]
		public bool showChoice = false;
		
		[ORKEditorHelp("GUI Box", "The GUI box used to display the choice dialogue.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("showChoice", true)]
		public int guiBoxID = 0;
		
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		// message
		[ORKEditorHelp("Message", "The message displayed in the choice dialogue.\n" +
			"Can be defined in all languages - leave blank if no message should be displayed.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Message")]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		public string[] message = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// retry button
		[ORKEditorHelp("Show Retry", "A retry option will be displayed in the choice dialogue.\n" +
			"Selecting this option will load the last retry save game. " +
			"If no retry save game is available it will load the last saved (or loaded) save game.\n" +
			"The name of the button can be defined in all languages and have an icon.", "")]
		[ORKEditorInfo("Retry Button", "Define the retry button.", "")]
		public bool showRetry = true;
		
		[ORKEditorInfo(labelText="Set Game Variables on Retry")]
		[ORKEditorLayout("showRetry", true)]
		public VariableSetter variableSetter = new VariableSetter();
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageContent[] retryButton = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Retry"});
		
		
		// load button
		[ORKEditorHelp("Show Load", "A load option will be displayed in the choice dialogue.\n" +
			"Selecting this option will call the load menu.\n" +
			"The name of the button can be defined in all languages and have an icon.", "")]
		[ORKEditorInfo("Load Button", "Define the load button.", "")]
		public bool showLoad = true;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("showLoad", true, endCheckGroup=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageContent[] loadButton = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Load"});
		
		
		// exit button
		[ORKEditorHelp("Show Exit", "An exit option will be displayed in the choice dialogue.\n" +
			"Selecting this option will load the main menu scene.\n" +
			"The name of the button can be defined in all languages and have an icon.", "")]
		[ORKEditorInfo("Exit Button", "Define the exit button.", "")]
		public bool showExit = true;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("showExit", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageContent[] exitButton = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Exit"});
		
		
		// choices
		private GUIBox box;
		
		private int current = -1;
		
		private ChoiceContent[] choices;

		private int[] choiceActions;
		
		private static int RETRY_INDEX = 0;

		private static int LOAD_INDEX = 1;

		private static int EXIT_INDEX = 2;
		
		public GameOverChoice()
		{
			
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Scene functions
		============================================================================
		*/
		public void LoadScene()
		{
			ORK.Control.SetBlockControl(1, true);
			ORK.Game.Running = false;
			if(this.scene != "")
			{
				SceneChanger changer = new GameObject().AddComponent<SceneChanger>();
				if(changer != null)
				{
					changer.target = new SceneTarget[] {new SceneTarget(this.scene, -1)};
					changer.useFadeOut = this.useFadeOut;
					changer.fadeOut = this.fadeOut;
					changer.useFadeIn = this.useFadeIn;
					changer.fadeIn = this.fadeIn;
					changer.SetStarter(this);
					changer.StartEvent(this.GameObject);
				}
				else
				{
					this.EventEnded();
				}
			}
			else
			{
				this.EventEnded();
			}
		}
		
		public void EventEnded()
		{
			ORK.Game.CallGameOverChoice();
		}

		public void DontDestroy()
		{
			
		}
		
		public GameObject GameObject
		{
			get{ return null;}
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show()
		{
			this.box = ORK.GUIBoxes.Create(this.guiBoxID);
			this.CreateChoices();
			this.box.Content = new DialogueContent(this.message[ORK.Game.Language], 
				this.useTitle ? this.title[ORK.Game.Language] : "", this.choices, this);
			this.box.InitIn();
			ORK.GUI.FocusBlocked = true;
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		public void Closed(GUIBox origin)
		{
			this.box = null;
			if(this.current == GameOverChoice.RETRY_INDEX)
			{
				ORK.SaveGame.Load(SaveGameHandler.RETRY_INDEX);
				this.variableSetter.SetVariables();
			}
			else if(this.current == GameOverChoice.LOAD_INDEX)
			{
				ORK.SaveGameMenu.loadMenu.Show(this, null);
			}
			else if(this.current == GameOverChoice.EXIT_INDEX)
			{
				ORK.Game.LoadMainMenuScene();
			}
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void CreateChoices()
		{
			List<ChoiceContent> cc = new List<ChoiceContent>();
			List<int> ca = new List<int>();
			if(this.showRetry)
			{
				cc.Add(new ChoiceContent(this.retryButton[ORK.Game.Language].GetContent(),
					ORK.SaveGame.RetryAvailable()));
				ca.Add(GameOverChoice.RETRY_INDEX);
			}
			if(this.showLoad)
			{
				cc.Add(new ChoiceContent(this.loadButton[ORK.Game.Language].GetContent(),
					ORK.SaveGame.FileExists()));
				ca.Add(GameOverChoice.LOAD_INDEX);
			}
			if(this.showExit)
			{
				cc.Add(new ChoiceContent(this.exitButton[ORK.Game.Language].GetContent()));
				ca.Add(GameOverChoice.EXIT_INDEX);
			}
			this.choices = cc.ToArray();
			this.choiceActions = ca.ToArray();
		}
		
		public void ChoiceSelected(int index, GUIBox origin)
		{
			this.current = this.choiceActions[index];
			this.box.InitOut();
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}
		
		public void Canceled(GUIBox origin)
		{
			
		}
	}
}
