
using UnityEngine;

namespace ORKFramework
{
	public interface IDragOrigin
	{
		void Dropped(DragInfo drag);
		
		bool DroppedOnCombatant(Combatant c, DragInfo drag);
		
		bool DroppedToWorld(Vector3 position, DragInfo drag);
	}
}
