
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ShortcutPositionSetting : BaseData
	{
		[ORKEditorHelp("Position", "Define the position of this cell.\n" +
			"The position is defined with in the HUD element's bounds, " +
			"i.e. X=0, Y=0 is located in the upper left corner of the bounds.", "")]
		public Vector2 position = Vector2.zero;
		
		[ORKEditorHelp("Cell Anchor", "Select the anchor of the cell.", "")]
		public TextAnchor anchor = TextAnchor.MiddleCenter;
		
		
		// size
		[ORKEditorHelp("Set Size", "Set the size of the cell.", "")]
		public bool setSize = false;
		
		[ORKEditorHelp("Size", "Define the width (X) and height (Y) of the cell.", "")]
		[ORKEditorLayout("setSize", true, endCheckGroup=true)]
		public Vector2 size = new Vector2(50, 50);
		
		
		// index
		[ORKEditorHelp("Set Slot Index", "Set the shortcut index this cell will display.\n" +
			"If disabled, the start index + cell index will be used " +
			"(e.g. start index 1 and cell index 3 will display shortcut slot 4).", "")]
		public bool setSlotIndex = false;
		
		[ORKEditorHelp("Slot Index", "Define the index of the shortcut slot that will be displayed by this cell.", "")]
		[ORKEditorLayout("setSlotIndex", true, endCheckGroup=true)]
		public int slotIndex = 0;
		
		public ShortcutPositionSetting()
		{
			
		}
	}
}
