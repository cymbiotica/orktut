
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleRange : BaseData
	{
		[ORKEditorLimit(0.0f, false)]
		public Range maxDistance = new Range(20);
		
		[ORKEditorHelp("Show Player Group", "Console texts from the player group will always be displayed " +
			"and ignore the distance setting.\n" +
			"If disabled, the player group members will also be checked for distance to the player (leader of the group).", "")]
		[ORKEditorInfo(separator=true)]
		public bool alwaysPlayerGroup = true;
		
		public ConsoleRange()
		{
			
		}
		
		public bool InRange(Combatant user)
		{
			return user != null && 
				((this.alwaysPlayerGroup && user.Group == ORK.Game.ActiveGroup) || 
				this.maxDistance.InRange(user, ORK.Game.ActiveGroup.Leader));
		}
	}
}
