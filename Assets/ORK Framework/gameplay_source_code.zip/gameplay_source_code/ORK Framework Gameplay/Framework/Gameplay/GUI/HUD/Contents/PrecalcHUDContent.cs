
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class PrecalcHUDContent : GUIBoxContent
	{
		public HUDType type = HUDType.Information;
		
		private HUDElement[] element;
		
		private Combatant combatant;
		
		private bool doFlash = false;
		
		private HUDSetting hudSetting;
		
		
		// created content
		private MultiHUDContent[] content;
		
		private bool autoUpdate = false;
		
		private float updateInterval = 0;
		
		private float updateTime = 0;
		
		private bool markUpdate = false;
		
		
		// portrait
		private int portraitTypeID = -1;
		
		public PortraitPosition setPortraitPosition;
		
		private Portrait portrait;
		
		private PortraitPosition portraitPosition;
		
		
		// new UI
		private GameObject bgObject;
		
		private GameObject fgObject;
		
		public PrecalcHUDContent(HUDSetting setting)
		{
			this.hudSetting = setting;
			this.type = setting.type;
			
			if(HUDType.Information.Equals(setting.type))
			{
				this.element = setting.infoElement;
				
				if(setting.autoUpdate)
				{
					this.SetAutoUpdate(setting.updateInterval);
				}
			}
			else if(HUDType.Interaction.Equals(setting.type))
			{
				this.element = setting.interactionElement;
			}
			else if(HUDType.Combatant.Equals(setting.type) || 
				HUDType.TurnOrder.Equals(setting.type))
			{
				this.element = setting.combatantElement;
				this.doFlash = !setting.noFlash;
				if(setting.showPortrait)
				{
					this.portraitTypeID = setting.portraitTypeID;
					
					if(setting.ownPortraitPosition)
					{
						this.setPortraitPosition = setting.portraitPosition;
					}
				}
			}
			else if(HUDType.Tooltip.Equals(setting.type))
			{
				this.element = setting.tooltipElement;
				if(ORK.GUI != null)
				{
					ORK.GUI.UpdateHUD += this.Recalculate;
				}
			}
			else if(HUDType.Quest.Equals(setting.type))
			{
				this.element = setting.questElement;
				if(ORK.Game != null && ORK.Game.Quests != null)
				{
					ORK.Game.Quests.Changed += this.Recalculate;
				}
			}
			
			this.newContent = true;
		}
		
		public PrecalcHUDContent(HUDElement[] e, HUDType t)
		{
			this.element = e;
			this.type = t;
		}
		
		public override void Clear()
		{
			base.Clear();
			if(this.bgObject != null)
			{
				GameObject.Destroy(this.bgObject);
			}
			if(this.fgObject != null)
			{
				GameObject.Destroy(this.fgObject);
			}
		}
		
		public Combatant Combatant
		{
			get{ return this.combatant;}
			set
			{
				if(this.combatant != value)
				{
					if(Application.isPlaying)
					{
						if(this.combatant != null && 
							(HUDType.Combatant.Equals(this.type) || HUDType.TurnOrder.Equals(this.type)))
						{
							this.combatant.UpdateHUD -= this.Recalculate;
							ORK.GUI.UpdateHUD -= this.Recalculate;
						}
						this.combatant = value;
						if(this.combatant != null && 
							(HUDType.Combatant.Equals(this.type) || HUDType.TurnOrder.Equals(this.type)))
						{
							this.combatant.UpdateHUD += this.Recalculate;
							ORK.GUI.UpdateHUD += this.Recalculate;
						}
					}
					else
					{
						this.combatant = value;
					}
					
					this.portrait = null;
					this.portraitPosition = null;
					this.newContent = true;
				}
			}
		}

		public override void Tick()
		{
			base.Tick();
			if(this.box != null)
			{
				if(this.autoUpdate)
				{
					this.updateTime -= ORK.Core.GUITimeDelta;
					if(this.updateTime <= 0)
					{
						this.markUpdate = true;
						this.updateTime = this.updateInterval;
					}
				}
				
				if(this.markUpdate)
				{
					this.newContent = true;
					this.markUpdate = false;
				}
				
				// interface tick
				if(this.box.Controlable && this.controlInterface != null && this.box.Focused)
				{
					this.controlInterface.Tick(this.box);
				}
				
				// flash
				if(this.doFlash)
				{
					if(this.combatant != null && this.combatant.IsHUDFade())
					{
						this.box.flashColor = this.combatant.HUDColor;
						this.box.doFlash = true;
					}
					else
					{
						this.box.doFlash = false;
					}
				}
			}
		}
		
		public override void Closed()
		{
			if(this.combatant != null && Application.isPlaying)
			{
				this.combatant.UpdateHUD -= this.Recalculate;
				ORK.GUI.UpdateHUD -= this.Recalculate;
			}
			this.combatant = null;
			if(this.controlInterface != null)
			{
				this.controlInterface.Closed(this.box);
			}
		}
		
		public void SetAutoUpdate(float interval)
		{
			this.autoUpdate = interval > 0;
			this.updateInterval = interval;
			this.updateTime = interval;
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public override void Init(GUIBox box)
		{
			if(this.newContent)
			{
				this.box = box;
				this.newContent = false;
				this.markUpdate = false;
				
				this.CalculateContent(this.box.bounds.width - 
					(this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), false);
				
				if(this.portraitTypeID >= 0 && this.portrait == null && this.combatant != null)
				{
					this.portrait = this.combatant.GetPortrait(this.portraitTypeID);
					
					if(this.portrait != null && this.portrait.image != null)
					{
						this.portrait.image.wrapMode = TextureWrapMode.Clamp;
						
						if(this.setPortraitPosition != null)
						{
							this.portraitPosition = this.setPortraitPosition;
						}
						else if(this.portrait.ownPortraitPosition)
						{
							this.portraitPosition = this.portrait.portraitPosition;
						}
						else if(this.box.Settings.ownPortraitPosition)
						{
							this.portraitPosition = this.box.Settings.portraitPosition;
						}
						else
						{
							this.portraitPosition = ORK.MenuSettings.portraitPosition;
						}
					}
				}
			}
		}
		
		private void CalculateContent(float baseWidth, bool recalced)
		{
			if(this.content == null)
			{
				this.content = new MultiHUDContent[this.element != null ? this.element.Length : 0];
			}
			
			float contentHeight = 0;
			
			bool any = false;
			if(this.element != null)
			{
				for(int i=0; i<this.element.Length; i++)
				{
					if(this.content[i] == null)
					{
						this.content[i] = new MultiHUDContent(this.element[i]);
					}
					
					if(HUDType.Interaction.Equals(this.type))
					{
						this.content[i].UpdateContent(this.hudSetting.interaction);
					}
					else
					{
						this.content[i].UpdateContent(this.combatant);
					}
					
					if(this.content[i].label != null || 
						(this.hudSetting != null && this.hudSetting.emptyElements))
					{
						any = true;
						if(contentHeight < this.element[i].bounds.y + this.content[i].bounds.height)
						{
							contentHeight = this.element[i].bounds.y + this.content[i].bounds.height;
						}
					}
				}
			}
			
			if(this.hudSetting != null && this.hudSetting.hideEmptyHUD)
			{
				this.box.hidden = !any;
			}
			
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
				!this.box.forceSize)
			{
				this.box.bounds.height = contentHeight + this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
				
				if(this.box.Settings.useAutoMinHeight && 
					this.box.bounds.height < this.box.Settings.boxBounds.height)
				{
					this.box.bounds.height = this.box.Settings.boxBounds.height;
				}
			}
			else if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				this.scrollRect = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
					baseWidth, contentHeight);
			}
			
			this.contentBounds = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
				this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			if(!recalced && contentHeight > this.contentBounds.height && 
				BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				float scrollbarWidth = 0;
				if(ORK.GUI.IsNewUI)
				{
					if(this.box.Skins.scrollbarPrefab != null)
					{
						RectTransform rect = this.box.Skins.scrollbarPrefab.GetComponent<RectTransform>();
						if(rect != null)
						{
							scrollbarWidth = rect.sizeDelta.x;
						}
					}
				}
				else
				{
					scrollbarWidth = GUI.skin.verticalScrollbar.fixedWidth;
				}
				this.CalculateContent(baseWidth - (scrollbarWidth + this.box.Settings.scrollPadding), true);
			}
		}
		
		public override void CreateNewUI()
		{
			if(ORK.GUI.IsNewUI && 
				this.box.gameObject != null)
			{
				GameObject parent = this.UpdatePanel();
				
				// create
				int index = 0;
				if(this.labelObject == null)
				{
					this.labelObject = new List<RectTransform>();
				}
				else
				{
					for(int i=0; i<this.labelObject.Count; i++)
					{
						if(this.labelObject[i] == null)
						{
							this.labelObject.RemoveAt(i--);
						}
						else
						{
							this.labelObject[i].SetParent(null, false);
						}
					}
				}
				
				// display content
				for(int i=0; i<this.content.Length; i++)
				{
					this.content[i].CreateObjects(this.box, parent, this.labelObject, ref index);
				}
				
				// update labels
				for(int i=0; i<this.labelObject.Count; i++)
				{
					// remove empty
					if(this.labelObject[i] == null)
					{
						this.labelObject.RemoveAt(i--);
					}
					// remove exceeding labels
					else if(i >= index)
					{
						GameObject.Destroy(this.labelObject[i].gameObject);
						this.labelObject.RemoveAt(i--);
					}
				}
				
				// background image
				if(this.hudSetting != null && this.bgObject == null && 
					this.hudSetting.showBackground && this.hudSetting.bgImage != null)
				{
					this.bgObject = this.CreateImage(this.hudSetting.bgImage, 
						this.hudSetting.bgRelative, this.hudSetting.bgRelativeTo, 0);
				}
				// foreground image
				if(this.hudSetting != null && this.fgObject == null && 
					this.hudSetting.showForeground && this.hudSetting.fgImage != null)
				{
					this.fgObject = this.CreateImage(this.hudSetting.fgImage, 
						this.hudSetting.fgRelative, this.hudSetting.fgRelativeTo, 1);
				}
				
				// portrait
				this.CreatePortraitObject(this.portrait, this.portraitPosition);
				
				this.box.uiComponent.UpdateColors();
			}
		}
		
		public void Recalculate()
		{
			this.markUpdate = true;
		}
		
		
		/*
		============================================================================
		Show GUI functions
		============================================================================
		*/
		public override void ShowBefore()
		{
			// background image
			if(this.hudSetting != null && 
				this.hudSetting.showBackground && this.hudSetting.bgImage != null)
			{
				if(this.hudSetting.bgRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.box.windowRect, this.hudSetting.bgRelativeTo);
					this.hudSetting.bgImage.Show(tmp.x, tmp.y);
				}
				else
				{
					this.hudSetting.bgImage.Show();
				}
			}
			// portrait
			if(this.portrait != null && this.portrait.image != null && 
				this.portraitPosition != null && PortraitBoxPosition.Behind.Equals(this.portraitPosition.boxPosition))
			{
				this.portraitPosition.Show(this.portrait, this.box.windowRect);
			}
		}
		
		public override void ShowAfter()
		{
			// foreground image
			if(this.hudSetting != null && 
				this.hudSetting.showForeground && this.hudSetting.fgImage != null)
			{
				if(this.hudSetting.fgRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.box.windowRect, this.hudSetting.fgRelativeTo);
					this.hudSetting.fgImage.Show(tmp.x, tmp.y);
				}
				else
				{
					this.hudSetting.fgImage.Show();
				}
			}
			// portrait
			if(this.portrait != null && this.portrait.image != null && 
				this.portraitPosition != null && PortraitBoxPosition.InFront.Equals(this.portraitPosition.boxPosition))
			{
				this.portraitPosition.Show(this.portrait, this.box.windowRect);
			}
		}

		public override void ShowWindow()
		{
			if(this.box.doFlash)
			{
				GUI.color = this.box.flashColor;
			}
			else
			{
				GUI.color = this.box.color;
			}
			
			GUIStyle textStyle = new GUIStyle(GUI.skin.label);
			textStyle.wordWrap = false;
			
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.skin.horizontalScrollbar = GUIStyle.none;
				this.scroll = GUI.BeginScrollView(this.contentBounds, this.scroll, this.scrollRect);
				GUI.BeginGroup(this.scrollRect);
			}
			else
			{
				GUI.BeginGroup(this.contentBounds);
			}
			
			// within box potrait
			if(this.portrait != null && this.portrait.image != null && 
				this.portraitPosition != null && PortraitBoxPosition.Within.Equals(this.portraitPosition.boxPosition))
			{
				this.portraitPosition.Show(this.portrait, this.box.windowRect);
			}
			
			// display content
			for(int i=0; i<this.content.Length; i++)
			{
				if(this.content[i].label != null || 
					(this.hudSetting != null && this.hudSetting.emptyElements))
				{
					// no flash > reset color
					this.box.SetGUIColor(this.content[i].setting.noFlash);
					
					// show
					this.content[i].Show(textStyle);
					this.box.SetGUIColor(false);
				}
			}
			
			GUI.EndGroup();
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.EndScrollView();
			}
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public override ChoiceContent GetDragOnPosition(Vector2 position)
		{
			// interaction HUD click
			if(HUDType.Interaction.Equals(this.type) && 
				this.hudSetting != null && this.hudSetting.interactClick)
			{
				GameObject obj = ORK.Game.GetPlayer();
				if(obj != null)
				{
					InteractionController ic = obj.transform.root.GetComponentInChildren<InteractionController>();
					if(ic != null)
					{
						this.hudSetting.interaction.Interact(ic);
					}
				}
			}
			// combatant HUD shortcut drag
			else if(HUDType.Combatant.Equals(this.type))
			{
				position.x -= this.box.windowRect.x + this.box.Settings.boxPadding.x;
				position.y -= this.box.windowRect.y + this.box.Settings.boxPadding.y;
				if(this.content != null)
				{
					for(int i=0; i<this.content.Length; i++)
					{
						ChoiceContent cc = this.content[i].setting.GetDragOnPosition(this.combatant, position);
						if(cc != null)
						{
							if(cc.drag != null)
							{
								cc.drag.BoxOrigin = this.box;
							}
							return cc;
						}
					}
				}
			}
			return null;
		}
		
		public override bool CheckDrop(DragInfo drag, Vector2 position)
		{
			if(this.hudSetting != null && this.InBox(position) && 
				(HUDType.Combatant.Equals(this.type) || HUDType.TurnOrder.Equals(this.type)))
			{
				position.x -= this.box.windowRect.x + this.box.Settings.boxPadding.x;
				position.y -= this.box.windowRect.y + this.box.Settings.boxPadding.y;
				
				if(this.content != null)
				{
					for(int i=0; i<this.content.Length; i++)
					{
						if(this.content[i].setting.CheckDrop(this.combatant, drag, position))
						{
							return true;
						}
					}
				}
				
				if(this.hudSetting.enableDrop)
				{
					return drag.Origin.DroppedOnCombatant(this.combatant, drag);
				}
			}
			return false;
		}
		
		public override IContent GetTooltip(Vector2 position)
		{
			if(this.box != null && !this.box.FadingOut && 
				(HUDType.Combatant.Equals(this.type) || 
					HUDType.TurnOrder.Equals(this.type)))
			{
				position.x -= this.box.windowRect.x + this.box.Settings.boxPadding.x;
				position.y -= this.box.windowRect.y + this.box.Settings.boxPadding.y;
				
				if(this.content != null)
				{
					for(int i=0; i<this.content.Length; i++)
					{
						IContent content = this.content[i].setting.GetTooltip(this.combatant, position);
						if(content != null)
						{
							return content;
						}
					}
				}
			}
			return null;
		}
		
		public override bool CheckClick(Vector2 position)
		{
			if(this.InBox(position))
			{
				if(this.box != null && !this.box.FadingOut && 
					(HUDType.Combatant.Equals(this.type) || 
						HUDType.TurnOrder.Equals(this.type)))
				{
					position.x -= this.box.windowRect.x + this.box.Settings.boxPadding.x;
					position.y -= this.box.windowRect.y + this.box.Settings.boxPadding.y;
					
					if(this.content != null)
					{
						for(int i=this.content.Length - 1; i>=0; i--)
						{
							if(this.content[i].label != null && 
								this.content[i].bounds.Contains(position) && 
								this.content[i].setting.CheckClick(this.combatant, position))
							{
								return true;
							}
						}
					}
				}
				return true;
			}
			return false;
		}
	}
}
