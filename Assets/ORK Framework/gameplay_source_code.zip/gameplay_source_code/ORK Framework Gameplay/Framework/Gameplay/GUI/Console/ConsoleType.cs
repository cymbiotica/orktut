
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleType : BaseLanguageData, IContentSimple
	{
		public ConsoleType()
		{
			
		}
		
		public ConsoleType(string name) : base(name)
		{
			
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get{ return this.realID;}
		}

		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].GetDescription();
		}
		
		public string GetIconTextCode()
		{
			return TextCode.ConsoleTypeIcon + this.realID + "#";
		}

		public Texture2D GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}
	}
}
