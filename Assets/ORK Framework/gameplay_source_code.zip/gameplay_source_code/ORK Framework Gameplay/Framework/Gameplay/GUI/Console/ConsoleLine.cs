
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleLine
	{
		public string text = "";
		
		public int typeID = 0;
		
		public ConsoleLine(string text, int typeID)
		{
			this.text = text;
			this.typeID = typeID;
		}
	}
}
