
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ChoiceIconSettings : BaseData
	{
		[ORKEditorHelp("Selection Icon", "The icon is displayed at a currently selected choice.", "")]
		public Texture2D icon;
		
		
		// position
		[ORKEditorHelp("Icon Anchor", "Select the anchor of the icon.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("icon", null, elseCheckGroup=true)]
		public TextAnchor anchor = TextAnchor.MiddleCenter;
		
		[ORKEditorHelp("Choice Anchor", "The icon will be displayed at the selected position of the choice.\n" +
			"E.g. 'Middle Left' will display the icon at the center of the left border of the choice.", "")]
		public TextAnchor choiceAnchor = TextAnchor.MiddleLeft;
		
		[ORKEditorHelp("Show Unfocused", "The icon will also be displayed if the GUI box is not focused.\n" +
			"If disabled, the icon will only be displayed when the GUI box is focused.", "")]
		public bool showUnfocused = false;
		
		[ORKEditorHelp("Icon Offset", "The offset added to the icon's anchor position.", "")]
		public Vector2 offset = Vector2.zero;
		
		
		// fading
		[ORKEditorHelp("Fade Position", "Fade the icon's position over time.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool fadePosition = false;
		
		[ORKEditorHelp("Fade Offset", "The position the icon will fade to.\n" +
			"Defined as offset to the icon's base position.", "")]
		[ORKEditorLayout("fadePosition", true)]
		public Vector2 fadeOffset = Vector2.zero;
		
		[ORKEditorHelp("Fade Time (s)", "The time in seconds used to fade in one direction.", "")]
		[ORKEditorLimit(0.1f, false)]
		public float fadeTime = 1;
		
		[ORKEditorHelp("Interpolation", "Select the interpolation used for fading the icon's position.", "")]
		public EaseType interpolate = EaseType.Linear;
		
		[ORKEditorHelp("Back Interpolation", "Select the interpolation used for fading the icon's position back to the base.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public EaseType interpolateBack = EaseType.Linear;
		
		
		// ingame
		private Function fade;
		
		private Function fadeBack;
		
		public ChoiceIconSettings()
		{
			
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(Rect choiceRect, Vector2 fadePos)
		{
			if(this.icon != null)
			{
				Vector2 position = GUIHelper.GetRectAnchor(choiceRect, this.choiceAnchor) + this.offset + fadePos;
				Rect iconRect = new Rect(position.x, position.y, this.icon.width, this.icon.height);
				GUIHelper.GetRectAnchor(ref iconRect, -iconRect.width, -iconRect.height, this.anchor);
				
				GUI.DrawTexture(iconRect, this.icon);
			}
		}
		
		public void Tick(float t, ref bool fadingBack, ref Vector2 fadePos, ref float time)
		{
			if(this.fadePosition && this.icon != null)
			{
				if(fadingBack)
				{
					if(this.fadeBack == null)
					{
						this.fadeBack = Interpolate.Ease(this.interpolateBack);
					}
					
					time += t;
					fadePos = Interpolate.Ease(this.fadeBack, this.fadeOffset, -this.fadeOffset, time, this.fadeTime);
					
					if(time >= this.fadeTime)
					{
						time = 0;
						fadingBack = false;
					}
				}
				else
				{
					if(this.fade == null)
					{
						this.fade = Interpolate.Ease(this.interpolate);
					}
					
					time += t;
					fadePos = Interpolate.Ease(this.fade, Vector2.zero, this.fadeOffset, time, this.fadeTime);
					
					if(time >= this.fadeTime)
					{
						time = 0;
						fadingBack = true;
					}
				}
			}
		}
		
		
		/*
		============================================================================
		New UI functions
		============================================================================
		*/
		public RectTransform CreateObject(GameObject parent)
		{
			GameObject gameObject = UIHelper.CreateImage(this.icon, null, 
				new Rect(0, 0, this.icon.width, this.icon.height), parent);
			gameObject.name = "Choice Icon";
			UIHelper.AddNonRaycast(gameObject);
			return gameObject.GetComponent<RectTransform>();
		}
		
		public void SetObjectPosition(RectTransform iconObject, Vector2 fadePos, 
			Rect buttonBounds, Rect contentBounds, float scroll, bool isFocused)
		{
			// new UI
			if(iconObject != null)
			{
				Vector2 position = GUIHelper.GetRectAnchor(buttonBounds, this.choiceAnchor) + this.offset + fadePos;
				Rect iconRect = new Rect(
					position.x + contentBounds.x, 
					position.y + contentBounds.y, 
					this.icon.width, this.icon.height);
				GUIHelper.GetRectAnchor(ref iconRect, -iconRect.width, -iconRect.height, this.anchor);
				
				iconObject.anchoredPosition = new Vector2(iconRect.x, -iconRect.y + scroll);
				
				iconObject.gameObject.SetActive(
					(this.showUnfocused || isFocused) && 
					(-iconObject.anchoredPosition.y >= contentBounds.y || 
						-iconObject.anchoredPosition.y + iconRect.height >= contentBounds.y) && 
					(-iconObject.anchoredPosition.y < contentBounds.y + contentBounds.height || 
						-iconObject.anchoredPosition.y + iconRect.height < contentBounds.y + contentBounds.height));
			}
		}
	}
}
