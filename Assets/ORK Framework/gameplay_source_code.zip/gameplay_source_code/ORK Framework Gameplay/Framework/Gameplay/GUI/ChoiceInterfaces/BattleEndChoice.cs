
using UnityEngine;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleEndChoice : BaseData, IChoice
	{
		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the victory gain and level up texts.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		// ingame
		private GUIBox box;
		
		private int current = -1;
		
		private BaseEvent baseEvent;
		
		private string gainsText = "";
		
		private float autoClose = -1;
		
		private bool autoCloseBlockAccept = true;
		
		private Queue<string> nextTexts = new Queue<string>();
		
		public BattleEndChoice()
		{
			
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return this.autoClose < 0 || !this.autoCloseBlockAccept;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(string gainsText, float autoClose, bool autoCloseBlockAccept, 
			BaseEvent baseEvent, int next)
		{
			this.baseEvent = baseEvent;
			this.current = next;
			this.autoClose = autoClose;
			this.autoCloseBlockAccept = autoCloseBlockAccept;
			
			if(this.box != null && !this.box.FadedOut)
			{
				this.nextTexts.Enqueue(gainsText);
			}
			else
			{
				if(this.autoClose >= 0)
				{
					string[] tmp = gainsText.Split(new string[] {TextCode.NextPage}, System.StringSplitOptions.RemoveEmptyEntries);
					if(tmp.Length > 0)
					{
						this.gainsText = tmp[0];
						for(int i=1; i<tmp.Length; i++)
						{
							this.nextTexts.Enqueue(tmp[i]);
						}
					}
					else
					{
						this.gainsText = gainsText;
					}
				}
				else
				{
					this.gainsText = gainsText;
				}
				this.Show();
			}
		}
		
		public void Show()
		{
			this.box = ORK.GUIBoxes.Create(this.guiBoxID);
			this.box.Content = new DialogueContent(this.gainsText, 
				this.useTitle ? this.title[ORK.Game.Language] : "", null, this);
			if(this.autoClose >= 0)
			{
				this.box.CloseAfter(this.autoClose, !this.autoCloseBlockAccept);
			}
			this.box.InitIn();
			ORK.GUI.FocusBlocked = true;
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		public void Closed(GUIBox origin)
		{
			ORK.GUI.FocusBlocked = false;
			this.box = null;
			if(this.nextTexts.Count > 0)
			{
				this.Show(this.nextTexts.Dequeue(), 
					this.autoClose, this.autoCloseBlockAccept, 
					this.baseEvent, this.current);
			}
			else if(this.baseEvent != null)
			{
				BaseEvent tmpEvent = this.baseEvent;
				this.baseEvent = null;
				tmpEvent.StepFinished(this.current);
			}
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			this.box.InitOut();
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}
		
		public void Canceled(GUIBox origin)
		{
			
		}
	}
}
