
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HUDText : HUDElement
	{
		[ORKEditorHelp("Text", "The text that will be displayed.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, label=new string[] {
			"Use default text codes to display game information", 
			"e.g. #area.current = current area name, #time = current game time"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// text format
		[ORKEditorHelp("Line Spacing", "The space between text lines.", "")]
		[ORKEditorInfo("Text Formatting", "Define the appearance of the text, e.g. alignment, text/shadow color, font size/style.", "", 
			separatorForce=true)]
		public float lineSpacing = 10;
		
		[ORKEditorHelp("Text Alignment", "Select how the text will be aligned horizontally.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TextAlignment alignment = TextAlignment.Left;
		
		[ORKEditorHelp("Line Alignment", "Select how text lines will be aligned vertically.\n" +
			"This is used to align text lines consisting of labels with different heights (e.g. text and icons).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public VerticalTextAlignment vAlignment = VerticalTextAlignment.Bottom;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		public TextFormat textFormat = TextFormat.Default;
		
		public HUDText()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public override void CreateLabels(out List<BaseLabel> label, Rect displayBounds, Combatant combatant)
		{
			label = new MultiContent(
				TextHelper.ReplaceSpecials(this.text[ORK.Game.Language]), null, null, 
				displayBounds, this.lineSpacing, this.alignment, this.vAlignment, 
				BoxHeightAdjustment.Auto, false, this.textFormat).label;
		}
	}
}
