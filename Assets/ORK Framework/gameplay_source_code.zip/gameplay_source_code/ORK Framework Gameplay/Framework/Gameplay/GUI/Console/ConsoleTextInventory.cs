
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleTextInventory : BaseData
	{
		[ORKEditorHelp("Console Type", "Select the console type this text will be displayed in.", "")]
		[ORKEditorInfo(ORKDataType.ConsoleType)]
		public int typeID = 0;
		
		[ORKEditorHelp("Text", "The text used to display an inventory change.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, 
			label=new string[] {"%un = user name(s), %n item name, %i = item icon, % = quantity"})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		public ConsoleTextInventory()
		{
			
		}
		
		public ConsoleTextInventory(string text)
		{
			this.text = ArrayHelper.CreateArray(ORK.Languages.Count, text);
		}
		
		public void Print(List<Combatant> owners, IContentSimple content, int quantity)
		{
			ORK.Game.Console.AddLine(
				this.text[ORK.Game.Language].
					Replace("%un", ORK.ConsoleSettings.inventoryOwnerNames.GetNames(owners)).
					Replace("%n", content.GetName()).
					Replace("%i", content.GetIconTextCode()).
					Replace("%", quantity.ToString()), 
				this.typeID);
		}
	}
}
