
using UnityEngine;

namespace ORKFramework
{
	public class GUIBoxButtons : BaseData
	{
		[ORKEditorHelp("Inactive Alpha", "The alpha value (0-1) to use when displaying an " +
			"inactive button (e.g. when a recipe can't be created due to missing ingredients).", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float inactiveAlpha = 0.5f;
		
		[ORKEditorHelp("Use Ok Button", "An 'Ok' button will be displayed in the GUI box.", "")]
		[ORKEditorInfo("Ok Settings", "Define the settings of the 'Ok' button.", "")]
		public bool useOk = true;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useOk", true, endCheckGroup=true, autoInit=true)]
		public GUIBoxButton ok = new GUIBoxButton(new Rect(-150, -30, 150, 30), "Ok");
		
		[ORKEditorHelp("Use Cancel Button", "A 'Cancel' button will be displayed in the GUI box.", "")]
		[ORKEditorInfo("Cancel Settings", "Define the settings of the 'Cancel' button.", "")]
		public bool useCancel = true;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useCancel", true, endCheckGroup=true, autoInit=true)]
		public GUIBoxButton cancel = new GUIBoxButton(new Rect(-300, -30, 150, 30), "Cancel");
		
		public GUIBoxButtons()
		{
			
		}
	}
}
