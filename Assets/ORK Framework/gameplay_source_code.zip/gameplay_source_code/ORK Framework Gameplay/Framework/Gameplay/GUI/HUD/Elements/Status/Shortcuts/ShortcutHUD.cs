
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ShortcutHUD : BaseData, IDragOrigin
	{
		[ORKEditorHelp("Group Shortcut", "Use the group shortcuts of the combatant's group.\n" +
			"If disabled, the combatant's individual shortcuts will be used.", "")]
		public bool isGroupShortcut = false;
		
		[ORKEditorHelp("Slot Start Index", "The index of the first slot that will be displayed.\n" +
			"The rows and columns define how many slots will be displayed.", "")]
		[ORKEditorLimit(0, false)]
		public int startIndex = 0;
		
		[ORKEditorHelp("Enable Tooltip", "A tooltip HUD can be displayed when the mouse position is over a shortcut.", "")]
		public bool enableTooltip = false;
		
		[ORKEditorHelp("Enable Dragging", "Assigned shortcuts can be dragged.\n" +
			"Dragging a shortcut onto something (e.g. a combatant) will use it on the target.", "")]
		public bool enableDrag = false;
		
		[ORKEditorHelp("Enable Clicking", "Assigned shortcuts can be clicked.\n" +
			"Clicking on a shortcut the defined amount of times and clicking on something " +
			"(e.g. a combatant) will use it on the target.", "")]
		public bool enableClick = false;
		
		[ORKEditorHelp("Click Count", "Define the number of clicks needed to use the shortcut.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("enableClick", true, endCheckGroup=true)]
		public int clickCount = 2;
		
		[ORKEditorHelp("Inner Assign", "Select how assigning a shortcut slot from another shortcut slot will be handled:\n" +
			"- None: Shortcuts can't be assigned from the same shortcut HUD element.\n" +
			"- Keep: Both old and new slot will use the shortcut.\n" +
			"- Remove: The old shortcut slot will be removed, the new assigned.\n" +
			"- Swap: The old and new shortcut slot will be swapped, " +
			"i.e. the old will be at the new slot, the new at the old slot.", "")]
		public ShortcutInnerAssignType innerAssign = ShortcutInnerAssignType.Keep;
		
		// remove on drop
		[ORKEditorHelp("Remove On Drop", "Remove the assigned shortcut when it's dropped into the game world " +
			"(i.e. not dropped on a combatant to be used).", "")]
		public bool removeOnWorldDrop = false;
		
		// remove sound sound
		[ORKEditorHelp("Remove Clip", "Select the audio clip that will be played when removing a shortcut through dropping.\n" +
			"Select none to not play an audio clip.", "")]
		[ORKEditorLayout("removeOnWorldDrop", true)]
		public AudioClip removeClip;
		
		[ORKEditorHelp("Volume", "The volume used to play the remove clip (between 0 and 1).", "")]
		[ORKEditorLayout("removeClip", null, elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float removeVolume = 1;
		
		[ORKEditorHelp("Use Group Target", "The shortcut will be used on a group target (if possible).", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("enableClick", true, setDefault=true, defaultValue=false)]
		public bool useGroupTarget = false;
		
		[ORKEditorHelp("Use Individual Target", "The shortcut will be used on an individual target (if possible).", "")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool useIndividualTarget = false;
		
		[ORKEditorHelp("Use Auto Target", "The shortcut will be used on an automatically selected target.\n" +
			"Abilities and items use their 'Auto Target' settings, the nearest target or a random target in range.\n" +
			"Equipment will be equipped on the combatant of the shortcut slots.", "")]
		[ORKEditorLayout(endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool useAutoTarget = false;
		
		
		// inactive shortcut color
		[ORKEditorHelp("Inactive Color", "The color used to display inactive shortcuts (e.g. an ability that can't be used).", "")]
		[ORKEditorInfo(separator=true)]
		public Color inactiveColor = new Color(1, 1, 1, 0.5f);
		
		
		// cell settings
		[ORKEditorHelp("Cell Mode", "Select how cells are arranged:\n" +
			"- List: The cells are displayed in lists (with one or more columns).\n" +
			"- Circle: The cells are displayed in a circle with a defined radius.", "")]
		[ORKEditorInfo(separator=true, labelText="Cell Settings")]
		public ChoiceButtonMode cellMode = ChoiceButtonMode.List;
		
		// list mode
		[ORKEditorHelp("Rows", "The number of rows the bounds will be split into.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("cellMode", ChoiceButtonMode.List)]
		public int rows = 1;
		
		[ORKEditorHelp("Columns", "The number of columns the bounds will be split into.", "")]
		[ORKEditorLimit(1, false)]
		public int columns = 5;
		
		[ORKEditorHelp("Column Fill", "Defines how the shortcuts will be filled into the columns.\n" +
			"Either 'Vertical' or 'Horizontal'.", "")]
		[ORKEditorInfo(isEnumToolbar=true)]
		public ColumnFill columnFill = ColumnFill.Vertical;
		
		[ORKEditorHelp("Spacing", "The space between the cells (X=horizontally, Y=vertically).", "")]
		public Vector2 spacing = new Vector2(5, 5);
		
		[ORKEditorHelp("Set Cell Size", "Set the size of the cells manually.\n" +
			"If disabled, the cell size will be calculated based on the " +
			"number of rows and columns, and the bounds.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool setCellSize = false;
		
		// circle mode
		[ORKEditorHelp("Circle Radius", "Define the radius of the circle.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("cellMode", ChoiceButtonMode.Circle)]
		public float circleRadius = 100;
		
		[ORKEditorHelp("Circle Degree", "Define the degree of the circle that will be used.\n" +
			"360 is a full circle, 180 is a half circle, etc.", "")]
		[ORKEditorLimit(1.0f, 360.0f)]
		public float circleDegree = 360.0f;
		
		[ORKEditorHelp("First Slot Offset", "The offset in degrees the first slot will be placed at on the circle.\n" +
			"The offset will be added clockwise to the top point of the circle, i.e. " +
			"0 will be at the top, 90 will be at the left side, 180 will be at the bottom and 270 will be at the right side.", "")]
		[ORKEditorLimit(0.0f, 360.0f)]
		public float circleFirstOffset = 0;
		
		[ORKEditorHelp("Inverse Alignment", "The slots will be aligned on the circle counter clockwise.\n" +
			"If disabled, the choices will be aligned clockwise.", "")]
		public bool circleInverse = false;
		
		[ORKEditorHelp("Slot Anchor", "Select the anchor of the slot.", "")]
		public TextAnchor circleSlotAnchor = TextAnchor.MiddleCenter;
		
		[ORKEditorHelp("Circle Position", "The position (center) of the circle within the HUD element's bounds.", "")]
		public Vector2 circlePosition = new Vector2(100, 100);
		
		[ORKEditorHelp("Slot Count", "Define the number of slots that will be displayed.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int circleSlotCount = 10;
		
		// position mode
		[ORKEditorArray(false, "Add Cell", "Adds a cell.", "", 
			"Remove", "Removes this cell.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Cell", "Define the position of the cell.", ""
		})]
		[ORKEditorLayout("cellMode", ChoiceButtonMode.Position, endCheckGroup=true, autoInit=true)]
		public ShortcutPositionSetting[] cellPosition;
		
		// set cell size
		[ORKEditorHelp("Cell Size", "The width (X) and height (Y) of each cell.", "")]
		[ORKEditorLayout(new string[] {"setCellSize", "cellMode", "cellMode"}, 
			new System.Object[] {true, ChoiceButtonMode.Circle, ChoiceButtonMode.Position}, 
			needed=Needed.One, endCheckGroup=true)]
		public Vector2 cellSize = new Vector2(50, 50);
		
		
		// empty slot
		[ORKEditorInfo("Empty Slot Display", "Define how empty slots will be displayed.", "", 
			endFoldout=true, separatorForce=true)]
		public ShortcutSlotDisplay emptySlot = new ShortcutSlotDisplay();
		
		
		// assigned slot
		[ORKEditorInfo("Assigned Slot Display", "Define how assigned slots will be displayed.", "", 
			endFoldout=true, separatorForce=true)]
		public ShortcutSlotDisplay assignedSlot = new ShortcutSlotDisplay();
		
		public ShortcutHUD()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<bool>("noInnerAssign"))
			{
				bool tmp = false;
				data.Get("noInnerAssign", ref tmp);
				if(tmp)
				{
					this.innerAssign = ShortcutInnerAssignType.None;
				}
			}
			if(data.Contains<bool>("enableDoubleClick"))
			{
				data.Get("enableDoubleClick", ref this.enableClick);
			}
		}
		
		
		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		private bool HasShortcut(Combatant combatant, int index)
		{
			if(this.isGroupShortcut)
			{
				return combatant.Group.Shortcuts.HasShortcut(index);
			}
			else
			{
				return combatant.Shortcuts.HasShortcut(index);
			}
		}
		
		private IShortcut GetShortcut(Combatant combatant, int index)
		{
			if(this.isGroupShortcut)
			{
				if(combatant.Group.Shortcuts[index] != null)
				{
					return combatant.Group.Shortcuts[index].Shortcut;
				}
			}
			else
			{
				return combatant.Shortcuts[index];
			}
			return null;
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, Combatant combatant, Rect bounds)
		{
			label = new List<BaseLabel>();
			
			Vector2 cell = this.GetCellSize(bounds.width, bounds.height);
			
			if(ChoiceButtonMode.List.Equals(this.cellMode))
			{
				int currentColumn = 0;
				int currentRow = 0;
				int maxView = this.rows * this.columns;
				
				for(int i=0; i<maxView; i++)
				{
					Rect cellBounds = new Rect(
						cell.x * currentColumn + this.spacing.x * currentColumn, 
						cell.y * currentRow + this.spacing.y * currentRow, 
						cell.x, cell.y);
					if(this.HasShortcut(combatant, this.startIndex + i))
					{
						if(this.isGroupShortcut)
						{
							GroupShortcutSlot shortcut = combatant.Group.Shortcuts[this.startIndex + i];
							label.Add(new ShortcutLabel(shortcut.Owner, shortcut.Shortcut, 
								this.assignedSlot.Create(shortcut.Owner, shortcut.Shortcut, cellBounds, this.startIndex + i), 
								this.inactiveColor, cellBounds));
						}
						else
						{
							IShortcut shortcut = combatant.Shortcuts[this.startIndex + i];
							label.Add(new ShortcutLabel(combatant, shortcut, 
								this.assignedSlot.Create(combatant, shortcut, cellBounds, this.startIndex + i), 
								this.inactiveColor, cellBounds));
						}
					}
					else
					{
						label.AddRange(this.emptySlot.Create(combatant, null, 
							cellBounds, this.startIndex + i));
					}
					
					if(ColumnFill.Vertical.Equals(this.columnFill))
					{
						currentColumn++;
						if(currentColumn >= this.columns)
						{
							currentColumn = 0;
							currentRow++;
						}
					}
					else
					{
						currentRow++;
						if(currentRow >= this.rows)
						{
							currentRow = 0;
							currentColumn++;
						}
					}
				}
			}
			else if(ChoiceButtonMode.Circle.Equals(this.cellMode))
			{
				float angleOffset = this.circleDegree < 360.0f ? 
					this.circleDegree / (this.circleSlotCount - 1) : 
					360.0f / this.circleSlotCount;
				float startOffset = 180 - this.circleFirstOffset;
				
				for(int i=0; i<this.circleSlotCount; i++)
				{
					Vector2 pos = VectorHelper.CirclePosition(
							this.circlePosition, this.circleRadius, 
							this.circleInverse ? 
								startOffset + angleOffset * i : 
								startOffset - angleOffset * i);
					pos -= GUIHelper.GetRectAnchor(new Rect(0, 0, cell.x, cell.y), this.circleSlotAnchor);
					
					Rect cellBounds = new Rect(pos.x, pos.y, cell.x, cell.y);
					if(this.HasShortcut(combatant, this.startIndex + i))
					{
						if(this.isGroupShortcut)
						{
							GroupShortcutSlot shortcut = combatant.Group.Shortcuts[this.startIndex + i];
							label.Add(new ShortcutLabel(shortcut.Owner, shortcut.Shortcut, 
								this.assignedSlot.Create(shortcut.Owner, shortcut.Shortcut, cellBounds, this.startIndex + i), 
								this.inactiveColor, cellBounds));
						}
						else
						{
							IShortcut shortcut = combatant.Shortcuts[this.startIndex + i];
							label.Add(new ShortcutLabel(combatant, shortcut, 
								this.assignedSlot.Create(combatant, shortcut, cellBounds, this.startIndex + i), 
								this.inactiveColor, cellBounds));
						}
					}
					else
					{
						label.AddRange(this.emptySlot.Create(combatant, null, 
							cellBounds, this.startIndex + i));
					}
				}
			}
			else if(ChoiceButtonMode.Position.Equals(this.cellMode))
			{
				for(int i=0; i<this.cellPosition.Length; i++)
				{
					int cellIndex = this.cellPosition[i].setSlotIndex ? 
						this.cellPosition[i].slotIndex : 
						this.startIndex + i;
					
					Rect cellBounds = this.cellPosition[i].setSize ? 
						new Rect(this.cellPosition[i].position.x, this.cellPosition[i].position.y, 
							this.cellPosition[i].size.x, this.cellPosition[i].size.y) : 
						new Rect(this.cellPosition[i].position.x, this.cellPosition[i].position.y, 
							cell.x, cell.y);
					GUIHelper.GetRectAnchor(ref cellBounds, 
						-cellBounds.width, -cellBounds.height, 
						this.cellPosition[i].anchor);
					
					if(this.HasShortcut(combatant, cellIndex))
					{
						if(this.isGroupShortcut)
						{
							GroupShortcutSlot shortcut = combatant.Group.Shortcuts[cellIndex];
							label.Add(new ShortcutLabel(shortcut.Owner, shortcut.Shortcut, 
								this.assignedSlot.Create(shortcut.Owner, shortcut.Shortcut, cellBounds, cellIndex), 
								this.inactiveColor, cellBounds));
						}
						else
						{
							IShortcut shortcut = combatant.Shortcuts[cellIndex];
							label.Add(new ShortcutLabel(combatant, shortcut, 
								this.assignedSlot.Create(combatant, shortcut, cellBounds, cellIndex), 
								this.inactiveColor, cellBounds));
						}
					}
					else
					{
						label.AddRange(this.emptySlot.Create(combatant, null, 
							cellBounds, cellIndex));
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public ChoiceContent GetDragOnPosition(Combatant owner, Vector2 position, Rect bounds)
		{
			Vector2 cell = this.GetCellSize(bounds.width, bounds.height);
			
			if(ChoiceButtonMode.List.Equals(this.cellMode))
			{
				int currentColumn = 0;
				int currentRow = 0;
				int maxView = this.rows * this.columns;
				
				for(int i=0; i<maxView; i++)
				{
					if(new Rect(bounds.x + cell.x * currentColumn + this.spacing.x * currentColumn, 
								bounds.y + cell.y * currentRow + this.spacing.y * currentRow, 
								cell.x, cell.y).Contains(position))
					{
						return this.GetCellContent(owner, this.startIndex + i);
					}
					
					if(ColumnFill.Vertical.Equals(this.columnFill))
					{
						currentColumn++;
						if(currentColumn >= this.columns)
						{
							currentColumn = 0;
							currentRow++;
						}
					}
					else
					{
						currentRow++;
						if(currentRow >= this.rows)
						{
							currentRow = 0;
							currentColumn++;
						}
					}
				}
			}
			else if(ChoiceButtonMode.Circle.Equals(this.cellMode))
			{
				float angleOffset = this.circleDegree < 360.0f ? 
					this.circleDegree / (this.circleSlotCount - 1) : 
					360.0f / this.circleSlotCount;
				float startOffset = 180 - this.circleFirstOffset;
				
				for(int i=0; i<this.circleSlotCount; i++)
				{
					Vector2 pos = VectorHelper.CirclePosition(
							this.circlePosition, this.circleRadius, 
							this.circleInverse ? 
								startOffset + angleOffset * i : 
								startOffset - angleOffset * i);
					pos -= GUIHelper.GetRectAnchor(new Rect(0, 0, cell.x, cell.y), this.circleSlotAnchor);
					
					if(new Rect(bounds.x + pos.x, bounds.y + pos.y, cell.x, cell.y).
						Contains(position))
					{
						return this.GetCellContent(owner, this.startIndex + i);
					}
				}
			}
			else if(ChoiceButtonMode.Position.Equals(this.cellMode))
			{
				for(int i=0; i<this.cellPosition.Length; i++)
				{
					int cellIndex = this.cellPosition[i].setSlotIndex ? 
						this.cellPosition[i].slotIndex : 
						this.startIndex + i;
					
					Rect cellBounds = this.cellPosition[i].setSize ? 
						new Rect(this.cellPosition[i].position.x, this.cellPosition[i].position.y, 
							this.cellPosition[i].size.x, this.cellPosition[i].size.y) : 
						new Rect(this.cellPosition[i].position.x, this.cellPosition[i].position.y, 
							cell.x, cell.y);
					GUIHelper.GetRectAnchor(ref cellBounds, 
						-cellBounds.width, -cellBounds.height, 
						this.cellPosition[i].anchor);
					
					if(cellBounds.Contains(position))
					{
						return this.GetCellContent(owner, cellIndex);
					}
				}
			}
			
			return null;
		}
		
		private ChoiceContent GetCellContent(Combatant owner, int cellIndex)
		{
			if(this.HasShortcut(owner, cellIndex))
			{
				IShortcut shortcut = null;
				if(this.isGroupShortcut)
				{
					shortcut = owner.Group.Shortcuts[cellIndex].Shortcut;
					owner = owner.Group.Shortcuts[cellIndex].Owner;
				}
				else
				{
					shortcut = owner.Shortcuts[cellIndex];
				}
				ChoiceContent cc = new ChoiceContent(shortcut.GetContent());
				
				cc.isDragable = this.enableDrag;
				cc.isTooltip = this.enableTooltip;
				if(this.enableClick)
				{
					cc.clickCount = this.clickCount;
					cc.useOnGroupTarget = this.useGroupTarget;
					cc.useOnIndividualTarget = this.useIndividualTarget;
					cc.useAutoTarget = this.useAutoTarget;
				}
				if(cc.isDragable || cc.clickCount > 0 || 
					cc.useOnGroupTarget || cc.useOnIndividualTarget || cc.useAutoTarget)
				{
					cc.drag = shortcut.GetDrag(this, owner);
					cc.drag.shortcutSlot = cellIndex;
				}
				
				return cc;
			}
			else
			{
				return null;
			}
		}
		
		public bool CheckDrop(Combatant owner, DragInfo drag, Vector2 position, Rect bounds)
		{
			if(((this.isGroupShortcut && owner.Group.IsMember(drag.User)) || 
					owner == drag.User) && 
				drag.Shortcut != null)
			{
				Vector2 cell = this.GetCellSize(bounds.width, bounds.height);
				
				if(ChoiceButtonMode.List.Equals(this.cellMode))
				{
					int currentColumn = 0;
					int currentRow = 0;
					int maxView = this.rows * this.columns;
					
					for(int i=0; i<maxView; i++)
					{
						if(new Rect(bounds.x + cell.x * currentColumn + this.spacing.x * currentColumn, 
									bounds.y + cell.y * currentRow + this.spacing.y * currentRow, 
									cell.x, cell.y).Contains(position))
						{
							this.DropCell(drag, owner, this.startIndex + i);
							return true;
						}
						
						if(ColumnFill.Vertical.Equals(this.columnFill))
						{
							currentColumn++;
							if(currentColumn >= this.columns)
							{
								currentColumn = 0;
								currentRow++;
							}
						}
						else
						{
							currentRow++;
							if(currentRow >= this.rows)
							{
								currentRow = 0;
								currentColumn++;
							}
						}
					}
				}
				else if(ChoiceButtonMode.Circle.Equals(this.cellMode))
				{
					float angleOffset = this.circleDegree < 360.0f ? 
						this.circleDegree / (this.circleSlotCount - 1) : 
						360.0f / this.circleSlotCount;
					float startOffset = 180 - this.circleFirstOffset;
					
					for(int i=0; i<this.circleSlotCount; i++)
					{
						Vector2 pos = VectorHelper.CirclePosition(
								this.circlePosition, this.circleRadius, 
								this.circleInverse ? 
									startOffset + angleOffset * i : 
									startOffset - angleOffset * i);
						pos -= GUIHelper.GetRectAnchor(new Rect(0, 0, cell.x, cell.y), this.circleSlotAnchor);
						
						if(new Rect(bounds.x + pos.x, bounds.y + pos.y, cell.x, cell.y).
							Contains(position))
						{
							this.DropCell(drag, owner, this.startIndex + i);
							return true;
						}
					}
				}
				else if(ChoiceButtonMode.Position.Equals(this.cellMode))
				{
					for(int i=0; i<this.cellPosition.Length; i++)
					{
						int cellIndex = this.cellPosition[i].setSlotIndex ? 
							this.cellPosition[i].slotIndex : 
							this.startIndex + i;
						
						Rect cellBounds = this.cellPosition[i].setSize ? 
							new Rect(this.cellPosition[i].position.x, this.cellPosition[i].position.y, 
								this.cellPosition[i].size.x, this.cellPosition[i].size.y) : 
							new Rect(this.cellPosition[i].position.x, this.cellPosition[i].position.y, 
								cell.x, cell.y);
						GUIHelper.GetRectAnchor(ref cellBounds, 
							-cellBounds.width, -cellBounds.height, 
							this.cellPosition[i].anchor);
						
						if(cellBounds.Contains(position))
						{
							this.DropCell(drag, owner, cellIndex);
							return true;
						}
					}
				}
			}
			
			return false;
		}
		
		private void DropCell(DragInfo drag, Combatant owner, int cellIndex)
		{
			if(this.isGroupShortcut)
			{
				if(drag.Origin != this)
				{
					owner.Group.Shortcuts[cellIndex] = new GroupShortcutSlot(drag.User, drag.Shortcut);
				}
				else
				{
					if(ShortcutInnerAssignType.Keep.Equals(this.innerAssign))
					{
						owner.Group.Shortcuts[cellIndex] = new GroupShortcutSlot(drag.User, drag.Shortcut);
					}
					else if(ShortcutInnerAssignType.Remove.Equals(this.innerAssign))
					{
						owner.Group.Shortcuts[cellIndex] = new GroupShortcutSlot(drag.User, drag.Shortcut);
						owner.Group.Shortcuts[drag.shortcutSlot] = null;
					}
					else if(ShortcutInnerAssignType.Swap.Equals(this.innerAssign))
					{
						GroupShortcutSlot tmpShortcut = owner.Group.Shortcuts[cellIndex];
						owner.Group.Shortcuts[cellIndex] = new GroupShortcutSlot(drag.User, drag.Shortcut);
						owner.Group.Shortcuts[drag.shortcutSlot] = tmpShortcut;
					}
				}
			}
			else
			{
				if(drag.Origin != this)
				{
					owner.Shortcuts[cellIndex] = drag.Shortcut;
				}
				else
				{
					if(ShortcutInnerAssignType.Keep.Equals(this.innerAssign))
					{
						owner.Shortcuts[cellIndex] = drag.Shortcut;
					}
					else if(ShortcutInnerAssignType.Remove.Equals(this.innerAssign))
					{
						owner.Shortcuts[cellIndex] = drag.Shortcut;
						owner.Shortcuts[drag.shortcutSlot] = null;
					}
					else if(ShortcutInnerAssignType.Swap.Equals(this.innerAssign))
					{
						IShortcut tmpShortcut = owner.Shortcuts[cellIndex];
						owner.Shortcuts[cellIndex] = drag.Shortcut;
						owner.Shortcuts[drag.shortcutSlot] = tmpShortcut;
					}
				}
			}
		}

		public void Dropped(DragInfo drag)
		{
			
		}

		public bool DroppedOnCombatant(Combatant c, DragInfo drag)
		{
			if(c != null)
			{
				return drag.UseOn(c, true);
			}
			return false;
		}

		public bool DroppedToWorld(Vector3 position, DragInfo drag)
		{
			if(this.removeOnWorldDrop && 
				drag.Origin == this && drag.User != null)
			{
				if(this.removeClip != null)
				{
					ORK.Audio.PlayOneShot(this.removeClip, this.removeVolume);
				}
				if(this.isGroupShortcut)
				{
					drag.User.Group.Shortcuts[drag.shortcutSlot] = null;
				}
				else
				{
					drag.User.Shortcuts[drag.shortcutSlot] = null;
				}
				return true;
			}
			return false;
		}
		
		public IContent GetTooltip(Combatant owner, Vector2 position, Rect bounds)
		{
			Vector2 cell = this.GetCellSize(bounds.width, bounds.height);
			
			if(ChoiceButtonMode.List.Equals(this.cellMode))
			{
				int currentColumn = 0;
				int currentRow = 0;
				int maxView = this.rows * this.columns;
				
				for(int i=0; i<maxView; i++)
				{
					if(new Rect(bounds.x + cell.x * currentColumn + this.spacing.x * currentColumn, 
								bounds.y + cell.y * currentRow + this.spacing.y * currentRow, 
								cell.x, cell.y).Contains(position))
					{
						return this.GetShortcut(owner, this.startIndex + i);
					}
					
					if(ColumnFill.Vertical.Equals(this.columnFill))
					{
						currentColumn++;
						if(currentColumn >= this.columns)
						{
							currentColumn = 0;
							currentRow++;
						}
					}
					else
					{
						currentRow++;
						if(currentRow >= this.rows)
						{
							currentRow = 0;
							currentColumn++;
						}
					}
				}
			}
			else if(ChoiceButtonMode.Circle.Equals(this.cellMode))
			{
				float angleOffset = this.circleDegree < 360.0f ? 
					this.circleDegree / (this.circleSlotCount - 1) : 
					360.0f / this.circleSlotCount;
				float startOffset = 180 - this.circleFirstOffset;
				
				for(int i=0; i<this.circleSlotCount; i++)
				{
					Vector2 pos = VectorHelper.CirclePosition(
							this.circlePosition, this.circleRadius, 
							this.circleInverse ? 
								startOffset + angleOffset * i : 
								startOffset - angleOffset * i);
					pos -= GUIHelper.GetRectAnchor(new Rect(0, 0, cell.x, cell.y), this.circleSlotAnchor);
					
					if(new Rect(bounds.x + pos.x, bounds.y + pos.y, cell.x, cell.y).
						Contains(position))
					{
						return this.GetShortcut(owner, this.startIndex + i);
					}
				}
			}
			else if(ChoiceButtonMode.Position.Equals(this.cellMode))
			{
				for(int i=0; i<this.cellPosition.Length; i++)
				{
					int cellIndex = this.cellPosition[i].setSlotIndex ? 
						this.cellPosition[i].slotIndex : 
						this.startIndex + i;
					
					Rect cellBounds = this.cellPosition[i].setSize ? 
						new Rect(this.cellPosition[i].position.x, this.cellPosition[i].position.y, 
							this.cellPosition[i].size.x, this.cellPosition[i].size.y) : 
						new Rect(this.cellPosition[i].position.x, this.cellPosition[i].position.y, 
							cell.x, cell.y);
					GUIHelper.GetRectAnchor(ref cellBounds, 
						-cellBounds.width, -cellBounds.height, 
						this.cellPosition[i].anchor);
					
					if(cellBounds.Contains(position))
					{
						return this.GetShortcut(owner, cellIndex);
					}
				}
			}
			return null;
		}
		
		
		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public Vector2 GetCellSize(float width, float height)
		{
			if(ChoiceButtonMode.Circle.Equals(this.cellMode) || 
				ChoiceButtonMode.Position.Equals(this.cellMode) || 
				this.setCellSize)
			{
				return this.cellSize;
			}
			else
			{
				Vector2 cell = new Vector2(width, height);
				cell.x -= this.spacing.x * (this.columns - 1);
				cell.y -= this.spacing.y * (this.rows - 1);
				cell.x /= this.columns;
				cell.y /= this.rows;
				return cell;
			}
		}
	}
}
