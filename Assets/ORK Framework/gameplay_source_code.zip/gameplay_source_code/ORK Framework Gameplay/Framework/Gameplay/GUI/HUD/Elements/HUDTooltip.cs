
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HUDTooltip : HUDElement
	{
		// value bar
		[ORKEditorHelp("Use Bar", "Display a value bar for level points (ability, equipment) or durability (equipment).\n" +
			"If disabled, a text is displayed.", "")]
		public bool useBar = false;
		
		[ORKEditorHelp("Bar Type", "Select the the value that will be displayed:\n" +
			"- Level Points: Displays an equipment's or ability's level points.\n" +
			"- Durability: Displays an equipment's durability.", "")]
		[ORKEditorLayout("useBar", true)]
		public HUDShortcutValueType barType = HUDShortcutValueType.LevelPoints;
		
		[ORKEditorHelp("Bar Bounds", "The position and size of the bar.\n" +
			"The coordinates X=0, Y=0 are located at the upper left corner of this element's bounds.", "")]
		public Rect barBounds = new Rect(0, 0, 100, 10);
		
		[ORKEditorLayout(autoInit=true)]
		public ValueBar bar;
		
		
		// text
		[ORKEditorInfo(separator=true, label=new string[] {
			"%n = name, %d = description, %i = icon, % = information (e.g. quantity, use costs)", 
			"%tn = type name, %td = type description, %ti = type icon", 
			"%l = level points (ability, equipment), %ml = max level points (next level up)", 
			"%ed = equipment durability, %ed1 = durability format 0.0, %ed2 = durability format 0.00", 
			"%md = max durability, %md1 = max durability format 0.0, %md2 = max durability format 0.00"
		})]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public StatusTextHUD infoText = new StatusTextHUD();
		
		public HUDTooltip()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<float>("lineSpacing"))
			{
				this.infoText.SetData(data);
			}
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public override void CreateLabels(out List<BaseLabel> label, Rect displayBounds, 
			Combatant combatant)
		{
			if(ORK.GUI.TooltipContent != null)
			{
				if(this.useBar)
				{
					label = null;
					if(HUDShortcutValueType.LevelPoints.Equals(this.barType))
					{
						if(ORK.GUI.TooltipContent is AbilityShortcut)
						{
							AbilityShortcut ability = ORK.GUI.TooltipContent as AbilityShortcut;
							if(ability.CanLevelUp())
							{
								label = new List<BaseLabel>();
								this.bar.Create(ref label, 
									new Rect(this.barBounds.x + displayBounds.x, this.barBounds.y + displayBounds.y, 
										this.barBounds.width, this.barBounds.height), 
									ability.LevelPoints, ability.MinLevelPoints, ability.MaxLevelPoints);
							}
						}
						else if(ORK.GUI.TooltipContent is EquipShortcut)
						{
							EquipShortcut equip = ORK.GUI.TooltipContent as EquipShortcut;
							if(equip.CanLevelUp())
							{
								label = new List<BaseLabel>();
								this.bar.Create(ref label, 
									new Rect(this.barBounds.x + displayBounds.x, this.barBounds.y + displayBounds.y, 
										this.barBounds.width, this.barBounds.height), 
									equip.LevelPoints, equip.MinLevelPoints, equip.MaxLevelPoints);
							}
						}
					}
					else if(HUDShortcutValueType.Durability.Equals(this.barType))
					{
						if(ORK.GUI.TooltipContent is EquipShortcut)
						{
							EquipShortcut equip = ORK.GUI.TooltipContent as EquipShortcut;
							if(equip.Durability != -1)
							{
								label = new List<BaseLabel>();
								this.bar.Create(ref label, 
									new Rect(this.barBounds.x + displayBounds.x, this.barBounds.y + displayBounds.y, 
										this.barBounds.width, this.barBounds.height), 
									equip.Durability, 0, equip.MaxDurability);
							}
						}
					}
				}
				else
				{
					string tmp = this.infoText.text[ORK.Game.Language];
					
					if(tmp.Contains("%t"))
					{
						IContentSimple typeContent = ORK.GUI.TooltipContent.GetTypeContent();
						if(typeContent != null)
						{
							tmp = tmp.Replace("%tn", typeContent.GetName()).
								Replace("%td", typeContent.GetDescription()).
								Replace("%ti", typeContent.GetIconTextCode());
						}
						else
						{
							tmp = tmp.Replace("%tn", "").
								Replace("%td", "").
								Replace("%ti", "");
						}
					}
					
					if(ORK.GUI.TooltipContent is AbilityShortcut)
					{
						AbilityShortcut ability = ORK.GUI.TooltipContent as AbilityShortcut;
						if(ability.CanLevelUp())
						{
							tmp = tmp.Replace("%ml", ability.MaxLevelPoints.ToString()).
								Replace("%l", ability.LevelPoints.ToString()).
								Replace("%md2", "").Replace("%md1", "").Replace("%md", "").
								Replace("%ed2", "").Replace("%ed1", "").Replace("%ed", "");
						}
						else
						{
							tmp = tmp.Replace("%ml", "").Replace("%l", "").
								Replace("%md2", "").Replace("%md1", "").Replace("%md", "").
								Replace("%ed2", "").Replace("%ed1", "").Replace("%ed", "");
						}
					}
					else if(ORK.GUI.TooltipContent is EquipShortcut)
					{
						EquipShortcut equip = ORK.GUI.TooltipContent as EquipShortcut;
						if(equip.CanLevelUp())
						{
							tmp = tmp.Replace("%ml", equip.MaxLevelPoints.ToString()).
								Replace("%l", equip.LevelPoints.ToString());
						}
						else
						{
							tmp = tmp.Replace("%ml", "").Replace("%l", "");
						}
						if(equip.Durability != -1)
						{
							tmp = tmp.Replace("%md2", equip.MaxDurability.ToString("0.00")).
								Replace("%md1", equip.MaxDurability.ToString("0.0")).
								Replace("%md", equip.MaxDurability.ToString("0")).
								Replace("%ed2", equip.Durability.ToString("0.00")).
								Replace("%ed1", equip.Durability.ToString("0.0")).
								Replace("%ed", equip.Durability.ToString("0"));
						}
						else
						{
							tmp = tmp.Replace("%md2", "").Replace("%md1", "").Replace("%md", "").
								Replace("%ed2", "").Replace("%ed1", "").Replace("%ed", "");
						}
					}
					else
					{
						tmp = tmp.Replace("%ml", "").Replace("%l", "").
							Replace("%md2", "").Replace("%md1", "").Replace("%md", "").
							Replace("%ed2", "").Replace("%ed1", "").Replace("%ed", "");
					}
					
					label = new MultiContent(
						TextHelper.ReplaceSpecials(tmp.
							Replace("%n", ORK.GUI.TooltipContent.GetName()).
							Replace("%d", ORK.GUI.TooltipContent.GetDescription()).
							Replace("%i", ORK.GUI.TooltipContent.GetIconTextCode()).
							Replace("%", ORK.GUI.TooltipContent.GetInfo(
								combatant != null ? combatant : ORK.Game.ActiveGroup.Leader))), 
						null, null, displayBounds, this.infoText.lineSpacing, 
						this.infoText.alignment, this.infoText.vAlignment, BoxHeightAdjustment.Auto, 
						false, this.infoText.textFormat).label;
				}
			}
			else
			{
				label = null;
			}
		}
		
		public override void CreateLabelsEditor(out List<BaseLabel> label, Rect displayBounds, 
			Combatant combatant)
		{
			if(this.useBar)
			{
				label = null;
				if(HUDShortcutValueType.LevelPoints.Equals(this.barType))
				{
					label = new List<BaseLabel>();
						this.bar.Create(ref label, 
							new Rect(this.barBounds.x + displayBounds.x, this.barBounds.y + displayBounds.y, 
								this.barBounds.width, this.barBounds.height), 
							10, 0, 100);
				}
				else if(HUDShortcutValueType.Durability.Equals(this.barType))
				{
					label = new List<BaseLabel>();
					this.bar.Create(ref label, 
						new Rect(this.barBounds.x + displayBounds.x, this.barBounds.y + displayBounds.y, 
							this.barBounds.width, this.barBounds.height), 
						50, 0, 100);
				}
			}
			else
			{
				Item item = ORK.Items.Get(0);
				string tmp = this.infoText.text[ORK.Game.Language];
				
				if(tmp.Contains("%t"))
				{
					IContentSimple typeContent = item.GetTypeContent();
					if(typeContent != null)
					{
						tmp = tmp.Replace("%tn", typeContent.GetName()).
							Replace("%td", typeContent.GetDescription()).
							Replace("%ti", typeContent.GetIconTextCode());
					}
					else
					{
						tmp = tmp.Replace("%tn", "").
							Replace("%td", "").
							Replace("%ti", "");
					}
				}
				tmp = tmp.Replace("%ml", "100").Replace("%l", "10").
					Replace("%md2", "100.00").Replace("%md1", "100.0").Replace("%md", "100").
					Replace("%ed2", "50.00").Replace("%ed1", "50.0").Replace("%ed", "50");
				
				label = new MultiContent(
					TextHelper.ReplaceSpecials(tmp.
						Replace("%n", item.GetName()).
						Replace("%d", item.GetDescription()).
						Replace("%i", item.GetIconTextCode()).
						Replace("%", item.GetInfo(combatant != null ? combatant : ORK.Game.ActiveGroup.Leader))), 
					null, null, displayBounds, this.infoText.lineSpacing, 
					this.infoText.alignment, this.infoText.vAlignment, BoxHeightAdjustment.Auto, 
					false, this.infoText.textFormat).label;
			}
		}
	}
}
