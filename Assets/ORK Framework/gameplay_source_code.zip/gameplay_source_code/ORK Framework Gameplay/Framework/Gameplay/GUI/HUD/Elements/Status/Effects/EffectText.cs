
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Display
{
	public class EffectText : BaseData
	{
		[ORKEditorHelp("Position", "Set the X and Y position of the info label within a status effect's cell bounds.", "")]
		public Vector2 position = Vector2.zero;
		
		[ORKEditorHelp("Anchor", "Select the anchor of the info label.\n" +
			"E.g. 'Upper Left' will place the upper left corner of the info label at the defined position, " +
			"'Lower Right' will place the lower right corner of the image at the defind position.", "")]
		public TextAnchor anchor = TextAnchor.UpperLeft;
		
		[ORKEditorHelp("Relative To", "Select the the corner of the status effect's cell bounds the info label will be relative to.", "")]
		public TextAnchor relativeTo = TextAnchor.UpperLeft;
		
		[ORKEditorInfo(separator=true, 
			label=new string[] {
				"%n = name, %d = description, %i = icon", 
				"% = remaining time/turns, %1 = with 1 decimal (0.0), %2 = with 2 decimal (0.00)", 
				"Remaining turns will always be displayed without decimals"
		})]
		public StatusTextHUD text = new StatusTextHUD();
		
		public EffectText()
		{
			
		}
		
		public void Create(ref List<BaseLabel> label, StatusEffect effect, Rect bounds)
		{
			MultiContent mc = new MultiContent(
				TextHelper.ReplaceSpecials(this.GetText(effect, this.text.text[ORK.Game.Language])), 
				null, null, bounds, this.text.lineSpacing, this.text.alignment, 
				this.text.vAlignment, BoxHeightAdjustment.Auto, false, this.text.textFormat);
			
			// move to anchor positions
			Rect tmpBounds = new Rect(this.position.x, this.position.y, mc.bounds.width - bounds.x, mc.bounds.height - bounds.y);
			Vector2 tmp = GUIHelper.GetRectAnchor(bounds, this.relativeTo);
			tmpBounds.x += (tmp.x - bounds.x);
			tmpBounds.y += (tmp.y - bounds.y);
			GUIHelper.GetRectAnchor(ref tmpBounds, -tmpBounds.width, -tmpBounds.height, this.anchor);
			mc.ChangePosition(tmpBounds.x, tmpBounds.y);
			
			label.AddRange(mc.label);
		}
		
		private string GetText(StatusEffect effect, string text)
		{
			return effect != null ? 
				text.Replace("%n", effect.GetName()).
					Replace("%d", effect.GetDescription()).
					Replace("%i", effect.GetIconTextCode()).
					Replace("%2", effect.RemainingTimeHUD(2)).
					Replace("%1", effect.RemainingTimeHUD(1)).
					Replace("%", effect.RemainingTimeHUD(0)) : 
				text.Replace("%n", "").
					Replace("%d", "").
					Replace("%i", "").
					Replace("%2", "").
					Replace("%1", "").
					Replace("%", "");
		}
	}
}
