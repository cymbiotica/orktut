
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleTextLevelUp : BaseData
	{
		[ORKEditorHelp("Console Type", "Select the console type this text will be displayed in.", "")]
		[ORKEditorInfo(ORKDataType.ConsoleType)]
		public int typeID = 0;
		
		[ORKEditorHelp("Text", "The text used to display a level up.\n" +
			"Please note that only class, ability and equipment level up use the %n text code.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, 
			label=new string[] {"%un = user name, %n name (class, ability, equipment), % = new level"})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		public ConsoleTextLevelUp()
		{
			
		}
		
		public ConsoleTextLevelUp(string text)
		{
			this.text = ArrayHelper.CreateArray(ORK.Languages.Count, text);
		}
		
		public void Print(Combatant user, IContentSimple content, int level)
		{
			if(ORK.ConsoleSettings.levelUpRange.InRange(user))
			{
				ORK.Game.Console.AddLine(
					this.text[ORK.Game.Language].
						Replace("%un", user.GetName()).
						Replace("%n", content.GetName()).
						Replace("%", level.ToString()), 
					this.typeID);
			}
		}
	}
}
