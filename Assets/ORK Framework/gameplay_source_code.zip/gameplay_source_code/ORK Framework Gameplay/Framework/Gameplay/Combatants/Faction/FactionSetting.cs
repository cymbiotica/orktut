
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class FactionSetting : BaseLanguageData, IContentSimple
	{
		// sympathy changes
		[ORKEditorHelp("Kill Member", "Killing a member of this faction will change the sympathy " +
			"(for the attacking factions) by this value.\n" +
			"The sympathy for all factions participating in the attack on the member will be changed.\n" +
			"Use negative values to decrease sympathy, positive values to increase.", "")]
		[ORKEditorInfo("Sympathy Changes", "Define how interactions with a member of a faction " +
			"change the faction's sympathy toward another faction.", "")]
		public float changeKill = -1;
		
		[ORKEditorHelp("Take Item", "Taking an item that belongs to this faction will change the sympathy by this value.\n" +
			"Use negative values to decrease sympathy, positive values to increase.", "")]
		public float changeItem = -1;
		
		[ORKEditorHelp("Take Money", "Taking money that belongs to this faction will change the sympathy by this value.\n" +
			"Use negative values to decrease sympathy, positive values to increase.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public float changeMoney = -1;
		
		
		// benefits
		[ORKEditorHelp("Benefit", "This benefit will be available for this faction.\n" +
			"If disabled, the benefit wont be available.\n" +
			"The first available benefit with suitable range will be used.", "")]
		[ORKEditorInfo("Sympathy Benefits", "You can add faction benefits to this faction.\n" +
			"A benefit is used if the sympathy value this faction has for the player is within the range of the benefit.", "", 
			endFoldout=true)]
		[ORKEditorArray(ORKDataType.FactionBenefit)]
		public bool[] benefits = new bool[ORK.FactionBenefits.Count];
		
		
		// phase change events
		[ORKEditorHelp("Phase Start Event", "Select the ORK phase change event that " +
			"will be performed when this faction's phase starts.\n" +
			"Phase change events are used in 'Phase' battles to animate the start and end of a faction's phase.", "")]
		[ORKEditorInfo("Phase Change Events", "Phase change events are used in 'Phase' battles to animate the start and end of a faction's phase.\n" +
			"Define this faction's phase start and phase end events.", "")]
		public ORKPhaseChangeEvent phaseStartAsset;
		
		[ORKEditorHelp("Phase End Event", "Select the ORK phase change event that " +
			"will be performed when this faction's phase ends.\n" +
			"Phase change events are used in 'Phase' battles to animate the start and end of a faction's phase.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public ORKPhaseChangeEvent phaseEndAsset;
		
		public FactionSetting()
		{
			
		}
		
		public FactionSetting(string n) : base(n)
		{
			
		}
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get{ return this.realID;}
		}

		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].GetDescription();
		}
		
		public string GetIconTextCode()
		{
			return TextCode.FactionIcon + this.realID + "#";
		}

		public Texture2D GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}
	}
}
