
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GroupAbilities : ISaveData
	{
		private Group owner;
		
		private AbilityShortcut[] learned = new AbilityShortcut[0];
		
		
		// change
		public event GroupAbilitiesChanged Changed;
		
		public GroupAbilities()
		{
			
		}
		
		public GroupAbilities(Group owner)
		{
			this.owner = owner;
		}
		
		public void LeaderChanged(Combatant oldLeader, Combatant newLeader)
		{
			for(int i=0; i<this.learned.Length; i++)
			{
				this.learned[i].UnregisterStatusChanges(oldLeader);
				this.learned[i].RegisterStatusChanges(newLeader);
			}
		}
		
		public void FireChanged()
		{
			if(this.Changed != null)
			{
				this.Changed(this.owner);
			}
		}
		
		public List<AbilityShortcut> GetAbilities()
		{
			return new List<AbilityShortcut>(this.learned);
		}
		
		
		/*
		============================================================================
		Learn functions
		============================================================================
		*/
		/// <summary>
		/// Determines whether the specified ability has been learned.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the ability has been learned; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='lvl'>
		/// The minimum level that has to be learned.
		/// </param>
		public bool HasLearned(int id, int lvl)
		{
			for(int i=0; i<this.learned.Length; i++)
			{
				if(this.learned[i].ID == id &&
					this.learned[i].Level >= lvl)
				{
					return true;
				}
			}
			return false;
		}
		
		/// <summary>
		/// Gets a learned ability.
		/// </summary>
		/// <returns>
		/// The ability if learned, else <c>null</c>.
		/// </returns>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		public AbilityShortcut GetLearned(int id)
		{
			for(int i=0; i<this.learned.Length; i++)
			{
				if(this.learned[i].ID == id)
				{
					return this.learned[i];
				}
			}
			return null;
		}
		
		
		/// <summary>
		/// Forgets an ability.
		/// </summary>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='showConsole'>
		/// <c>true</c> to display in the console.
		/// </param>
		public bool Forget(int id, bool showConsole)
		{
			if(this.HasLearned(id, 0))
			{
				AbilityShortcut ab = this.GetLearned(id);
				if(ab != null)
				{
					ArrayHelper.Remove(ref this.learned, ab);
					ab.UnregisterStatusChanges(this.owner.BattleLeader);
					
					if(showConsole && ORK.ConsoleSettings.displayForgetting)
					{
						Ability ability = ORK.Abilities.Get(id);
						if(ability.ownConsoleGroupForgetting)
						{
							ability.consoleGroupForgetting.PrintForgetRange(
								this.owner.GetBattle(), ability);
						}
						else
						{
							ORK.ConsoleSettings.forgetGroupAbility.PrintForgetRange(
								this.owner.GetBattle(), ability);
						}
					}
					
					this.FireChanged();
					return true;
				}
			}
			return false;
		}
		
		/// <summary>
		/// Learns an ability.
		/// </summary>
		/// <param name='id'>
		/// The ID (index) of the ability.
		/// </param>
		/// <param name='lvl'>
		/// The level that will be learned
		/// </param>
		/// <param name='showConsole'>
		/// <c>true</c> to display in the console.
		/// </param>
		public bool Learn(int id, int lvl, bool showConsole)
		{
			if(!this.HasLearned(id, lvl))
			{
				bool add = true;
				for(int i=0; i<this.learned.Length; i++)
				{
					if(this.learned[i].ID == id)
					{
						PassiveAbility passiveLevel = this.learned[i].GetPassiveLevel();
						this.learned[i].Level = lvl;
						this.learned[i].SetUseLevel(lvl);
						add = false;
						
						if(passiveLevel != null)
						{
							List<Combatant> list = this.owner.GetGroup();
							for(int j=0; j<list.Count; j++)
							{
								passiveLevel.autoEffects.RemoveEffects(list[j]);
							}
						}
						
						break;
					}
				}
				if(add)
				{
					AbilityShortcut ab = new AbilityShortcut(id, lvl, AbilityActionType.Ability);
					ArrayHelper.Add(ref this.learned, ab);
					ab.RegisterStatusChanges(this.owner.BattleLeader);
				}
				
				if(showConsole && ORK.ConsoleSettings.displayLearning)
				{
					Ability ability = ORK.Abilities.Get(id);
					if(ability.ownConsoleGroupLearning)
					{
						ability.consoleGroupLearning.PrintLearnRange(
							this.owner.GetBattle(), ability);
					}
					else
					{
						ORK.ConsoleSettings.learnGroupAbility.PrintLearnRange(
							this.owner.GetBattle(), ability);
					}
				}
				
				this.FireChanged();
				return true;
			}
			return false;
		}
		
		
		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			
			DataObject[] tmp = new DataObject[this.learned.Length];
			for(int i=0; i<tmp.Length; i++)
			{
				tmp[i] = this.learned[i].SaveGame();
			}
			data.Set("learned", tmp);
			
			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.learned = new AbilityShortcut[0];
			if(data != null)
			{
				DataObject[] tmp = data.GetFileArray("learned");
				if(tmp != null)
				{
					this.learned = new AbilityShortcut[tmp.Length];
					for(int i=0; i<tmp.Length; i++)
					{
						this.learned[i] = new AbilityShortcut();
						this.learned[i].LoadGame(tmp[i]);
						this.learned[i].RegisterStatusChanges(this.owner.BattleLeader);
					}
				}
			}
		}
	}
}
