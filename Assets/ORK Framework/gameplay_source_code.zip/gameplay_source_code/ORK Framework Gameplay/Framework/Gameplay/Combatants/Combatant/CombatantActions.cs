
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework
{
	public class CombatantActions
	{
		private Combatant owner;
		
		
		// queue
		private Queue<BaseAction> actionQueue = new Queue<BaseAction>();
		
		private bool actionFired = false;
		
		private bool finishAttackQueue = false;
		
		
		// cast time
		private bool castingAbility = false;
		
		private AbilityAction castAbilityAction = null;
		
		
		// flags
		private bool isChoosingAction = false;
		
		private bool inAction = false;
		
		private bool waitForAction = false;
		
		
		// ai
		private float aiTimeoutTimer = 0;
		
		private BaseAction aiAction = null;
		
		private Combatant rtCounterFlag;
		
		private List<BaseAction> nextAction = new List<BaseAction>();
		
		
		// auto attack
		private bool autoAttacking = false;
		
		private float autoAttackTime = 0;
		
		public CombatantActions(Combatant owner)
		{
			this.owner = owner;
		}
		
		/// <summary>
		/// Clears the queued actions and states - used at the start and end of a battle.
		/// </summary>
		/// <param name='start'>
		/// <c>true</c> if at the start of a battle.
		/// </param>
		public void Clear(bool start)
		{
			this.actionQueue.Clear();
			this.actionFired = false;
			this.finishAttackQueue = false;
			
			this.isChoosingAction = false;
			this.waitForAction = false;
			if(this.castingAbility && this.castAbilityAction != null && 
				!this.castAbilityAction.castMove)
			{
				this.owner.Status.ChangeStopMovement(-1);
			}
			this.castingAbility = false;
			this.castAbilityAction = null;
			this.autoAttacking = false;
			this.InAction = false;
			this.rtCounterFlag = null;
			this.aiAction = null;
			this.nextAction.Clear();
			
			if(start)
			{
				this.autoAttackTime = Random.Range(0.0f, this.owner.Setting.autoAttack.interval);
			}
		}
		
		/// <summary>
		/// Gets the number of queued actions.
		/// </summary>
		/// <value>
		/// The action count.
		/// </value>
		public int Count
		{
			get{ return this.actionQueue.Count;}
		}
		
		/// <summary>
		/// Gets or sets a value indicating whether the combatant is in action (i.e. performs a battle action).
		/// </summary>
		/// <value>
		/// <c>true</c> if in action; otherwise, <c>false</c>.
		/// </value>
		public bool InAction
		{
			get{ return this.inAction || this.castingAbility;}
			set
			{
				this.inAction = value;
				
				if(!this.inAction)
				{
					if(this.autoAttacking)
					{
						this.autoAttacking = false;
						this.autoAttackTime = this.owner.Setting.autoAttack.interval;
					}
					else
					{
						this.waitForAction = false;
					}
				}
			}
		}
		
		/// <summary>
		/// Gets or sets a value indicating whether the combatant is choosing an action.
		/// </summary>
		/// <value>
		/// <c>true</c> if choosing; otherwise, <c>false</c>.
		/// </value>
		public bool IsChoosing
		{
			get{ return this.isChoosingAction;}
			set{ this.isChoosingAction = value;}
		}
		
		/// <summary>
		/// Gets a value indicating whether the combatant can choose an action.
		/// </summary>
		/// <value>
		/// <c>true</c> if the combatant can choose; otherwise, <c>false</c>.
		/// </value>
		public bool CanChoose
		{
			get
			{
				return !this.owner.Dead && !this.owner.TurnEnded && 
					!this.IsChoosing &&
					(!this.InAction || this.autoAttacking) &&
					!this.owner.Status.StopMove &&
				//!this.owner.Status.AutoAttack && 
				//!this.owner.Status.AttackAllies && 
					((ORK.Battle.IsActiveTime() && ORK.BattleSystem.activeTime.multiChoice) ||
						!this.waitForAction) && 
					(!ORK.Battle.IsActiveTime() || (!this.finishAttackQueue && 
						this.owner.UsedTimeBar < ORK.BattleSystem.activeTime.maxTimebar));
			}
		}
		
		/// <summary>
		/// The combatant chooses a battle action.
		/// Depending on the combatant (e.g. player, enemy, AI controlled), 
		/// either displays the battle menu or chooses an action based on AI settings.
		/// </summary>
		public void Choose()
		{
			if(this.owner.InitNewTurn(true))
			{
				this.isChoosingAction = true;
				
				List<Combatant> allies = ORK.Game.Combatants.Get(this.owner, 
					true, Range.Battle, Consider.No, Consider.Ignore, Consider.Yes);
				List<Combatant> enemies = ORK.Game.Combatants.Get(this.owner, 
					true, Range.Battle, Consider.Yes, Consider.Ignore, Consider.Yes);
				
				if(this.owner.Status.StopMove || 
					(this.owner.Status.AutoAttack && (this.owner.Status.BlockAttack || enemies.Count == 0)) ||
					(this.owner.Status.AttackAllies && (this.owner.Status.BlockAttack || allies.Count == 0)))
				{
					this.Add(new NoneAction(this.owner), false);
				}
				else if(this.owner.Status.AutoAttack || this.owner.Status.AttackAllies)
				{
					if(this.owner.IsAIControlled())
					{
						this.aiTimeoutTimer = ORK.BattleSettings.aiRecheckTime;
					}
					
					BaseAction action = new AbilityAction(this.owner, this.owner.GetCurrentBaseAttack());
					action.AutoTarget(this.owner.LastTargets, allies, enemies);
					this.Add(action, false);
				}
				else if(this.nextAction.Count > 0)
				{
					BaseAction action = this.nextAction[0];
					this.nextAction.RemoveAt(0);
					this.Add(action, false);
				}
				else if(this.owner.IsAIControlled())
				{
					this.Add(this.GetAIBehaviourAction(allies, enemies), false);
				}
				else if(this.owner.IsPlayerControlled())
				{
					this.owner.ShowBattleMenu();
				}
				else
				{
					this.owner.EndTurn();
				}
			}
			else
			{
				this.owner.EndTurn();
			}
		}
		
		public void ChooseAuto()
		{
			if(this.owner.InitNewTurn(true))
			{
				this.isChoosingAction = true;
				this.Add(this.GetAIBehaviourAction(
						ORK.Game.Combatants.Get(this.owner, true, Range.Battle, 
							Consider.No, Consider.Ignore, Consider.Ignore), 
						ORK.Game.Combatants.Get(this.owner, true, Range.Battle, 
							Consider.Yes, Consider.Ignore, Consider.Ignore)), 
					false);
			}
			else
			{
				this.owner.EndTurn();
			}
		}
		
		
		/*
		============================================================================
		Auto attack functions
		============================================================================
		*/
		/// <summary>
		/// Gets a value indicating whether the combatant is currently auto attacking.
		/// </summary>
		/// <value>
		/// <c>true</c> if auto attacking; otherwise, <c>false</c>.
		/// </value>
		public bool AutoAttacking
		{
			get{ return this.autoAttacking;}
		}
		
		
		/*
		============================================================================
		Battle action functions
		============================================================================
		*/
		/// <summary>
		/// Lets the combatant fire a battle action. 
		/// Depending on the state and battle systems the action can be added to the 
		/// battle's action queue, the combatant's action queue or not fired at all.
		/// </summary>
		/// <param name='action'>
		/// The action.
		/// </param>
		/// <param name='newTurn'>
		/// <c>true</c> if a new turn should be initialized.
		/// </param>
		public void Add(BaseAction action, bool newTurn)
		{
			if(newTurn && !this.owner.InitNewTurn(true))
			{
				ORK.Battle.Actions.Add(null);
				return;
			}
			
			this.owner.EndBattleMenu(false);
			this.isChoosingAction = false;
			
			if(action != null && ORK.Battle.IsActiveTime())
			{
				bool add = true;
				if(!this.owner.Dead && !action.IsType(ActionType.CounterAttack) && !action.autoAttackFlag)
				{
					float tmp = action.TimeUse;
					if((!ORK.BattleSystem.activeTime.multiChoice && this.owner.UsedTimeBar == 0) || 
						(ORK.BattleSystem.activeTime.multiChoice && 
						this.owner.UsedTimeBar + tmp <= ORK.BattleSystem.activeTime.maxTimebar))
					{
						this.owner.UsedTimeBar += tmp;
					}
					else
					{
						add = false;
						ORK.Battle.Actions.Add(null);
					}
				}
				
				if(add)
				{
					if(this.owner.TimeBar < ORK.BattleSystem.activeTime.actionBorder || 
						this.actionQueue.Count > 0 || this.actionFired)
					{
						this.actionQueue.Enqueue(action);
					}
					else
					{
						this.actionFired = true;
						ORK.Battle.Actions.Add(action);
					}
				}
			}
			else
			{
				this.actionFired = true;
				ORK.Battle.Actions.Add(action);
			}
		}
		
		/// <summary>
		/// Notifies the combatant that his actions 
		/// have been removed from the battle's action queue.
		/// </summary>
		public void Removed()
		{
			this.actionFired = false;
			this.finishAttackQueue = false;
			this.owner.TurnEnded = false;
			this.owner.TurnPerformed = true;
			this.waitForAction = false;
			this.owner.TurnValue = 0;
			this.owner.TimeBar = 0;
			this.owner.UsedTimeBar = 0;
		}
		
		/// <summary>
		/// Dequeues the next action from the combatant's action queue 
		/// and add's it to the battle's action queue.
		/// </summary>
		/// <returns>
		/// <c>true</c> if an action was available; otherwise <c>false</c>.
		/// </returns>
		public bool DequeueNextAction()
		{
			if(this.actionQueue.Count > 0)
			{
				this.actionFired = true;
				this.waitForAction = true;
				this.owner.Defending = false;
				ORK.Battle.Actions.Add(this.actionQueue.Dequeue());
				return true;
			}
			else
			{
				this.actionFired = false;
				this.finishAttackQueue = false;
				this.owner.TurnEnded = false;
				this.waitForAction = false;
				return false;
			}
		}
		
		/// <summary>
		/// Adds a battle action as next action of the combatant. 
		/// The combatant will try to use this action the next time he can choose an action.
		/// </summary>
		/// <param name='action'>
		/// The battle action.
		/// </param>
		public void AddNextAction(BaseAction action, NextBattleActionChange actionChange)
		{
			if(action != null)
			{
				if(NextBattleActionChange.Add.Equals(actionChange))
				{
					this.nextAction.Add(action);
				}
				else if(NextBattleActionChange.Set.Equals(actionChange))
				{
					this.nextAction.Clear();
					this.nextAction.Add(action);
				}
				else if(NextBattleActionChange.First.Equals(actionChange))
				{
					this.nextAction.Insert(0, action);
				}
			}
		}
		
		/// <summary>
		/// Gets or sets a value indicating whether the combatant should finish his action queue 
		/// (i.e. use all actions added to his queue).
		/// </summary>
		/// <value>
		/// <c>true</c> if the action queue should be finished; otherwise, <c>false</c>.
		/// </value>
		public bool FinishAttackQueue
		{
			get{ return this.finishAttackQueue;}
			set{ this.finishAttackQueue = value;}
		}
		
		/// <summary>
		/// Gets or sets a value indicating whether the combatant is waiting for an action to start.
		/// </summary>
		/// <value>
		/// <c>true</c> if waiting; otherwise, <c>false</c>.
		/// </value>
		public bool IsWaiting
		{
			get{ return this.waitForAction;}
			set{ this.waitForAction = value;}
		}
		
		/// <summary>
		/// Gets a value indicating whether the combatant fired an action.
		/// </summary>
		/// <value>
		/// <c>true</c> if fired; otherwise, <c>false</c>.
		/// </value>
		public bool Fired
		{
			get{ return this.actionFired;}
		}
		
		/// <summary>
		/// Checks if the combatant is able to perform an action.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the combatant can perform actions; otherwise false.
		/// </returns>
		/// <param name='isAutoAttack'>
		/// <c>true</c> if checking for performing an auto attack.
		/// </param>
		public bool AllowPerformingAction(bool isAutoAttack)
		{
			return !this.InAction && (!ORK.Battle.IsActiveTime() || 
					(this.owner.TimeBar >= this.owner.UsedTimeBar && 
					(this.finishAttackQueue || isAutoAttack || 
						((UseTimebarAction.ActionBorder.Equals(ORK.BattleSystem.activeTime.useTimebarAction) && 
							this.owner.TimeBar >= ORK.BattleSystem.activeTime.actionBorder) ||
						(UseTimebarAction.MaxTimebar.Equals(ORK.BattleSystem.activeTime.useTimebarAction) && 
							this.owner.TimeBar >= ORK.BattleSystem.activeTime.maxTimebar) ||
						(UseTimebarAction.EndTurn.Equals(ORK.BattleSystem.activeTime.useTimebarAction) && this.owner.TurnEnded)))));
		}
		
		
		/*
		============================================================================
		Ability cast functions
		============================================================================
		*/
		/// <summary>
		/// Determines whether the combatant is casting an ability.
		/// </summary>
		/// <returns>
		/// <c>true</c> if casting; otherwise, <c>false</c>.
		/// </returns>
		public bool IsCastingAbility
		{
			get{ return this.castingAbility && this.castAbilityAction != null;}
		}
		
		/// <summary>
		/// Gets the name of the casting ability.
		/// </summary>
		/// <returns>
		/// The ability name.
		/// </returns>
		public string GetCastAbilityName()
		{
			if(this.castingAbility && this.castAbilityAction != null)
			{
				return this.castAbilityAction.GetName();
			}
			return "";
		}
		
		/// <summary>
		/// The combatant will cast a defined ability.
		/// </summary>
		/// <param name='action'>
		/// The ability action to cast.
		/// </param>
		public void CastAbility(AbilityAction action)
		{
			this.castAbilityAction = action;
			this.castingAbility = true;
			if(!this.castAbilityAction.castMove)
			{
				this.owner.Status.ChangeStopMovement(1);
			}
		}
		
		/// <summary>
		/// Gets the remaining cast time of the casting ability.
		/// </summary>
		/// <returns>
		/// The cast time.
		/// </returns>
		public float GetCastTime()
		{
			float time = -1;
			if(this.castingAbility && this.castAbilityAction != null)
			{
				time = this.castAbilityAction.castTime;
			}
			return time;
		}
		
		/// <summary>
		/// Gets the maximum cast time of the casting ability.
		/// </summary>
		/// <returns>
		/// The maximum cast time.
		/// </returns>
		public float GetCastTimeMax()
		{
			float time = -1;
			if(this.castingAbility && this.castAbilityAction != null)
			{
				time = this.castAbilityAction.castTimeMax;
			}
			return time;
		}
		
		/// <summary>
		/// Cancel casting an ability.
		/// </summary>
		public void CancelCast()
		{
			if(this.castingAbility && this.castAbilityAction != null && 
				this.castAbilityAction.CancelAbilityCast())
			{
				if(ORK.BattleTexts.useCastCancelNotification && ORK.BattleTexts.castCancelTextSettings != null)
				{
					ORK.BattleTexts.castCancelTextSettings.ShowText(this.GetCastAbilityName(), this.owner.GameObject);
				}
				this.castingAbility = false;
				if(!this.castAbilityAction.castMove)
				{
					this.owner.Status.ChangeStopMovement(-1);
				}
				this.waitForAction = false;
				if(!this.castAbilityAction.autoAttackFlag)
				{
					this.owner.TimeBar -= this.castAbilityAction.TimeUse;
					this.owner.UsedTimeBar -= this.castAbilityAction.TimeUse;
				}
				this.castAbilityAction = null;
				this.DequeueNextAction();
			}
		}
		
		
		/*
		============================================================================
		AI functions
		============================================================================
		*/
		/// <summary>
		/// Sets a combatant to be the target of a counter attack in 'Real Time' battles.
		/// </summary>
		/// <value>
		/// The combatant that will be used as target.
		/// </value>
		public Combatant RTCounter
		{
			set{ this.rtCounterFlag = value;}
		}
		
		/// <summary>
		/// Gets a battle action based on the AI settings and BattleAI of the combatant.
		/// </summary>
		/// <returns>
		/// The selected battle action.
		/// </returns>
		/// <param name='allies'>
		/// A list of combatants allied to the combatant.
		/// </param>
		/// <param name='enemies'>
		/// A list of combatants who are enemies of the combatant.
		/// </param>
		public BaseAction GetAIBehaviourAction(List<Combatant> allies, List<Combatant> enemies)
		{
			// get in battle range
			allies = TargetHelper.GetCombatantsInRange(this.owner, allies);
			enemies = TargetHelper.GetCombatantsInRange(this.owner, enemies);
			
			BaseAction action = null;
			
			if(ORK.BattleSettings.aiRange.InRange(this.owner, ORK.Game.ActiveGroup.Leader))
			{
				if(this.rtCounterFlag != null)
				{
					action = BaseAction.CreateAbility(this.owner, this.owner.GetCounterAttack(), -2);
					if(action != null)
					{
						action.SetTarget(this.rtCounterFlag);
					}
				}
				else
				{
					for(int i=0; i<this.owner.Setting.aiBehaviour.Length; i++)
					{
						action = this.owner.Setting.aiBehaviour[i].GetAction(this.owner, allies, enemies);
						if(action != null)
						{
							break;
						}
					}
					
					// set up base attack if no action was found
					if(action == null)
					{
						if(this.owner.Status.BlockAttack || enemies.Count == 0)
						{
							action = new NoneAction(this.owner);
						}
						else
						{
							action = BaseAction.CreateAbility(this.owner, this.owner.GetCurrentBaseAttack(), -2);
							if(action != null)
							{
								if((!this.owner.Setting.attackGroupTarget || !action.SetGroupTarget()) && 
									(!this.owner.Setting.attackIndividualTarget || !action.SetIndividualTarget()))
								{
									List<Combatant> targets = new List<Combatant>();
									if(this.owner.Setting.attackLastTarget && 
										this.owner.LastTargets != null && this.owner.LastTargets.Count > 0)
									{
										targets.AddRange(this.owner.LastTargets);
									}
									action.AutoTarget(targets, allies, enemies);
								}
							}
							else
							{
								action = new NoneAction(this.owner);
							}
						}
					}
				}
				
				if(action != null && !action.IsType(ActionType.None))
				{
					if(!action.HasTargets() && 
						(!action.HasOutOfRangeTargets() || !ORK.Battle.CanUseMoveAI(this.owner)))
					{
						action = new NoneAction(this.owner);
					}
					else if(ORK.Battle.IsRealTime() && !action.InRange())
					{
						Combatant nearest = action.GetNearestTarget();
						if(nearest != null && action.InBattleRange() && 
							this.owner.MoveAI != null)
						{
							this.owner.MoveAI.SetTarget(nearest, MoveAIMode.Hunt);
							this.aiAction = action;
							action = null;
						}
						else
						{
							action = new NoneAction(this.owner);
						}
					}
					else if(this.owner.MoveAI != null)
					{
						this.owner.MoveAI.Stop();
					}
				}
				
				// set AI timeout timer
				if(this.rtCounterFlag != null)
				{
					this.rtCounterFlag = null;
					this.aiTimeoutTimer = 0;
				}
				else
				{
					this.aiTimeoutTimer = this.owner.Setting.aiTimeout;
				}
			}
			else
			{
				action = new NoneAction(this.owner);
				this.aiTimeoutTimer = ORK.BattleSettings.aiRecheckTime;
			}
			
			if(action != null && ORK.Battle.IsActiveTime() && 
				this.owner.UsedTimeBar + action.TimeUse > ORK.BattleSystem.activeTime.maxTimebar)
			{
				action = new NoneAction(this.owner);
			}
			
			if(action == null)
			{
				this.owner.EndTurn();
			}
			
			return action;
		}
		
		/// <summary>
		/// Removes a waiting AI action and resets the combatant's waiting state.
		/// </summary>
		public void ClearAIAction()
		{
			if(this.aiAction != null)
			{
				this.aiAction = null;
				this.aiTimeoutTimer = this.owner.Setting.aiTimeout;
				this.waitForAction = false;
			}
		}
		
		
		/*
		============================================================================
		Time functions
		============================================================================
		*/
		/// <summary>
		/// Update function called each frame.
		/// </summary>
		/// <param name='bt'>
		/// The time since the last tick.
		/// </param>
		public void Tick(float bt)
		{
			// ability casting
			if(this.castingAbility && this.castAbilityAction != null && !this.autoAttacking)
			{
				this.castAbilityAction.castTime += bt;
				if(this.castAbilityAction.castTime >= this.castAbilityAction.castTimeMax)
				{
					this.castAbilityAction.casted = true;
					ORK.Battle.Actions.Perform(this.castAbilityAction);
					this.castingAbility = false;
					if(!this.castAbilityAction.castMove)
					{
						this.owner.Status.ChangeStopMovement(-1);
					}
					this.castAbilityAction = null;
				}
				this.owner.MarkHUDUpdate();
			}
			
			if(this.owner.InBattle)
			{
				// auto attack
				if(this.owner.EnableAutoAttack && 
					!this.autoAttacking && !this.owner.Defending &&
					this.owner.Setting.autoAttack.active && !this.InAction &&
					ORK.Battle.IsDynamicCombat() && ORK.Battle.CanAutoAttack &&
					(!this.isChoosingAction || !ORK.Battle.MenuBlockAutoAttack))
				{
					if(this.autoAttackTime > 0)
					{
						this.autoAttackTime -= bt;
					}
					else if(!this.owner.Status.StopMove)
					{
						BaseAction autoAction = this.owner.Setting.autoAttack.GetAction(this.owner);
						if(autoAction != null)
						{
							this.autoAttacking = true;
							this.Add(autoAction, false);
						}
					}
				}
				
				// real time AI
				if(ORK.Battle.IsRealTime() && !ORK.Battle.BattleEnd && 
					ORK.Control.InBattle && !this.owner.Dead && this.owner.IsAggressive && 
					(!this.owner.Setting.limitAIRange || this.owner.IsLeader || 
						this.owner.Setting.aiRange.InRange(this.owner, this.owner.Group.Leader)))
				{
					if(this.aiAction == null && this.CanChoose)
					{
						if(this.aiTimeoutTimer > 0)
						{
							this.aiTimeoutTimer -= bt;
						}
						if((this.aiTimeoutTimer <= 0 || this.rtCounterFlag != null) && 
							this.owner.IsAIControlled())
						{
							this.Choose();
						}
					}
					else if(this.aiAction != null)
					{
						this.aiAction.UpdateTargets();
						if(this.aiAction.InRange())
						{
							if(this.owner.MoveAI != null)
							{
								this.owner.MoveAI.Stop();
							}
							this.Add(this.aiAction, false);
							this.aiAction = null;
						}
					}
				}
			}
		}
	}
}
