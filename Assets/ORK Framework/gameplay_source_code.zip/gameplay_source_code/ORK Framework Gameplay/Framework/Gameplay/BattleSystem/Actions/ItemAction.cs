
using System.Collections.Generic;
using UnityEngine;
using ORKFramework.Behaviours;

namespace ORKFramework
{
	public class ItemAction : BaseAction
	{
		private ItemShortcut item;
		
		public bool forceFoundTargets = false;
		
		public ItemAction(Combatant user, ItemShortcut item)
		{
			this.user = user;
			this.item = item;
			
			this.targetDead = this.item.Setting.targetSettings.isDead;
			this.targetRaycast = this.item.Setting.targetSettings.targetRaycast;
			if(ItemAbilityType.Use.Equals(this.item.Setting.itemAbility))
			{
				AbilityLevel activeLevel = ORK.Abilities.Get(this.item.Setting.useAbilityID).GetLevel(this.item.Setting.abilityLevel - 1);
				if(activeLevel != null && activeLevel.active != null)
				{
					this.targetDead = activeLevel.active.targetSettings.isDead;
				}
			}
			
			if(ORK.BattleSystem.activeTime.itemEndTurn)
			{
				this.timeUse = ORK.BattleSystem.activeTime.actionBorder;
			}
			else
			{
				this.timeUse = ORK.BattleSystem.activeTime.itemTimebarUse;
			}
		}
		
		public override bool IsType(ActionType t)
		{
			return ActionType.Item.Equals(t);
		}
		
		public override string GetName()
		{
			return this.item.GetName();
		}
		
		public override void SetTarget(Combatant t)
		{
			this.target = new List<Combatant>();
			this.target.Add(t);
		}
		
		public override void SetTargets(List<Combatant> t)
		{
			this.target = t;
		}
		
		public override void AutoTarget(List<Combatant> preferredTargets, List<Combatant> allies, List<Combatant> enemies)
		{
			if(this.user.Status.AttackAllies)
			{
				enemies = allies;
			}
			this.item.Setting.targetSettings.SetAutoTargets(this, preferredTargets, allies, enemies);
		}
		
		public override bool SetGroupTarget()
		{
			Combatant tmpTarget = this.user.Group.SelectedTargets.GetItemTarget(this.user, this.item);
			if(tmpTarget != null)
			{
				this.SetTarget(tmpTarget);
				return true;
			}
			return false;
		}
		
		public override bool SetIndividualTarget()
		{
			Combatant tmpTarget = this.user.SelectedTargets.GetItemTarget(this.user, this.item);
			if(tmpTarget != null)
			{
				this.SetTarget(tmpTarget);
				return true;
			}
			return false;
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool CanDamage(Combatant c)
		{
			return (this.user.Status.AttackAllies || 
				this.item.CanTarget(this.user, c));
		}
		
		
		/*
		============================================================================
		Damage dealer functions
		============================================================================
		*/
		public override void AutoActivateUserDamageDealers(bool activate)
		{
			if(this.user != null && this.user.GameObject != null)
			{
				DamageDealer[] damage = this.user.GameObject.GetComponentsInChildren<DamageDealer>();
				for(int i=0; i<damage.Length; i++)
				{
					if((!this.user.InBattle && damage[i].autoField) || 
						(this.user.InBattle && 
							((ORK.Battle.IsTurnBased() && damage[i].autoTurnBased) || 
							(ORK.Battle.IsActiveTime() && damage[i].autoActiveTime) || 
							(ORK.Battle.IsRealTime() && damage[i].autoRealTime) || 
							(ORK.Battle.IsRealTime() && damage[i].autoRealTime))))
					{
						damage[i].SetAction(activate ? this : null);
						damage[i].SetDamageActive(activate, this.item.Setting.activationTags);
						this.item.Setting.ddActivation.Add(damage[i], this.user);
					}
				}
			}
		}
		
		public override bool CheckDamageDealer(DamageDealer dealer)
		{
			for(int i=0; i<dealer.itemID.Length; i++)
			{
				if(dealer.itemID[i] == this.item.ID)
				{
					return true;
				}
			}
			return false;
		}
		
		public override string[] GetActivationTags()
		{
			return this.item.Setting.activationTags;
		}
		
		public override DamageDealerActivation GetDamageDealerActivation()
		{
			return this.item.Setting.ddActivation;
		}
		
		
		/*
		============================================================================
		Target selection functions
		============================================================================
		*/
		public override void SetRandomTarget()
		{
			if(this.forceFoundTargets)
			{
				List<Combatant> list = new List<Combatant>();
				if(this.target != null)
				{
					list.AddRange(this.target);
					this.target = null;
				}
				if(this.outOfRange != null)
				{
					list.AddRange(this.outOfRange);
					this.outOfRange = null;
				}
				
				if(this.item.Setting.targetSettings.TargetSelf())
				{
					this.AutoTarget(list, 
						ORK.Game.Combatants.Get(this.user, true, Range.Battle, 
							Consider.No, Consider.Ignore, Consider.Ignore), 
						ORK.Game.Combatants.Get(this.user, true, Range.Battle, 
							Consider.Yes, Consider.Ignore, Consider.Ignore));
				}
				else if(this.item.Setting.targetSettings.TargetEnemy())
				{
					this.AutoTarget(list, 
						ORK.Game.Combatants.Get(this.user, true, Range.Battle, 
							Consider.No, Consider.Ignore, Consider.Ignore), 
						list);
				}
				else if(this.item.Setting.targetSettings.TargetAlly())
				{
					this.AutoTarget(list, list, 
						ORK.Game.Combatants.Get(this.user, true, Range.Battle, 
							Consider.Yes, Consider.Ignore, Consider.Ignore));
				}
				else if(this.item.Setting.targetSettings.TargetAll())
				{
					this.AutoTarget(list, list, list);
				}
			}
			else
			{
				this.AutoTarget(null, 
					ORK.Game.Combatants.Get(this.user, true, Range.Battle, 
						Consider.No, Consider.Ignore, Consider.Ignore), 
					ORK.Game.Combatants.Get(this.user, true, Range.Battle, 
						Consider.Yes, Consider.Ignore, Consider.Ignore));
			}
		}
		
		public override bool TargetNone()
		{
			return this.item.Setting.targetSettings.NoneTarget();
		}
		
		
		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public override bool InRange(Combatant t)
		{
			if(this.user != null && t != null && 
				!this.item.Setting.InRange(this.user, t))
			{
				return false;
			}
			return true;
		}
		
		
		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null && !this.user.Dead && 
				this.item.CanUse(this.user, false) && 
				(this.item.Setting.targetSettings.NoneTarget() || this.target.Count > 0);
		}
		
		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.itemInfo.Show(this.user, this.item.GetName());
			}
			
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.item.Setting.ownConsoleAction)
				{
					this.item.Setting.consoleAction.Print(this.user, this.target, this.item);
				}
				else
				{
					ORK.ConsoleSettings.actionItem.Print(this.user, this.target, this.item);
				}
			}
			
			if(this.item.Setting.animate)
			{
				this.item.Setting.GetAnimations(ref this.events, this.user);
			}
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			this.results = new ActionResults();
			
			// get affected range targets for this calculation
			ts = this.item.Setting.targetSettings.GetAffectRange(this.user, ts);
			
			if(ORK.BattleSettings.camera.blockEventCams)
			{
				if(ts.Count == 1 && ts[0] != null && ts[0].GameObject != null)
				{
					ORK.BattleSettings.camera.SetLatestDamage(ts[0].GameObject.transform);
				}
				else if(ts.Count > 1)
				{
					ORK.BattleSettings.camera.SetLatestDamage(ORK.Battle.GetGroupCenter(ts).transform);
				}
			}
			
			if(this.user != null && !this.user.Dead && 
				ts.Count > 0 && ts[0] != null)
			{
				this.CheckBestiary(ts);
				
				this.item.Setting.Use(this.user, ts, animate, !this.userConsumeDone, 
					this, damageFactor, this.damageMultiplier);
				this.userConsumeDone = true;
			}
		}
		
		public override void ConsumeCosts()
		{
			if(this.item != null && this.user != null)
			{
				this.item.Setting.Consume(this.user);
			}
			this.userConsumeDone = true;
		}

		protected override void ActionEndSetup()
		{
			this.user.LastAbilityID = -1;
			
			// set delay time
			this.item.Setting.SetDelayTime(this.user);
		}
	}
}
