
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BackBMItem : BMItem
	{
		public BackBMItem(ChoiceContent content)
		{
			this.content = content;
		}

		public override void Selected(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				owner.BattleMenu.Back();
			}
		}
	}
}
