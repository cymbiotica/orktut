
using UnityEngine;

namespace ORKFramework
{
	public class LookAtSettings : BaseData
	{
		[ORKEditorHelp("Enable", "Use this 'look at' action.", "")]
		public bool enable = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds this look at will be active.\n" +
			"Set to 0 if you don't want the look at to end automatically.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("enable", true)]
		public float time = 0;
		
		[ORKEditorHelp("Simple Look", "The base battle camera will simply look at the " +
			"target and wont use a special camera position.\n" +
			"The camera will still rotate around the arena (if enabled) while looking at the target.", "")]
		public bool simpleLook = false;
		
		[ORKEditorHelp("Look At Child", "The camera will look at the defined child object " +
			"(e.g. Path/to/Child) of the target.\n" +
			"If the child object can't be found, the target object itself is used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("simpleLook", true)]
		public string pathToChild = "";
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorArray(false, "Add Camera Position", "Adds a camera position to this 'look at' action.\n" +
			"You can add as much camera positions per target as you want, the used camera position is chosen randomly.", "", 
			"Remove", "Removes the camera position", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Camera Position", "Define the used camera position and if the camera should rotate around the target.", ""})]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public CamPosRotation[] camPos = new CamPosRotation[0];
		
		
		// ingame
		private int index = 0;
		
		private Transform target = null;
		
		public LookAtSettings()
		{
			
		}
		
		public Transform Target
		{
			get{ return this.target;}
			set{ this.target = value;}
		}
		
		public void Set(Transform camera)
		{
			if(ORK.Control.CameraBlocked)
			{
				if(this.simpleLook && this.pathToChild != "")
				{
					this.target = TransformHelper.GetChild(this.pathToChild, this.target);
				}
				else if(this.camPos.Length > 0)
				{
					this.index = Random.Range(0, this.camPos.Length);
					ORK.CameraPositions.Get(this.camPos[this.index].camPosID).Use(camera, this.target);
				}
			}
		}
		
		public bool CheckCamPos()
		{
			return (this.simpleLook || 
				(this.camPos.Length > 0 && this.index < this.camPos.Length));
		}
		
		public void Rotate(Transform camera)
		{
			this.camPos[this.index].Rotate(camera, this.target.position);
		}
	}
}

