
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework
{
	public class AbilityBMItem : BMItem
	{
		private AbilityShortcut ability;
		
		public AbilityBMItem(AbilityShortcut ability, ChoiceContent content)
		{
			this.ability = ability;
			this.content = content;
		}
		
		public override void CreateDrag(Combatant owner)
		{
			if(this.content.drag == null)
			{
				// drag+drop
				this.content.isDragable = ORK.BattleSettings.bmDrag;
				this.content.clickCount = ORK.BattleSettings.bmClick ? ORK.BattleSettings.bmClickCount : 0;
				this.content.isTooltip = ORK.BattleSettings.bmTooltip;
				if(this.content.isDragable || this.content.clickCount > 0 || this.content.isTooltip)
				{
					this.content.drag = this.ability.GetDrag(owner.BattleMenu, owner);
				}
			}
			
			// portrait
			if(this.content.portrait == null && 
				owner.BattleMenu.Settings.showAbilityPortraits && 
				this.ability.HasPortrait())
			{
				this.content.portrait = this.ability.GetPortrait();
			}
		}
		
		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			this.content.Active = this.ability.CanUse(owner, 
				!AbilityActionType.CounterAttack.Equals(this.ability.Type)) && 
				(this.ability.NoneTarget() || 
					this.ability.GetPossibleTargets(owner, 
						ORK.Game.Combatants.Get(owner, true, Range.Battle, 
							Consider.No, Consider.Ignore, owner.InBattle ? Consider.Yes : Consider.Ignore), 
						ORK.Game.Combatants.Get(owner, true, Range.Battle, 
							Consider.Yes, Consider.Ignore, owner.InBattle ? Consider.Yes : Consider.Ignore)).Count > 0);
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				if(this.ability.TargetSelf())
				{
					BaseAction action = new AbilityAction(owner, this.ability);
					action.SetTarget(owner);
					owner.Actions.Add(action, false);
				}
				else if(this.ability.NoneTarget())
				{
					BaseAction action = new AbilityAction(owner, this.ability);
					if(action.targetRaycast.NeedInteraction())
					{
						owner.BattleMenu.RayAction = action;
					}
					else
					{
						if(action.targetRaycast.active)
						{
							action.rayTargetSet = true;
							action.rayPoint = action.targetRaycast.GetRayPoint(owner.GameObject, VectorHelper.GetScreenCenter());
						}
						owner.Actions.Add(action, false);
					}
				}
				else
				{
					// use on group target
					if(owner.BattleMenu.Settings.useGroupTarget)
					{
						Combatant target = owner.Group.SelectedTargets.GetAbilityTarget(owner, this.ability);
						if(target != null)
						{
							BaseAction action = new AbilityAction(owner, this.ability);
							action.SetTarget(target);
							owner.Actions.Add(action, false);
							return;
						}
					}
					// use on individual target
					if(owner.BattleMenu.Settings.useIndividualTarget)
					{
						Combatant target = owner.SelectedTargets.GetAbilityTarget(owner, this.ability);
						if(target != null)
						{
							BaseAction action = new AbilityAction(owner, this.ability);
							action.SetTarget(target);
							owner.Actions.Add(action, false);
							return;
						}
					}
					
					// display target menu
					ActiveAbility activeLevel = this.ability.GetActiveLevel();
					
					List<BMItem> list = new List<BMItem>();
					
					if(owner.BattleMenu.Settings.addBack && 
						owner.BattleMenu.Settings.backFirst && 
						ORK.BattleSettings.useTargetMenu)
					{
						list.Add(new BackBMItem(owner.BattleMenu.Settings.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton)));
					}
					
					List<Combatant> targets = activeLevel.targetSettings.GetPossibleTargets(owner, 
						ORK.Game.Combatants.Get(owner, true, Range.Battle, 
							Consider.No, Consider.Ignore, owner.InBattle ? Consider.Yes : Consider.Ignore), 
						ORK.Game.Combatants.Get(owner, true, Range.Battle, 
							Consider.Yes, Consider.Ignore, owner.InBattle ? Consider.Yes : Consider.Ignore));
					
					int selection = -1;
					if(this.ability.SingleTarget())
					{
						for(int i=0; i<targets.Count; i++)
						{
							List<Combatant> tmp = new List<Combatant>();
							tmp.Add(targets[i]);
							list.Add(new TargetBMItem(
								owner.BattleMenu.GetCombatantChoice(targets[i]), 
								this.ability, tmp));
							
							if(selection < 0 && activeLevel.targetSettings.useAutoTarget && 
								activeLevel.targetSettings.autoTarget.Check(targets[i]))
							{
								selection = i;
							}
						}
					}
					else if(this.ability.GroupTarget())
					{
						list.Add(new TargetBMItem(
							ORK.BattleTexts.GetAllCombatantsContent(
								activeLevel.targetSettings.targetType, 
								owner.BattleMenu.Settings.contentLayout), 
							this.ability, targets));
					}
					
					if(owner.BattleMenu.Settings.addBack && 
						!owner.BattleMenu.Settings.backFirst && 
						ORK.BattleSettings.useTargetMenu)
					{
						list.Add(new BackBMItem(owner.BattleMenu.Settings.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton)));
					}
					
					owner.BattleMenu.Show(list, selection < 0 ? 0 : selection, BattleMenuMode.Target);
				}
			}
		}
		
		public override bool ChangeUseLevel(int change, Combatant owner)
		{
			if(this.ability.ChangeUseLevel(change, ORK.GameControls.loopAbilityLevels))
			{
				if(owner.BattleMenu != null)
				{
					if(owner.BattleMenu.Box != null)
					{
						owner.BattleMenu.Box.Audio.PlayAbilityLevel();
					}
					this.content = owner.BattleMenu.Settings.contentLayout.GetChoiceContent(this.ability, owner);
				}
				return true;
			}
			return false;
		}
	}
}
