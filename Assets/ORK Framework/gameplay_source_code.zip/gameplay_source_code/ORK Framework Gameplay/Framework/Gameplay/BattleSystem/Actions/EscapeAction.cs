
using System.Collections.Generic;

namespace ORKFramework
{
	public class EscapeAction : BaseAction
	{
		public EscapeAction(Combatant user)
		{
			this.user = user;
			this.target = new List<Combatant>();
			this.target.Add(user);
			
			if(ORK.BattleSystem.activeTime.escapeEndTurn)
			{
				this.timeUse = ORK.BattleSystem.activeTime.actionBorder;
			}
			else
			{
				this.timeUse = ORK.BattleSystem.activeTime.escapeTimebarUse;
			}
		}
		
		public override bool IsType(ActionType t)
		{
			return ActionType.Escape.Equals(t);
		}
		
		
		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null && !this.user.Dead && 
				!this.user.Status.BlockEscape;
		}
		
		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.escapeInfo.Show(this.user, "");
			}
			
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleEscape)
				{
					this.user.Setting.consoleEscape.Print(this.user, this.target, null);
				}
				else
				{
					ORK.ConsoleSettings.actionEscape.Print(this.user, this.target, null);
				}
			}
			
			this.user.GetEscapeEvent(ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			if(ORK.BattleSettings.camera.blockEventCams)
			{
				if(ts.Count == 1 && ts[0] != null && ts[0].GameObject != null)
				{
					ORK.BattleSettings.camera.SetLatestDamage(ts[0].GameObject.transform);
				}
				else if(ts.Count > 1)
				{
					ORK.BattleSettings.camera.SetLatestDamage(ORK.Battle.GetGroupCenter(ts).transform);
				}
			}
			
			if(this.user != null && !this.user.Dead && 
				ts.Count > 0 && ts[0] != null && 
				!this.user.Status.BlockEscape)
			{
				if(ORK.GameSettings.CheckRandom(this.user.GetEscapeChance()))
				{
					user.Escape();
				}
				this.userConsumeDone = true;
			}
		}

		protected override void ActionEndSetup()
		{
			this.user.LastAbilityID = -1;
		}
	}
}
