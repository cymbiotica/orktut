
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework
{
	public class TargetBMItem : BMItem
	{
		private List<Combatant> targets;
		
		private IShortcut shortcut;
		
		public TargetBMItem(ChoiceContent content, IShortcut shortcut, List<Combatant> targets)
		{
			this.content = content;
			this.shortcut = shortcut;
			this.targets = targets;
		}
		
		public override void CreateDrag(Combatant owner)
		{
			// portrait
			if(this.content.portrait == null && this.targets != null && 
				owner.BattleMenu.Settings.showTargetPortraits)
			{
				for(int i=0; i<this.targets.Count; i++)
				{
					if(this.targets[i] != null)
					{
						this.content.portrait = this.targets[i].GetPortrait(
							owner.BattleMenu.Settings.targetPortraitTypeID);
						if(this.content.portrait != null)
						{
							return;
						}
					}
				}
			}
		}
		
		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			this.content.Active = false;
			
			if(this.shortcut is AbilityShortcut && 
				this.shortcut.CanUse(owner, !AbilityActionType.CounterAttack.Equals(((AbilityShortcut)this.shortcut).Type)))
			{
				for(int i=0; i<this.targets.Count; i++)
				{
					if(((AbilityShortcut)this.shortcut).InRange(owner, this.targets[i]) && 
						((AbilityShortcut)this.shortcut).CanTarget(owner, this.targets[i]))
					{
						this.content.Active = true;
						break;
					}
				}
			}
			else if(this.shortcut is ItemShortcut && 
				this.shortcut.CanUse(owner, true) && 
				owner.Inventory.HasItem(this.shortcut.ID, 1))
			{
				for(int i=0; i<this.targets.Count; i++)
				{
					if(((ItemShortcut)this.shortcut).Setting.InRange(owner, this.targets[i]) && 
						((ItemShortcut)this.shortcut).CanTarget(owner, this.targets[i]))
					{
						this.content.Active = true;
						break;
					}
				}
			}
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			BaseAction action = null;
			if(this.shortcut is AbilityShortcut)
			{
				action = new AbilityAction(owner, this.shortcut as AbilityShortcut);
			}
			else if(this.shortcut is ItemShortcut)
			{
				action = new ItemAction(owner, this.shortcut as ItemShortcut);
			}
			action.SetTargets(this.targets);
			owner.BattleMenu.AddAction(action);
		}
		
		public override void Blink(bool doBlink)
		{
			bool cam = false;
			for(int i=0; i<this.targets.Count; i++)
			{
				TargetHelper.Blink(this.targets[i], doBlink);
				if(doBlink && !cam && ORK.BattleSettings.camera.blockEventCams && 
					this.targets[i] != null && this.targets[i].GameObject != null)
				{
					ORK.BattleSettings.camera.SetSelection(this.targets[i].GameObject.transform);
					cam = true;
				}
			}
		}
		
		public override bool Contains(Combatant combatant)
		{
			return this.targets.Contains(combatant);
		}
		
		public override bool ContainsAny(List<Combatant> list)
		{
			if(list != null)
			{
				for(int i=0; i<list.Count; i++)
				{
					if(this.targets.Contains(list[i]))
					{
						return true;
					}
				}
			}
			return false;
		}
	}
}
