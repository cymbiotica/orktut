
namespace ORKFramework
{
	public class GroupAdvantage : BaseData
	{
		// turn based
		[ORKEditorHelp("First Move", "The group will have the first move in a set number of turns at battle start.\n" +
			"This setting is used in 'Turn Based' type battles.", "")]
		public bool firstMove = false;
		
		[ORKEditorHelp("Turns", "The number of turns the group will have the first move.\n" +
			"This setting is used in 'Turn Based' type battles.", "")]
		[ORKEditorLayout("firstMove", true, endCheckGroup=true)]
		[ORKEditorLimit(0, false)]
		public int firstMoveRounds = 1;
		
		// active time
		[ORKEditorHelp("Set Timebar", "The timebar values of this group will be set at battle start.\n" +
			"This setting is used in 'Active Time' type battles.", "")]
		[ORKEditorInfo(separator=true)]
		public bool setTimebar = false;
		
		[ORKEditorHelp("Timebar", "The start value of the group member's timebars.\n" +
			"This setting is used in 'Active Time' type battles.", "")]
		[ORKEditorLayout("setTimebar", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float timebar = 0;
		
		// phase
		[ORKEditorHelp("First Phase", "The group will have the first phase in a set number of turns at battle start.\n" +
			"This setting is used in 'Phase' type battles.", "")]
		[ORKEditorInfo(separator=true)]
		public bool firstPhase = false;
		
		[ORKEditorHelp("Turns", "The number of turns the group will have the first move.\n" +
			"This setting is used in 'Phase' type battles.", "")]
		[ORKEditorLayout("firstPhase", true, endCheckGroup=true)]
		[ORKEditorLimit(0, false)]
		public int firstPhaseRounds = 1;
		
		
		// status
		[ORKEditorInfo(separator=true, labelText="Status Value Changes")]
		[ORKEditorArray(true, "Add Status Change", "Adds a status value change to the list.", "", 
			"Remove", "Removes this status value change.", "")]
		public StatusValueSetter[] status = new StatusValueSetter[0];
		
		// effect
		[ORKEditorInfo(separator=true, labelText="Status Effect Changes")]
		[ORKEditorArray(true, "Add Status Effect", "Add a status effect cast to the list.", "", 
			"Remove", "Remove this status effect cast from the list.", "")]
		public StatusEffectCast[] effect = new StatusEffectCast[0];
		
		public GroupAdvantage()
		{
			
		}
		
		
		/*
		============================================================================
		Advantage functions
		============================================================================
		*/
		public void Apply(Combatant c)
		{
			if(ORK.Battle.IsActiveTime())
			{
				c.TimeBar = this.timebar;
				if(c.TimeBar > ORK.BattleSystem.activeTime.maxTimebar)
				{
					c.TimeBar = ORK.BattleSystem.activeTime.maxTimebar;
				}
			}
			
			if(this.status.Length > 0)
			{
				for(int i=0; i<this.status.Length; i++)
				{
					this.status[i].Change(c);
				}
				c.MarkStatusBoundsCheck();
			}
			
			for(int i=0; i<this.effect.Length; i++)
			{
				this.effect[i].ChangeEffect(c, c);
			}
		}
	}
}
