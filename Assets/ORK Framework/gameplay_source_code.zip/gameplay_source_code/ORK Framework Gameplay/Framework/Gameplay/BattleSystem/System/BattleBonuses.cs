
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleBonuses : BaseData
	{
		// start bonus
		[ORKEditorInfo("Bonus Settings", "'Consumable' type status values can be changed every turn or " +
			"at start and end of the battle.\n" +
			"Additionally dead combatants can be revived at the end of the battle.", "", 
			labelText="Start Battle Bonus")]
		[ORKEditorArray(false, "Add Start Bonus", "Adds a start bonus to the list.\n" +
			"A start bonus is added at the start of a battle.", "", 
			"Remove", "Removes this start bonus.", "", isMove=true, isCopy=true, 
			removeType=ORKDataType.StatusValue, removeCheckField="statusID", 
			foldout=true, foldoutText=new string[] {"Start Bonus", 
				"This bonus will be added at the start of a battle.", ""})]
		public StatusValueSetter[] startSetter = new StatusValueSetter[0];
		
		
		// turn bonus
		[ORKEditorInfo(separator=true, labelText="Turn Bonuses")]
		[ORKEditorArray(false, "Add Turn Bonus", "Adds a turn bonus to the list.\n" +
			"A turn bonus is added whenever a combatant starts a new turn (i.e. selects a battle action).", "", 
			"Remove", "Removes this turn bonus.", "", isMove=true, isCopy=true, 
			removeType=ORKDataType.StatusValue, removeCheckField="statusID", 
			foldout=true, foldoutText=new string[] {"Turn Bonus", 
				"This bonus will be added when a combatant starts a new turn.", ""})]
		public StatusValueSetter[] turnSetter = new StatusValueSetter[0];
		
		
		// end bonus
		[ORKEditorInfo(separator=true, labelText="End Battle Bonus")]
		[ORKEditorArray(false, "Add End Bonus", "Adds an end bonus to the list.\n" +
			"An end bonus is added at the end of a battle.", "", 
			"Remove", "Removes this end bonus.", "", isMove=true, isCopy=true, 
			removeType=ORKDataType.StatusValue, removeCheckField="statusID", 
			foldout=true, foldoutText=new string[] {"End Bonus", 
				"This bonus will be added at the end of a battle.", ""})]
		public StatusValueSetter[] endSetter = new StatusValueSetter[0];
		
		
		// revive after battle
		[ORKEditorHelp("Revive After Battle", "Dead members of the player group will be revived after battle.", "")]
		[ORKEditorInfo(separator=true, labelText="Revive After Battle")]
		public bool reviveAfterBattle = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Revive Bonus", "Adds a revive bonus to the list.\n" +
			"A revive bonus is added whenever a combatant is revived after battle.", "", 
			"Remove", "Removes this revive bonus.", "", isMove=true, isCopy=true, 
			removeType=ORKDataType.StatusValue, removeCheckField="statusID", 
			foldout=true, foldoutText=new string[] {"Revive Bonus", 
				"This bonus will be added when a combatant is revived after the battle.", ""})]
		[ORKEditorLayout("reviveAfterBattle", true, endCheckGroup=true)]
		public StatusValueSetter[] reviveSetter = new StatusValueSetter[0];
		
		public BattleBonuses()
		{
			
		}
		
		
		/*
		============================================================================
		Status bonus functions
		============================================================================
		*/
		private void AddBonus(Combatant c, ref StatusValueSetter[] bonus)
		{
			if(!c.Dead && bonus.Length > 0)
			{
				for(int i=0; i<bonus.Length; i++)
				{
					bonus[i].Change(c);
				}
				c.MarkStatusBoundsCheck();
			}
		}
		
		public void StartBonus(Combatant c)
		{
			this.AddBonus(c, ref this.startSetter);
		}
		
		public void TurnBonus(Combatant c)
		{
			this.AddBonus(c, ref this.turnSetter);
		}
		
		public void EndBonus(Combatant c)
		{
			this.AddBonus(c, ref this.endSetter);
		}
		
		public void ReviveBonus(Combatant c)
		{
			if(this.reviveAfterBattle && c.Dead)
			{
				c.Dead = false;
				this.AddBonus(c, ref this.reviveSetter);
			}
		}
	}
}
