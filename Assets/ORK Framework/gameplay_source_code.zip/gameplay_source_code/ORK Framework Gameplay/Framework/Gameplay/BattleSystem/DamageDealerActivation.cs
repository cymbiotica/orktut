
using UnityEngine;
using ORKFramework.Events;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DamageDealerActivation : BaseData
	{
		// audio settings
		[ORKEditorHelp("Add Audio", "An audio clip is played on the game object hit by the damage dealer (when doing damage).", "")]
		[ORKEditorInfo(labelText="Audio Settings")]
		public bool addAudio = false;
		
		[ORKEditorHelp("Use Sound Type", "The user or target combatant's defined sound of a selected sound type will be used.", "")]
		[ORKEditorLayout("addAudio", true)]
		public bool useSoundType = false;
		
		[ORKEditorHelp("Sound Type", "Select the sound type that will be played.", "")]
		[ORKEditorInfo(ORKDataType.SoundType)]
		[ORKEditorLayout("useSoundType", true)]
		public int soundTypeID = 0;
		
		[ORKEditorHelp("Use Target", "Use the target combatant's audio clip.\n" +
			"If disabled, the user combatant's audio clip is used.", "")]
		public bool targetSound = false;
		
		[ORKEditorHelp("Audio Clip", "Select the audio clip that will be played.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, setDefault=true, defaultValue=null)]
		public AudioClip audioClip;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public PlayAudioSettings audio;
		
		
		// prefab settings
		[ORKEditorHelp("Add Prefab", "A prefab is spawned on the position it hit an object when doing damage.\n" +
			"This prefab can't be used by the battle event.", "")]
		[ORKEditorInfo(separator=true, labelText="Prefab Settings")]
		public bool addPrefab = false;
		
		[ORKEditorHelp("Prefab", "Select the prefab that will be used.", "")]
		[ORKEditorLayout("addPrefab", true, setDefault=true, defaultValue=null)]
		public GameObject prefab;
		
		[ORKEditorHelp("Stop Particles", "Particles emitting from the prefab will stop emitting.", "")]
		public bool stopParticles = false;
		
		[ORKEditorHelp("Stop After (s)", "The time in seconds before emitting particles will stop.", "")]
		[ORKEditorLayout("stopParticles", true, endCheckGroup=true)]
		public float stopAfter = 1;
		
		[ORKEditorHelp("Destroy After (s)", "The spawned prefab will be destroyed after the set amout of time in seconds.\n" +
			"Set to 0 if you don't want to destroy it after time.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float after = 0;
		
		
		// battle animation
		[ORKEditorHelp("Animate", "The damage dealer will perform a series of battle events when hitting a damage zone.\n" +
			"You need to add a calculation step to one of the battle events to calculate the outcome of the action.\n" +
			"If disabled, the damage dealer wont use additional animation and automatically calculate the outcome once.", "")]
		[ORKEditorInfo(separator=true, labelText="Animation Settings")]
		public bool animate = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Animation", "Adds a battle event to the damage dealer.\n" +
			"All battle events (passing the chance check) will be performed one by one.", "", 
			"Remove", "Removes this battle event from the list.", "", isCopy=true, isMove=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {"Battle Event", 
				"Define the battle event, chance and battle systems the event will be performed in.", ""})]
		[ORKEditorLayout("animate", true, endCheckGroup=true)]
		public BattleAnimation[] animation = new BattleAnimation[] {new BattleAnimation()};
		
		public DamageDealerActivation()
		{
			
		}
		
		public void Add(DamageDealer damage, Combatant user)
		{
			this.AddAudio(damage, user);
			this.AddPrefab(damage);
		}
		
		public void AddAudio(DamageDealer damage, Combatant user)
		{
			if(this.addAudio)
			{
				if(this.useSoundType)
				{
					if(this.targetSound)
					{
						damage.SetAudioType(this.soundTypeID, this.audio);
					}
					else
					{
						damage.SetAudioClip(user.Animations.GetAudioClip(this.soundTypeID), this.audio);
					}
				}
				else
				{
					damage.SetAudioClip(this.audioClip, this.audio);
				}
			}
		}
		
		public void AddPrefab(DamageDealer damage)
		{
			if(this.addPrefab)
			{
				damage.SetPrefab(this.prefab, this.after, this.stopParticles ? this.stopAfter : -1);
			}
		}
		
		
		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public void GetAnimations(ref List<BattleEvent> list, Combatant user)
		{
			if(this.animate)
			{
				for(int i=0; i<this.animation.Length; i++)
				{
					this.animation[i].GetEvent(ref list, user);
				}
			}
		}
	}
}
