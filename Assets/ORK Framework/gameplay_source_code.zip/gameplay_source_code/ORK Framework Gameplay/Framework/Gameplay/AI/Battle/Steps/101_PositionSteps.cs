
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Check Distance", "The distance between user and target is checked with a defined value.\n" +
		"If the check is true, 'Success' will be executed next, else 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position Steps", "Check Steps")]
	public class CheckDistanceStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;
		
		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TargetType targetType = TargetType.Ally;
		
		
		// distance
		[ORKEditorHelp("Ignore Y Distance", "Height differences to the targets are ignored when calculating the distance.", "")]
		[ORKEditorInfo(separator=true, labelText="Distance")]
		public bool ignY = false;
		
		[ORKEditorHelp("Ignore Radius", "The box radius settings of the combatants will be ignored when calculating the distance.", "")]
		public bool ignComRad = false;
		
		
		// check
		[ORKEditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defind values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		
		// check value
		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public AIFloat value = new AIFloat();
		
		// check value 2
		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public AIFloat value2 = new AIFloat();
		
		public CheckDistanceStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear.Equals(this.foundType))
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check.Equals(this.foundType))
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, user, tmp, foundTargets);
			}
			
			// check all possible targets
			this.Check(ref any, user, this.GetTargetList(this.targetType, user, allies, enemies), foundTargets);
			
			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}
		
		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(ValueHelper.CheckVariableValue(user.DistanceTo(list[i], this.ignY, this.ignComRad), 
						this.value.GetValue(user, list[i]), 
						this.value2 != null ? this.value2.GetValue(user, list[i]) : 0, 
						this.check))
					{
						any = true;
						if(!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString() + " " + this.value.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Check Angle", "The angle between user and target is checked with a defined value.\n" +
		"If the check is true, 'Success' will be executed next, else 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position Steps", "Check Steps")]
	public class CheckAngleStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;
		
		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TargetType targetType = TargetType.Ally;
		
		
		// angle
		[ORKEditorHelp("Use Direction", "The angle between the forward directions of user and target will be calculated.\n" +
			"E.g. the result will be 0 if both are looking into the same direction, -180/180 if they look into opposite directions.\n" +
			"If disabled, the angle between the positions will be calculated.\n" +
			"E.g. the result will be 0 if the user looks directly at the target, -180/180 if he looks away from the target.", "")]
		[ORKEditorInfo(separator=true, labelText="Angle")]
		public bool direction = false;
		
		[ORKEditorHelp("From Target", "The angle is calculated from target to user.\n" +
			"If disabled, the angle is calculated from user to target.", "")]
		[ORKEditorLayout("direction", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool fromTarget = false;
		
		
		// check
		[ORKEditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defind values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		
		// check value
		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public AIFloat value = new AIFloat();
		
		// check value 2
		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public AIFloat value2 = new AIFloat();
		
		public CheckAngleStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear.Equals(this.foundType))
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check.Equals(this.foundType))
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, user, tmp, foundTargets);
			}
			
			// check all possible targets
			this.Check(ref any, user, this.GetTargetList(this.targetType, user, allies, enemies), foundTargets);
			
			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}
		
		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			if(user.GameObject != null)
			{
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null && list[i].GameObject != null)
					{
						float tmpVal = 0;
						if(this.direction)
						{
							tmpVal = VectorHelper.HorizontalDirectionAngle(user.GameObject.transform, list[i].GameObject.transform);
						}
						else if(this.fromTarget)
						{
							tmpVal = VectorHelper.HorizontalAngle(list[i].GameObject.transform, user.GameObject.transform);
						}
						else
						{
							tmpVal = VectorHelper.HorizontalAngle(user.GameObject.transform, list[i].GameObject.transform);
						}
						
						if(ValueHelper.CheckVariableValue(tmpVal, 
							this.value.GetValue(user, list[i]), 
							this.value2 != null ? this.value2.GetValue(user, list[i]) : 0, 
							this.check))
						{
							any = true;
							if(!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check + " " + this.value.GetInfoText() + 
				(this.direction ? " Direction" : "") + (this.fromTarget ? " from Target" : "");
		}
	}
	
	[ORKEditorHelp("Check Orientation", "Checks the orientation from user to target (e.g. if the target is in front of the user).\n" +
		"If the check is true, 'Success' will be executed next, else 'Failed'\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position Steps", "Check Steps")]
	public class CheckOrientationStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;
		
		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TargetType targetType = TargetType.Ally;
		
		
		// orientation
		[ORKEditorHelp("Orientation", "Select the orientation that'll be checked for:\n" +
			"- None: The orientation is ignored.\n" +
			"- Front: The target has to be in front of the user.\n" +
			"- Back: The target has to be in the back of the user.\n" +
			"- Left: The target has to be left of the user.\n" +
			"- Right: The target has to be right of the user.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true, labelText="Orientation")]
		public Orientation orientation = Orientation.Front;
		
		[ORKEditorHelp("From Target", "The orientation is checked from target to user.\n" +
			"If disabled, the orientation is checked from user to target.", "")]
		public bool fromTarget = false;
		
		public CheckOrientationStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear.Equals(this.foundType))
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check.Equals(this.foundType))
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, user, tmp, foundTargets);
			}
			
			// check all possible targets
			this.Check(ref any, user, this.GetTargetList(this.targetType, user, allies, enemies), foundTargets);
			
			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}
		
		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					Orientation check = Orientation.None;
					if(user.GameObject != null && list[i].GameObject != null)
					{
						if(this.fromTarget)
						{
							check = VectorHelper.GetOrientation(list[i].GameObject.transform, user.GameObject.transform);
						}
						else
						{
							check = VectorHelper.GetOrientation(user.GameObject.transform, list[i].GameObject.transform);
						}
					}
					if(Orientation.None.Equals(this.orientation) || this.orientation.Equals(check))
					{
						any = true;
						if(!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.orientation + (this.fromTarget ? ", from Target" : "");
		}
	}
}
