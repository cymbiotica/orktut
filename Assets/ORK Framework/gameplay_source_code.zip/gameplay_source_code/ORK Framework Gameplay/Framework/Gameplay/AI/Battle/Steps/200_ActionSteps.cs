
using ORKFramework;
using ORKFramework.AI;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Attack", "Performs the combatant's base attack or counter attack.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action Steps")]
	public class AttackStep : BaseAIStep
	{
		[ORKEditorHelp("Use Counter", "The combatant's counter attack is used.\n" +
			"If disabled, the combatant's base attack is used.", "")]
		public bool useCounter = false;
		
		
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[ORKEditorInfo(separator=true)]
		public bool endPhase = false;
		
		[ORKEditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;
		
		public AttackStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			AbilityAction action = null;
			AbilityShortcut ability = this.useCounter ? 
				user.GetCounterAttack() : 
				user.GetCurrentBaseAttack();
			
			// get action
			if(!user.Status.BlockAttack)
			{
				action = BaseAction.CreateAbility(user, ability, -2);
			}
			
			// check active time
			if(action != null)
			{
				if((!user.Setting.attackGroupTarget || !action.SetGroupTarget()) && 
					(!user.Setting.attackIndividualTarget || !action.SetIndividualTarget()))
				{
					List<Combatant> preferredTargets = this.GetPreferredTargets(user, foundTargets);
					if(this.forceFoundTargets)
					{
						action.forceFoundTargets = true;
						
						if(ability.TargetSelf())
						{
							action.AutoTarget(preferredTargets, allies, enemies);
						}
						else if(ability.TargetEnemy())
						{
							action.AutoTarget(preferredTargets, allies, preferredTargets);
						}
						else if(ability.TargetAlly())
						{
							action.AutoTarget(preferredTargets, preferredTargets, enemies);
						}
						else if(ability.TargetAll())
						{
							action.AutoTarget(preferredTargets, preferredTargets, preferredTargets);
						}
					}
					else
					{
						action.AutoTarget(preferredTargets, allies, enemies);
					}
				}
				if((ORK.Battle.IsActiveTime() && 
					(user.UsedTimeBar + action.TimeUse) > ORK.BattleSystem.activeTime.maxTimebar))
				{
					action = null;
				}
			}
			
			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
			}
			
			currentStep = this.next;
			return action;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useCounter ? "Counter Attack" : "Base Attack") + 
				(this.endPhase ? ", Ends Phase" : "");
		}
	}
	
	[ORKEditorHelp("Ability", "Performs an ability of the combatant.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action Steps")]
	public class AbilityStep : BaseAIStep
	{
		[ORKEditorHelp("Ability", "Select the ability that will be performed.\n" +
			"The combatant must know the ability (e.g. learned the ability, equipment ability), or the action can't be performed.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		public int id = 0;
		
		[ORKEditorHelp("Use Highest Level", "The highest available ability level will be used " +
			"(i.e. the highest level that can be used, e.g. due to use costs).\n" +
			"If disabled, a defined ability level will be used - " +
			 "if the defined level can't be used (e.g. due to use costs), the action can't be performed.", "")]
		public bool useHighest = false;
		
		[ORKEditorHelp("Level", "Set the level of the ability that will be used.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("useHighest", false, endCheckGroup=true)]
		public int level = 1;
		
		
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[ORKEditorInfo(separator=true)]
		public bool endPhase = false;
		
		[ORKEditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;
		
		public AbilityStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			AbilityAction action = null;
			
			// get action
			AbilityShortcut ability = user.Abilities.Get(this.id);
			if(ability != null)
			{
				action = BaseAction.CreateAbility(user, ability, this.useHighest ? -1 : this.level);
			}
			
			// check active time
			if(action != null)
			{
				if((!user.Setting.attackGroupTarget || !action.SetGroupTarget()) && 
					(!user.Setting.attackIndividualTarget || !action.SetIndividualTarget()))
				{
					List<Combatant> preferredTargets = this.GetPreferredTargets(user, foundTargets);
					if(this.forceFoundTargets)
					{
						action.forceFoundTargets = true;
						
						if(ability.TargetSelf())
						{
							action.AutoTarget(preferredTargets, allies, enemies);
						}
						else if(ability.TargetEnemy())
						{
							action.AutoTarget(preferredTargets, allies, preferredTargets);
						}
						else if(ability.TargetAlly())
						{
							action.AutoTarget(preferredTargets, preferredTargets, enemies);
						}
						else if(ability.TargetAll())
						{
							action.AutoTarget(preferredTargets, preferredTargets, preferredTargets);
						}
					}
					else
					{
						action.AutoTarget(preferredTargets, allies, enemies);
					}
				}
				if((ORK.Battle.IsActiveTime() && 
					(user.UsedTimeBar + action.TimeUse) > ORK.BattleSystem.activeTime.maxTimebar))
				{
					action = null;
				}
			}
			
			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
			}
			
			currentStep = this.next;
			return action;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Abilities.GetName(this.id) + 
				(this.useHighest ? ", Highest Level" : ", Level " + this.level) + 
				(this.endPhase ? ", Ends Phase" : "");
		}
	}
	
	[ORKEditorHelp("Class Ability", "Performs the combatant's class ability.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action Steps")]
	public class ClassAbilityStep : BaseAIStep
	{
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;
		
		[ORKEditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;
		
		public ClassAbilityStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			AbilityAction action = null;
			AbilityShortcut ability = null;
			
			// get action
			if(user.Abilities.HasClassAbility())
			{
				ability = user.Abilities.GetClassAbility();
				if(ability != null)
				{
					action = BaseAction.CreateAbility(user, ability, -1);
				}
			}
			
			// check active time
			if(action != null)
			{
				if((!user.Setting.attackGroupTarget || !action.SetGroupTarget()) && 
					(!user.Setting.attackIndividualTarget || !action.SetIndividualTarget()))
				{
					List<Combatant> preferredTargets = this.GetPreferredTargets(user, foundTargets);
					if(this.forceFoundTargets)
					{
						action.forceFoundTargets = true;
						
						if(ability.TargetSelf())
						{
							action.AutoTarget(preferredTargets, allies, enemies);
						}
						else if(ability.TargetEnemy())
						{
							action.AutoTarget(preferredTargets, allies, preferredTargets);
						}
						else if(ability.TargetAlly())
						{
							action.AutoTarget(preferredTargets, preferredTargets, enemies);
						}
						else if(ability.TargetAll())
						{
							action.AutoTarget(preferredTargets, preferredTargets, preferredTargets);
						}
					}
					else
					{
						action.AutoTarget(preferredTargets, allies, enemies);
					}
				}
				if((ORK.Battle.IsActiveTime() && 
					(user.UsedTimeBar + action.TimeUse) > ORK.BattleSystem.activeTime.maxTimebar))
				{
					action = null;
				}
			}
			
			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
			}
			
			currentStep = this.next;
			return action;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.endPhase ? "Ends Phase" : "";
		}
	}
	
	[ORKEditorHelp("Item", "The combatant uses an item.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action Steps")]
	public class ItemStep : BaseAIStep
	{
		[ORKEditorHelp("Item", "Select the item that will be used.\n" +
			"The item must be useable in battle, or the action can't be performed.", "")]
		[ORKEditorInfo(ORKDataType.Item)]
		public int id = 0;
		
		[ORKEditorHelp("In Inventory", "The item must be in the combatant's inventory, or the action can't be performed.\n" +
			"If disabled, the combatant doesn't need to have the item in the inventory, but it will be consumed if it's in the inventory.", "")]
		public bool inInventory = false;
		
		
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[ORKEditorInfo(separator=true)]
		public bool endPhase = false;
		
		[ORKEditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;
		
		public ItemStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			ItemAction action = null;
			
			// get action
			ItemShortcut item = this.inInventory ? user.Inventory.GetItem(this.id) : new ItemShortcut(this.id, 1);
			if(item != null && item.CanUse(user, true))
			{
				action = new ItemAction(user, item);
			}
			
			// check active time
			if(action != null)
			{
				if((!user.Setting.attackGroupTarget || !action.SetGroupTarget()) && 
					(!user.Setting.attackIndividualTarget || !action.SetIndividualTarget()))
				{
					List<Combatant> preferredTargets = this.GetPreferredTargets(user, foundTargets);
					if(this.forceFoundTargets)
					{
						action.forceFoundTargets = true;
						
						if(item.Setting.targetSettings.TargetSelf())
						{
							action.AutoTarget(preferredTargets, allies, enemies);
						}
						else if(item.Setting.targetSettings.TargetEnemy())
						{
							action.AutoTarget(preferredTargets, allies, preferredTargets);
						}
						else if(item.Setting.targetSettings.TargetAlly())
						{
							action.AutoTarget(preferredTargets, preferredTargets, enemies);
						}
						else if(item.Setting.targetSettings.TargetAll())
						{
							action.AutoTarget(preferredTargets, preferredTargets, preferredTargets);
						}
					}
					else
					{
						action.AutoTarget(preferredTargets, allies, enemies);
					}
				}
				if((ORK.Battle.IsActiveTime() && 
					(user.UsedTimeBar + action.TimeUse) > ORK.BattleSystem.activeTime.maxTimebar))
				{
					action = null;
				}
			}
			
			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
			}
			
			currentStep = this.next;
			return action;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Items.GetName(this.id) + 
				(this.inInventory ? ", Inventory" : "") + 
				(this.endPhase ? ", Ends Phase" : "");
		}
	}
	
	[ORKEditorHelp("Defend", "The combatant uses the defend command.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action Steps")]
	public class DefendStep : BaseAIStep
	{
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;
		
		public DefendStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			BaseAction action = null;
			
			// get action
			if(!user.Status.BlockDefend)
			{
				action = new DefendAction(user);
			}
			
			// check active time
			if(action != null && (ORK.Battle.IsActiveTime() && 
				(user.UsedTimeBar + action.TimeUse) > ORK.BattleSystem.activeTime.maxTimebar))
			{
				action = null;
			}
			
			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
			}
			
			currentStep = this.next;
			return action;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.endPhase ? "Ends Phase" : "";
		}
	}
	
	[ORKEditorHelp("Escape", "The combatant uses the escape command.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action Steps")]
	public class EscapeStep : BaseAIStep
	{
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;
		
		public EscapeStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			BaseAction action = null;
			
			// get action
			if(!user.Status.BlockEscape)
			{
				action = new EscapeAction(user);
			}
			
			// check active time
			if(action != null && (ORK.Battle.IsActiveTime() && 
				(user.UsedTimeBar + action.TimeUse) > ORK.BattleSystem.activeTime.maxTimebar))
			{
				action = null;
			}
			
			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
			}
			
			currentStep = this.next;
			return action;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.endPhase ? "Ends Phase" : "";
		}
	}
	
	[ORKEditorHelp("Death", "The combatant dies.", "")]
	[ORKNodeInfo("Action Steps")]
	public class DeathStep : BaseAIStep
	{
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;
		
		public DeathStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			currentStep = -1;
			BaseAction action = new DeathAction(user, false);
			action.endPhaseFlag = this.endPhase;
			return action;
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 0;
		}
		
		public override int GetNext(int index)
		{
			return -1;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Ends the AI" + (this.endPhase ? ", Ends Phase" : "");
		}
	}
	
	[ORKEditorHelp("None", "The combatant does nothing.", "")]
	[ORKNodeInfo("Action Steps")]
	public class NoneStep : BaseAIStep
	{
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;
		
		public NoneStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			currentStep = -1;
			BaseAction action = new NoneAction(user);
			action.endPhaseFlag = this.endPhase;
			return action;
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 0;
		}
		
		public override int GetNext(int index)
		{
			return -1;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Ends the AI" + (this.endPhase ? ", Ends Phase" : "");
		}
	}
	
	[ORKEditorHelp("Change Member", "The combatant is exchanged with a member of the combatant's non-battle group.", "")]
	[ORKNodeInfo("Action Steps")]
	public class ChangeMemberStep : BaseAIStep
	{
		[ORKEditorHelp("Member Index", "The index of the non-battle member that will be used.", "")]
		[ORKEditorLimit(0, false)]
		public int memberIndex = 0;
		
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;
		
		public ChangeMemberStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			currentStep = -1;
			BaseAction action = null;
			
			Combatant target = user.Group.NonBattleMemberAt(this.memberIndex);
			if(target != null)
			{
				action = new ChangeMemberAction(user, target);
				action.endPhaseFlag = this.endPhase;
			}
			
			return action;
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 0;
		}
		
		public override int GetNext(int index)
		{
			return -1;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Ends the AI" + (this.endPhase ? ", Ends Phase" : "");
		}
	}
}
