
using UnityEngine;
using ORKFramework;
using ORKFramework.AI.Steps;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class BattleAI : BaseNode
	{
		[ORKEditorHelp("Name", "The name of the battle AI.", "")]
		[ORKEditorInfo("AI Settings", "Set the name and base settings of the battle AI.", "", 
			expandWidth=true, endFoldout=true)]
		public string name = "";
		
		
		// AI steps
		[ORKEditorInfo(hide=true)]
		public int startIndex = -1;
		
		[ORKEditorInfo(hide=true)]
		public BaseAIStep[] step = new BaseAIStep[0];
		
		public BattleAI()
		{
			
		}
		
		public BattleAI(string name)
		{
			this.name = name;
		}
		
		public BaseAction GetAction(Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			BaseAction action = null;
			List<Combatant> foundTargets = new List<Combatant>();
			int currentStep = this.startIndex;
			
			while(action == null && currentStep >= 0 && currentStep < this.step.Length)
			{
				action = this.step[currentStep].Execute(ref currentStep, user, allies, enemies, foundTargets);
			}
			
			return action;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "Battle AI Settings";
		}
		
		public override string GetNodeDetails()
		{
			return "";
		}
		
		public override string GetNextName(int index)
		{
			return "Start";
		}
		
		public override bool IsRemovable()
		{
			return false;
		}
		
		
		/*
		============================================================================
		Next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}
		
		public override int GetNext(int index)
		{
			return this.startIndex;
		}
		
		public override void SetNext(int index, int next)
		{
			this.startIndex = next;
		}
	}
}
