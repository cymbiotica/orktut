
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ControlMap : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the control map.", "")]
		[ORKEditorInfo("Control Map Settings", "Define the name, battle system availability, control keys and actions of this control map.", "", 
			expandWidth=true)]
		public string name = "";
		
		
		// system types
		[ORKEditorHelp("Field", "The control map will be available in the field (i.e. outside of battles).", "")]
		[ORKEditorInfo(separator=true, labelText="Useable In")]
		public bool field = false;
		
		[ORKEditorHelp("Turn Based", "The control map will be available in 'Turn Based' battles.", "")]
		public bool turnBased = false;
		
		[ORKEditorHelp("Active Time", "The control map will be available in 'Active Time' battles.", "")]
		public bool activeTime = false;
		
		[ORKEditorHelp("Real Time", "The control map will be available in 'Real Time' battles.", "")]
		public bool realTime = false;
		
		[ORKEditorHelp("Phase", "The control map will be available in 'Phase' battles.", "")]
		public bool phase = false;
		
		[ORKEditorHelp("While Choosing", "The control map will be available while the combatant's battle menu is active.\n" +
			"If disabled, the control map will only be available if no battle menu is active.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool whileChoosing = false;
		
		
		// requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions.", "")]
		[ORKEditorInfo("Requirements", "Using this control map can depend on status requirements and " +
			"game variable conditions.\n" +
			"The combatant using the control map is used for status checks and object game variables.", "")]
		public bool useRequirements = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useRequirements", true, endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement requirement;
		
		
		// keys
		[ORKEditorInfo(separator=true)]
		[ORKEditorArray(false, "Add Control Key", "Add a control key to this control map.", "", 
			"Remove", "Remove this control key", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Control Key", "A control key can trigger a battle action.\n" +
			"Define the key and action in this settings.\n" +
			"You can have multiple controls on the same key, the first action that can be performed will be performed.\n" +
			"E.g. have multiple refreshing items on the same key, the first item which is in the inventory will be used.", ""}, 
			typeCheckField="selection", removeCheckField="useID")]
		public ControlMapKey[] controlKey = new ControlMapKey[0];
		
		
		// ingame
		private bool blocked = false;
		
		public ControlMap()
		{
			
		}
		
		public ControlMap(string name)
		{
			this.name = name;
		}
		
		
		/*
		============================================================================
		Control functions
		============================================================================
		*/
		public bool Tick(Combatant combatant)
		{
			if(!this.blocked && this.controlKey.Length > 0 && 
				!combatant.Actions.InAction && 
			// requirements
				(!this.useRequirements || this.requirement.Check(combatant)) && 
			// in field
				((!combatant.InBattle && this.field && !ORK.Control.Blocked) || 
			// in battle
				(combatant.InBattle && ORK.Control.InBattle && ORK.Battle.IsBattleRunning() && 
			// system type
					((this.turnBased && ORK.Battle.IsTurnBased()) || 
					(this.activeTime && ORK.Battle.IsActiveTime()) || 
					(this.realTime && ORK.Battle.IsRealTime()) || 
					(this.phase && ORK.Battle.IsPhase())) && 
			// combatant can perform actions
				!combatant.Actions.AutoAttacking && 
				((this.whileChoosing && combatant.Actions.IsChoosing) || combatant.Actions.CanChoose))))
			{
				for(int i=0; i<this.controlKey.Length; i++)
				{
					if(this.controlKey[i].KeyValid(combatant))
					{
						if(this.controlKey[i].PerformAction(combatant))
						{
							return true;
						}
					}
				}
			}
			return false;
		}
		
		public bool Blocked
		{
			get{ return this.blocked;}
			set{ this.blocked = value;}
		}
	}
}
