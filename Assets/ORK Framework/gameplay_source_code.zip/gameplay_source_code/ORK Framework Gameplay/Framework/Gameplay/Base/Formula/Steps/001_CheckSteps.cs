
using UnityEngine;
using ORKFramework;
using ORKFramework.Formulas;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Check Chance", "Which step will be executed next is decided by chance.\n" +
		"The chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings).\n" +
		"If the random number is less or equal to the defined chance, 'Success' is executed, else 'Failed'.", "")]
	[ORKNodeInfo("Check Steps")]
	public class CheckChanceStep : BaseFormulaCheckStep
	{
		[ORKEditorInfo(labelText="Chance")]
		public FormulaFloat chance = new FormulaFloat();
		
		public CheckChanceStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			if(ORK.GameSettings.CheckRandom(this.chance.GetValue(user, target)))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.chance.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Chance Fork", "Which step will be executed next is decided by chance.\n" +
		"he chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings).\n" +
		"The next step of the first defined value range, that includes the chance, will be executed.\n" +
		"If no range contains the chance, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Check Steps")]
	public class ChanceForkStep : BaseFormulaStep
	{
		[ORKEditorArray(false, "Add Range", "Adds a range for the chance check.", "", 
			"Remove", "Removes this range.", "", isCopy=true, isMove=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {
				"Range", "Define the minimum and maximum value of the range.\n" +
				"If the random chance value is within the range (i.e. minimum <= chance <= maximum), " +
				"this range's next step will be executed.", ""
		})]
		public ChanceFormulaNextNode[] range = new ChanceFormulaNextNode[] {new ChanceFormulaNextNode()};
		
		public ChanceForkStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			int check = this.next;
			
			float chance = ORK.GameSettings.GetRandom();
			
			for(int i=0; i<this.range.Length; i++)
			{
				if(this.range[i].Contains(chance, user, user))
				{
					check = this.range[i].next;
					break;
				}
			}
			
			return check;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1).ToString() + ": " + 
					this.range[index - 1].GetInfoText();
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.range.Length + 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.range[index - 1].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.range[index - 1].next = next;
			}
		}
	}
	
	[ORKEditorHelp("Check Formula Value", "The current value of the formula will be checked with a defined value.\n" +
		"If the check is true, 'Success' will be executed next, else 'Failed'.", "")]
	[ORKNodeInfo("Check Steps")]
	public class CheckFormulaValueStep : BaseFormulaCheckStep
	{
		[ORKEditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defind values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public FormulaFloat value = new FormulaFloat();
		
		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public FloatValue value2;
		
		public CheckFormulaValueStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			if(ValueHelper.CheckVariableValue(result, 
				this.value.GetValue(user, target), 
				this.value2 != null ? this.value2.GetValue(user, target) : 0, 
				this.check))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString() + " " + this.value.GetInfoText();
		}
	}
}
