
using ORKFramework;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	public static class FormulaStepHelper
	{
		public static Dictionary<System.Type, NodeInfo> GetSteps()
		{
			Dictionary<System.Type, NodeInfo> list = new Dictionary<System.Type, NodeInfo>();
			
			System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
			for(int i=0; i<assembly.Length; i++)
			{
				FormulaStepHelper.AddFromAssembly(assembly[i], ref list);
			}
			
			return list;
		}
		
		private static void AddFromAssembly(System.Reflection.Assembly assembly, 
			ref Dictionary<System.Type, NodeInfo> list)
		{
			System.Type[] types = assembly.GetTypes();
			for(int i=0; i<types.Length; i++)
			{
				if(types[i].Namespace == "ORKFramework.Formulas.Steps")
				{
					System.Object[] attr = types[i].GetCustomAttributes(typeof(ORKEditorHelpAttribute), true);
					if(attr.Length > 0)
					{
						string[] help = (attr[0] as ORKEditorHelpAttribute).text;
						
						string[] subMenu = new string[0];
						attr = types[i].GetCustomAttributes(typeof(ORKNodeInfoAttribute), true);
						if(attr.Length > 0)
						{
							subMenu = (attr[0] as ORKNodeInfoAttribute).subMenu;
						}
						list.Add(types[i], new NodeInfo(help, subMenu));
					}
				}
			}
		}
	}
	
	public abstract class BaseFormulaStep : CoreFormulaStep
	{
		[ORKEditorHelp("Enabled", "This step is enabled and will be executed.\n" +
			"If disabled, the step wont execute and the next step ('Next') will be executed.", "")]
		[ORKEditorInfo(hide=true)]
		public bool active = true;
		
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		public abstract int Calculate(ref float result, Combatant user, Combatant target);
		
		public virtual int CalculatePreview(ref float result, Combatant user, Combatant target)
		{
			return this.Calculate(ref result, user, target);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "";
		}
		
		public override string GetNodeDetails()
		{
			return "";
		}
		
		public override string GetNextName(int index)
		{
			return "Next";
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}
		
		public override int GetNext(int index)
		{
			return this.next;
		}
		
		public override void SetNext(int index, int next)
		{
			this.next = next;
		}
		
		
		/*
		============================================================================
		Enable functions
		============================================================================
		*/
		public override bool IsEnabled
		{
			get{ return this.active;}
		}
	}
	
	public abstract class BaseFormulaCheckStep : BaseFormulaStep
	{
		[ORKEditorInfo(hide=true)]
		public int nextFail = -1;
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Success";
			}
			else if(index == 1)
			{
				return "Failed";
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return 2;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.nextFail;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.nextFail = next;
			}
		}
	}
	
	[ORKEditorHelp("Rounding", "The current value of the formula will be rounded.\n" +
		"The rounded value can be summed up.", "")]
	[ORKNodeInfo("Base Steps")]
	public class RoundingStep : BaseFormulaStep
	{
		[ORKEditorHelp("Rounding", "Rounds the current value of the formula.\n" +
			"- None: No rounding.\n" +
			"- Ceil: The value will be rounded up (e.g. 14.2 will become 15).\n" +
			"- Floor: The value will be rounded down (e.g. 14.8 will become 14).\n" +
			"- Round: The value will be rounded to the nearest integer (e.g. 14.2 will become 14, 14.8 will become 15).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Rounding rounding = Rounding.None;

		[ORKEditorHelp("Sum (1+...+n)", "The current value of the formula will be summed up, " +
			"i.e. all whole numbers starting from 1 to (including) the current formula value will be added to each other.\n" +
			"E.g. 5 will become 1+2+3+4+5=15.\n" +
			"The sum is build using the Gauss Sum ((n*(n+1))/2) where n is the current formula value (after rounding).", "")]
		[ORKEditorLayout("rounding", Rounding.None, elseCheckGroup=true, endCheckGroup=true)]
		public bool doSum = false;
		
		public RoundingStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			result = ValueHelper.GetRounded(result, this.rounding);
			if(!Rounding.None.Equals(this.rounding) && this.doSum)
			{
				int sum = (int)result;
				sum = (sum * (sum + 1)) / 2;
				result = sum;
			}
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.rounding + (this.doSum ? ", Sum" : "");
		}
	}
	
	[ORKEditorHelp("Limit Value", "The current value of the formula will be limited.", "")]
	[ORKNodeInfo("Base Steps")]
	public class LimitValueStep : BaseFormulaStep
	{
		[ORKEditorHelp("Use Minimum", "The current value will be limited by a minimum value.", "")]
		[ORKEditorInfo(separator=true, labelText="Min/Max Value")]
		public bool useMin = false;

		[ORKEditorHelp("Minimum Value", "The value will have at least this value.", "")]
		[ORKEditorLayout("useMin", true, endCheckGroup=true)]
		public float min = 0;

		[ORKEditorHelp("Use Maximum", "The current value will be limited by a maximum value.", "")]
		public bool useMax = false;

		[ORKEditorHelp("Maximum Value", "The value will have this value at most.", "")]
		[ORKEditorLayout("useMax", true, endCheckGroup=true)]
		public float max = 0;
		
		public LimitValueStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			if(this.useMin && result < this.min)
			{
				result = this.min;
			}
			else if(this.useMax && result > this.max)
			{
				result = this.max;
			}
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useMin ? this.min.ToString() : "X") + " - " + (this.useMax ? this.max.ToString() : "X");
		}
	}
	
	[ORKEditorHelp("Absolute Value", "The current value of the formula will be absolute, i.e. negative values will become positive.\n" +
			"E.g.: -10.5 will become 10.5", "")]
	[ORKNodeInfo("Base Steps")]
	public class AbsoluteValueStep : BaseFormulaStep
	{
		public AbsoluteValueStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			result = Mathf.Abs(result);
			return this.next;
		}
	}
	
	[ORKEditorHelp("Random", "Randomly executes a next step out of a list of defined steps.", "")]
	[ORKNodeInfo("Base Steps")]
	public class RandomStep : BaseFormulaStep
	{
		[ORKEditorInfo(hide=true, instanceCallback="buttons:randomstep")]
		public int[] random = new int[] {-1};
		
		public RandomStep()
		{
			
		}

		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			return this.random[Random.Range(0, this.random.Length)];
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			return "Random " + index;
		}
		
		public override int GetNextCount()
		{
			return this.random.Length;
		}
		
		public override int GetNext(int index)
		{
			return this.random[index];
		}
		
		public override void SetNext(int index, int next)
		{
			this.random[index] = next;
		}
	}
	
	[ORKEditorHelp("Comment", "Leave a comment in your formula.\n" +
		"This step does nothing and is only for commentary purposes.", "")]
	[ORKNodeInfo("Base Steps")]
	public class CommentStep : BaseFormulaStep
	{
		[ORKEditorHelp("Comment", "The comment.", "")]
		[ORKEditorInfo(isTextArea=true)]
		public string comment = "";
		
		public CommentStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			return this.next;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.comment;
		}
	}
}
